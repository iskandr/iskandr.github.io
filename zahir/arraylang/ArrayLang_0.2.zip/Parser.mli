type token =
  | NUM of (float)
  | ID of (string)
  | STR of (string)
  | DOT
  | COMMA
  | COLON
  | SEMICOLON
  | DOLLAR
  | LPAREN
  | RPAREN
  | LBRACKET
  | RBRACKET
  | AT
  | FN
  | DEF
  | END
  | IF
  | THEN
  | ELSE
  | LET
  | SET
  | IN
  | TRUE
  | FALSE
  | NOT
  | AND
  | OR
  | PLUS
  | MINUS
  | TIMES
  | DIV
  | DOT_PLUS
  | DOT_MINUS
  | DOT_TIMES
  | DOT_DIV
  | EQ
  | LT
  | LTE
  | GT
  | GTE
  | NEQ
  | ARROW
  | DOUBLE_ARROW
  | UNDERSCORE
  | EOF

val program :
  (Lexing.lexbuf  -> token) -> Lexing.lexbuf -> Base.node
