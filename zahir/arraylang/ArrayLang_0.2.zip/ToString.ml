open Base;;
open Printf;;

  let unop_to_string = function 
		| Not -> "not"
		| Pos -> "+"
		| Neg -> "-";;

  let binop_to_string = function 
		| Add -> "+"
		| AddElts -> ".+"
		| Sub -> "-"
		| SubElts -> ".-"
		| Mult -> "*"
		| MultElts -> ".*"
		| Div -> "/"
		| DivElts -> "./"
		| And -> "&&"
		| Or -> "||"
		| Eq -> "=="
		| Gt -> ">"
		| Gte -> ">="
		| Lt -> "<"
		| Lte -> "<="
		| Neq -> "~=";;

let rec value_to_string v =  
	  match v with 
		| Nil -> "nil"
		| Void -> ""
		(*| IntVal num -> string_of_int num*)
		| NumVal num -> sprintf "%g" num (*string_of_float num*)
		| StringVal str -> str
		| BoolVal b -> string_of_bool  b
		| TupleVal data -> 
			   "(" ^ String.concat ", " (Array.to_list (Array.map value_to_string data)) ^ ")"
		| ArrayVal(shape, contents) -> 
			let str_list = Array.to_list(Array.map value_to_string contents) in 
			sprintf "[ %s ]" (String.concat " " str_list) 
		| LambdaVal(args, body) -> 
			  "@(" ^ (String.concat ", " args) ^ ")"
		| Primitive prim -> "<primitive-function>";;

let rec pattern_to_string = function
	  WildcardPattern -> "_"
		| IdPattern name -> name
		| TuplePattern ps -> String.concat ", " (Array.to_list (Array.map pattern_to_string ps));;