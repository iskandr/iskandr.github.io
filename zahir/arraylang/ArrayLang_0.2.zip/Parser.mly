
%{
	open Printf;;
	open Base;;

  let makeNode e = 
		let lexpos = Parsing.symbol_start_pos () in
		let line = lexpos.Lexing.pos_lnum in
		let col = (lexpos.Lexing.pos_cnum - lexpos.Lexing.pos_bol) in 
			makeASTNode (e, line, col);;

%}

%token <float> NUM 
%token <string> ID 
%token <string> STR
%token  DOT COMMA COLON SEMICOLON DOLLAR
%token LPAREN RPAREN LBRACKET RBRACKET
%token AT FN DEF END
%token IF THEN ELSE LET SET IN
%token TRUE FALSE
%token NOT AND OR 
%token PLUS MINUS TIMES DIV
%token DOT_PLUS DOT_MINUS DOT_TIMES DOT_DIV 
%token EQ LT LTE GT GTE NEQ
%token ARROW DOUBLE_ARROW UNDERSCORE
%token EOF

%left EQ GT GTE LT LTE NEQ 
%nonassoc COLON
%left DOLLAR

%left DOT_MINUS MINUS DOT_PLUS PLUS OR
%left DOT_TIMES TIMES DOT_DIV DIV MOD AND
%left UMINUS NOT
%left FCALL

%nonassoc THEN 
%nonassoc ELSE
%nonassoc LET
%nonassoc END 


%start program
%type <Base.node> program


/* grammar */
%%


program:	exp_list { makeNode(Program($1)) }
;

exp_list: exp rest_of_exp_list { $1 :: $2 }
;


rest_of_exp_list:
    { [] }
   | SEMICOLON exp rest_of_exp_list { $2 :: $3 }
;


exp:
      tuple {$1 }
	    | exp1 { $1 }
;

exp1:   
 			| let_expr                        { $1 } 
			| if_expr                         { $1 }
			| if_else_expr                    { $1 }
      | exp2 { $1 }
;

exp2:
			range_exp  { $1 }
      | exp3 { $1 }  
;

exp3:
			| lambda                          { $1 }   
  		| function_definition             { $1 }
			| or_expr                           { $1 }
;

or_expr:
	or_expr OR and_expr 	{ makeNode(BinaryExpression(Or, $1, $3)) }
	| and_expr {$1}
;

and_expr:
	| and_expr AND not_expr 				{ makeNode(BinaryExpression(And, $1, $3)) }
	| not_expr {$1}
;

not_expr:
 			| NOT relational									{ makeNode(UnaryExpression(Not, $2)) }
			| relational {$1}
;
relational:
	 				| relational EQ term 											{ makeNode(BinaryExpression(Eq, $1, $3)) }
	 				| relational GT term 											{ makeNode(BinaryExpression(Gt, $1, $3)) }
	 				| relational GTE term 										{ makeNode(BinaryExpression(Gte, $1, $3)) }
	 				| relational LT term											{ makeNode(BinaryExpression(Lt, $1, $3)) }
	 				| relational LTE term 										{ makeNode(BinaryExpression(Lte, $1, $3)) }
	 				| relational NEQ term 										{ makeNode(BinaryExpression(Neq, $1, $3)) }
					| term { $1 }
;
term:
	  	term PLUS factor					{ makeNode(BinaryExpression(Add, $1, $3)) }
			| term DOT_PLUS factor    { makeNode(BinaryExpression(AddElts, $1, $3)) }  
			| term MINUS factor				{ makeNode(BinaryExpression(Sub, $1,  $3)) } 
		  | MINUS term %prec UMINUS  { makeNode(UnaryExpression(Neg, $2)) } 
			| term DOT_MINUS factor		{ makeNode(BinaryExpression(SubElts, $1,  $3)) } 
			| factor                          {$1 }
;

factor:
          postfix   { $1 } 
				 	| factor TIMES postfix				{ makeNode(BinaryExpression(Mult, $1, $3)) }
					| factor DOT_TIMES postfix		{ makeNode(BinaryExpression(MultElts, $1, $3)) } 
				  | factor DIV postfix					{ makeNode(BinaryExpression(Div, $1, $3)) }
					| factor DOT_DIV postfix     { makeNode(BinaryExpression(DivElts, $1, $3)) }  	
;

postfix:
					| function_reference %prec FCALL  { $1 }  
					| atom                            { $1 }
;

atom:
          constant                          { $1 }
				  | STR 													  { makeNode(StringLiteral($1)) } 
					| variable											  { $1 }
				  | LPAREN exp RPAREN								{ $2 } 
					| array                           { $1 }
;

constant: 		
				NUM														      { makeNode(FloatLiteral($1)) }
				| TRUE                              { makeNode(BoolLiteral(true)) } 
				| FALSE                             { makeNode(BoolLiteral(false)) }
;

variable: identifier  { $1 }
;


range_exp:
        exp1 COLON exp1 COLON exp1 { makeNode(RangeExpression($1, $5, $3)) }
;



tuple: exp1 COMMA exp1 rest_of_tuple { makeNode(TupleExpression($1::$3::$4)) } 
;

rest_of_tuple:   { [] }
               | COMMA exp1 rest_of_tuple { $2::$3 }
;

function_definition:
	DEF ID identifier_list exp END 
	 { makeNode(FunctionDefinition($2, $3, $4)) }
;

lambda:
	AT identifier_list exp END { makeNode(LambdaExpression($2, $3)) }
;


identifier_list: 
   LPAREN RPAREN { [] } 
	| LPAREN ID rest_of_identifier_list { $2::$3 }
;

rest_of_identifier_list: 	
              RPAREN  { [] }
							| COMMA ID rest_of_identifier_list	{ $2::$3 }
;


identifier: ID													{ makeNode(Id($1)) }
;

function_reference: variable actual_parameter_list  { makeNode(FunctionReference($1, $2)) }
							      | function_reference actual_parameter_list { makeNode(FunctionReference($1, $2)) }
										| lambda actual_parameter_list { makeNode(FunctionReference($1, $2)) }
										| LPAREN exp RPAREN actual_parameter_list { makeNode(FunctionReference($2, $4)) } 
;

actual_parameter_list: 
            LPAREN RPAREN { [] }
						|  LPAREN exp1 rest_of_actual_parameter_list							{ $2 :: $3 }
;

rest_of_actual_parameter_list: 											
                RPAREN { [] }
								| COMMA exp1 rest_of_actual_parameter_list		{ $2 :: $3 }
;




let_expr: LET pattern SET exp IN exp END          { makeNode(LetExpr($2, $4, $6)) }
;

if_expr :   IF exp1 THEN exp END 							     { makeNode(IfExpr($2, $4)) }
;

if_else_expr:  IF exp1 THEN exp ELSE exp	END { makeNode(IfElseExpr($2, $4, $6)) }
;


array: LBRACKET exp1 rest_of_array						{ makeNode(ArrayExpression ($2 :: $3)) }
;

rest_of_array: 	RBRACKET 											{ [] }
 /*             | COMMA exp1 rest_of_array {$2::$3}  */
								|   exp1 rest_of_array 		{ $1 :: $2 }
;

/*
pattern: pattern1 { makeNode(PatternExpression($1))}
;
*/
pattern:   tuple_pattern { $1 }
            | pattern1 { $1 }
;

pattern1: id_pattern { $1 }
          | LPAREN pattern RPAREN { $2 }
				  | wildcard {$1}
;

wildcard: UNDERSCORE { WildcardPattern } 
;

id_pattern: ID { IdPattern($1) }
;

tuple_pattern:  pattern1 COMMA pattern1 rest_of_tuple_pattern  { TuplePattern(Array.of_list ($1::$3::$4)) }
;

rest_of_tuple_pattern: 
                       {[]}
                       | COMMA pattern1 rest_of_tuple_pattern  { $2::$3 }
;

%%
