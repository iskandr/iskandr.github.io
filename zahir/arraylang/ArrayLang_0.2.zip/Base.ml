
exception EvalError of string;;
exception MatchFailure of string;;

type unary_op = Not | Pos |  Neg;;
	
type binary_op = Add | AddElts | Sub | SubElts | 
	                 Mult | MultElts | Div | DivElts | 
									 And | Or |  Eq | Gt | Gte | Lt | Lte | Neq;;

type node = {id:int; data:expr; line:int; col:int}
and expr = 
		     | Program of node list
		     | LetExpr of pattern * node * node 
				 | IfExpr of node * node
         | IfElseExpr of node * node * node
         | Id of string
				 | FloatLiteral of float  
         | StringLiteral of string
				 | BoolLiteral of bool
         | UnaryExpression of unary_op * node
         | BinaryExpression of binary_op * node * node
         | FunctionReference of node * (node list)
				 | FunctionDefinition of string * (string list) * node
				 | LambdaExpression of (string list) * node
				 | ArrayExpression of node list
				 | RangeExpression of node * node * node
				 | TupleExpression of node list
	(*			 | PatternExpression of pattern *)
and value = Nil
						| Void 
	          | NumVal of float 
						| BoolVal of bool
						| StringVal of string
						| ArrayVal of int array * value array
						| LambdaVal of string list * node 
						| TupleVal of value array
						| Primitive of (value list -> value)
and  pattern = WildcardPattern 
               | IdPattern of string 
							 | TuplePattern of pattern array;;

type pattern_result = Success of (string * value) list | Failure;; 

let node_id = ref 0;;      
  
let makeASTNode (e, l, c) = 
		let i = !node_id in 
			node_id := !node_id + 1; {id=i; data=e; line=l; col=c};;

