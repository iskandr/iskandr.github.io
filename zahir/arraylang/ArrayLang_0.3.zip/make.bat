del *.cmo
del *.cmi
ocamlyacc Parser.mly
ocamlc -c Base.ml
ocamlc -c  Parser.mli
ocamllex lexer.mll
ocamlc -c  lexer.ml
ocamlc -c  Parser.ml
ocamlc -c Environment.ml
ocamlc -c ToString.ml
ocamlc -c EvalMath.ml
ocamlc -c EvalArray.ml
ocamlc -c EvalPatterns.ml
ocamlc -c Eval.ml
ocamlc -c Interpreter.ml
ocamlc -c Primitives.ml
ocamlc -c  Main.ml
ocamlc   Base.cmo Parser.cmo lexer.cmo Environment.cmo ToString.cmo EvalMath.cmo EvalArray.cmo EvalPatterns.cmo Eval.cmo Interpreter.cmo Primitives.cmo  Main.cmo -o ArrayLang.exe
