open Base;;

let rec array_access arrV args = 
	match arrV with 
		| ArrayVal(shape, data) -> 
			(match (Array.to_list shape), args with 
			| _, [] -> arrV
			| [], _ -> raise (EvalError "Insufficient array dimensions")
			| dim::restShape, (NumVal num)::otherArgs -> 
				let rawIdx = int_of_float num in 
				let idx = if rawIdx < 0 then dim + rawIdx else rawIdx - 1 in 
				if idx < dim && idx >= 0 then (array_access data.(idx) otherArgs)
				else raise (EvalError "Array access out of bounds")
			| _ -> raise (EvalError "What happened?"))
		 | _ -> 
			  (match args with
					| [] -> arrV
					| _ ->raise (EvalError "Insufficient array dimensions")) ;;

let get_shape vals = 
	let shape_list = List.map (function ArrayVal (d, _) -> d | _ -> [| |]) vals in
  let shape = 
		match shape_list with  
	   d::ds -> d 
		| [] -> raise (EvalError "Empty arrays not supported") 
	in if all_same shape_list then shape 
	else raise (EvalError "Ragged arrays not supported");;

let build_array contents = 
	  let shape = get_shape contents in 
		ArrayVal (Array.append [| List.length contents |] shape, Array.of_list contents);;
		
let eval_concat n1 n2 = 
	match n1, n2 with 
	| ArrayVal(shape1, arr1), ArrayVal(shape2, arr2) -> 
			if eq_array shape1 shape2 1 then 
			let newShape = Array.copy shape1 in 
				newShape.(0) <- shape1.(0) + shape2.(0); 
				ArrayVal (newShape, Array.append arr1 arr2)
			else raise (EvalError "Cannot merge arrays of mismatching sizes")
  | _ -> raise (EvalError "Cannot concatenate non-array");;

let eval_range left right stride =
		match left, right, stride with 
		| (NumVal leftVal, NumVal rightVal, NumVal strideVal) -> 
			let size = int_of_float ((rightVal -. leftVal) /. strideVal) + 1 in 
				if size < 1 then raise (EvalError "Range of negative size")
				else 
					let resultArray  = Array.make size Nil in 
					let comp = if leftVal < rightVal then (<=) else (>=) in 
					let counter, currVal = ref 0, ref leftVal in 
					while comp !currVal rightVal do
						resultArray.(!counter) <- NumVal (!currVal); 
						currVal := !currVal +. strideVal;
						counter := !counter + 1
					done;
					let len = !counter in 
					if len < 1 then raise (EvalError "Cannot evaluate empty range") else
					let slice =  Array.sub resultArray 0 len   in 
					let shape = [| len |] in  ArrayVal(shape, slice)
			| _ -> raise (EvalError "Range bounds must be numerical");;

