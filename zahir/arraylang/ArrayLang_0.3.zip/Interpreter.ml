open Printf;;
open Hashtbl;;

open Base;;
open Lexer;;
open Parser;;

open ToString;;
open Environment;;

open EvalMath;;
open EvalArray;;
open EvalPatterns;;
open Eval;;

let interp lexbuf = 
	try 
		let ast = Parser.program token lexbuf in
		let result =(eval globalEnv ast) in
		let str = value_to_string result in 
		if String.length str > 0 then  printf "ans = %s \n" str;
		Hashtbl.replace globalEnv.values "ans" result
	 with
	 | Parsing.Parse_error  ->  
		  let p = (lexbuf.Lexing.lex_curr_p.Lexing.pos_cnum - lexbuf.Lexing.lex_curr_p.Lexing.pos_bol) in 
		  let l = lexbuf.Lexing.lex_curr_p.Lexing.pos_lnum in 
		    printf "parse error occurred on line %d at position %d \n" l p
	  | BindingNotFound id -> 
		    printf "no binding found for %s \n" id
	  | EvalError msg -> 
			  printf "error occurred - %s \n" msg
		| MatchFailure msg -> 
			 printf "match failure - %s \n" msg
		| InvalidBinop op -> 
			 printf "error while using binary %s operator \n" (binop_to_string op)
		| InvalidUnop op -> 
			 printf "error while using unary %s \n" (unop_to_string op)
		| Division_by_zero -> printf "Division by zero \n"
		| _ as e ->  raise e;;

let interp_file name = 
	try
		let cin = open_in name in 
	  let lexbuf = Lexing.from_channel cin in 
	  let result = interp lexbuf in 
		close_in cin;
		result
	with 
  	   Sys_error(msg) -> printf "Error: File not found (%s) \n" msg;;
