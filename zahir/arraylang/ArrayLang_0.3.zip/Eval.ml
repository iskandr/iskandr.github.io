open Printf;;
open Base;;
open Lexer;;
open Parser;;
open ToString;;
open Environment;;

open EvalMath;;
open EvalArray;;
open EvalPatterns;;

let rec  eval:environment->node->value  = fun  env ast ->
	let eval' = eval env in 
    match ast.data with 
		  | Program statements -> 
				  (match List.rev_map eval' statements with 
						| [] -> Nil
						| x::xs -> x)
   		| FunctionDefinition(id, formal_args, body) -> 
				  set_binding env.values id (LambdaVal(formal_args, body, env));
					Void
			| DefineExpression(pat, exp) -> 
				  let bindings = get_bindings pat (eval' exp) in 
				  	modify_map env.values bindings;
						Void 
			| LambdaExpression(args, body) -> LambdaVal(args, body, env)
			| LetExpr(pat, valExpr, body) ->
				 	match_and_eval env pat (eval' valExpr) body
			 | FunctionReference(fnExpr, argsExpr) -> 
				  let fn = eval' fnExpr in
					let actuals = List.map eval' argsExpr in  
					apply fn actuals
			| IfExpr (testExpr, trueExpr) -> 
				let testVal = eval' testExpr in 
				 (
					match testVal with 
					| BoolVal true -> eval' trueExpr
					| BoolVal false -> Nil
					| _ -> raise (EvalError "test value must be a boolean")
					);
    	| IfElseExpr (testExpr, trueExpr, falseExpr) ->
				 let testVal = eval' testExpr in 
				 (
					match testVal with 
					| BoolVal true -> eval' trueExpr
					| BoolVal false -> eval' falseExpr
					| _ -> raise (EvalError "test value must be a boolean")
					);
    	| Id name -> lookup name env
    (*  | IntLiteral num -> IntVal num*)
		  | FloatLiteral num -> NumVal num 
      | StringLiteral str -> StringVal str
			| BoolLiteral b -> BoolVal b
			| TupleExpression nodes -> 
				   TupleVal (Array.of_list (List.map eval' nodes))
      | UnaryExpression(op, arg) -> eval_unop op (eval' arg)
      | BinaryExpression(op, arg1, arg2) -> eval_binop op (eval' arg1) (eval' arg2)
			| ArrayExpression contents -> 
				  build_array (List.map eval' contents)
			| ConcatExpression(n1, n2) -> 
					eval_concat (eval' n1) (eval' n2)
			| RangeExpression(left, right, stride) ->
				  eval_range (eval' left) (eval' right) (eval' stride)
			| ForExpression(pat, exp, body) ->
			    match eval' exp with
					| ArrayVal(shape, data) -> 
							let len = (Array.length data) in
							let newData = Array.make len  Nil in 
							for i = 0 to len  - 1 do
								newData.(i) <- match_and_eval env pat data.(i) body
							done; 
							let innerShape = get_shape (Array.to_list newData) in 
						  ArrayVal(Array.append [|len|] innerShape, newData)
					| _ -> raise (EvalError "Iteration requires an array type")
	and apply fn args = 
		match fn with 
	  | LambdaVal(formals, body, closure_env) -> 
			let nformals = (List.length formals) in 
			let nactuals = (List.length args) in 
			if nformals <> nactuals then 
				raise (EvalError (sprintf "arity mismatch - expected %d, got %d" nformals nactuals))
			else let bindings = List.combine formals args in
				eval (extend_env closure_env bindings) body
		| Primitive prim -> prim args
		| ArrayVal (shape, data) as arr -> 
		     array_access arr args
		 | _ -> raise (EvalError "Cannot call non-function") 
	and match_and_eval env pat value body = 
				 let bindings = get_bindings pat value in  
				 let newEnv = extend_env env bindings in 
				 eval newEnv body;;
	
