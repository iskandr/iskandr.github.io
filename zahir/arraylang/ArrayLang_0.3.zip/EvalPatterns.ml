open Base;;
open ToString;;

let rec match_pattern pat value = 
	match pat, value with
		| _, Void -> Failure 
		| WildcardPattern, _ -> Success []
		| IdPattern name, _ -> Success [name, value]
		| TuplePattern ps, TupleVal vs -> 
			   match_arrays ps vs
		| TuplePattern ps, _ -> Failure
		| ArrayPattern ps, ArrayVal(shape, data) ->
			   match_arrays ps data
		| ArrayPattern ps, _ -> Failure
and match_arrays ps vs = 
	if Array.length ps <> Array.length vs then Failure else
		let result = List.map2 match_pattern (Array.to_list ps) (Array.to_list vs) in 
			if List.exists (fun x -> match x with Failure -> true | _ -> false) result then 
			   Failure
		  else let hoisted = 
				 List.map (fun x -> match x with Failure -> [] | Success xs -> xs) result 
			in  Success (List.flatten hoisted);;

let get_bindings pat value =
	match match_pattern pat value with 
	| Failure -> 
		 let msg = "Failed to match pattern " ^ (pattern_to_string pat) ^ 
		           " with " ^ (value_to_string value) 
		 in raise (MatchFailure msg)
  | Success bindings -> bindings;;
