
open Hashtbl;;

exception EvalError of string;;
exception MatchFailure of string;;

let uniq lst =
  let unique_set = Hashtbl.create (List.length lst) in
    List.iter (fun x -> Hashtbl.replace unique_set x ()) lst;
    Hashtbl.fold (fun x () xs -> x :: xs) unique_set [];;

let all_same lst = List.length (uniq lst) = 1;; 

let rec eq_array arr1 arr2 idx = 
	if idx >= Array.length arr1 then 
		idx >= Array.length arr2
	else if arr1.(idx) = arr2.(idx) then 
		 eq_array arr1 arr2 (idx+1)
	else false;; 

type unary_op = Not | Pos |  Neg;;
	
type binary_op = Add | AddElts | Sub | SubElts | 
	                 Mult | MultElts | Div | DivElts | 
									 And | Or |  Eq | Gt | Gte | Lt | Lte | Neq;;


type node = {id:int; data:expr; line:int; col:int}
and expr = 
		     | Program of node list
		     | LetExpr of pattern * node * node 
				 | IfExpr of node * node
         | IfElseExpr of node * node * node
         | Id of string
				 | FloatLiteral of float  
         | StringLiteral of string
				 | BoolLiteral of bool
         | UnaryExpression of unary_op * node
         | BinaryExpression of binary_op * node * node
				 | DefineExpression of pattern * node  
         | FunctionReference of node * (node list)
				 | FunctionDefinition of string * (string list) * node
				 | LambdaExpression of (string list) * node
				 | ArrayExpression of node list
				 | RangeExpression of node * node * node
				 | TupleExpression of node list
				 | ConcatExpression of node * node 
				 | ForExpression of pattern * node * node 
(*				 | MatchExpression of node * (pattern, node) list  *)
and value = Nil
						| Void 
	          | NumVal of float 
						| BoolVal of bool
						| StringVal of string
						| ArrayVal of int array * value array
						| LambdaVal of string list * node  * environment
						| TupleVal of value array
						| Primitive of (value list -> value)
and val_map = (string, value) Hashtbl.t
and environment = {values:val_map; parent:environment option}
and pattern = WildcardPattern 
               | IdPattern of string 
							 | TuplePattern of pattern array
							 | ArrayPattern of pattern array;;

type pattern_result = Success of (string * value) list | Failure;; 

let node_id = ref 0;;      
  
let makeASTNode (e, l, c) = 
		let i = !node_id in 
			node_id := !node_id + 1; {id=i; data=e; line=l; col=c};;

