open Printf;;

open Base;;
open ToString;;

exception InvalidUnop of unary_op;;
exception InvalidBinop of binary_op;;

let eval_unop op arg = 
	match (op, arg) with 
		(Not, BoolVal b) -> BoolVal (not b)
		| (Pos, NumVal num)-> NumVal num
		| (Neg, NumVal num) -> NumVal (-. num)
		| _ -> raise (InvalidUnop op);;

let rec eval_binop op arg1 arg2 = 
	match (op, arg1, arg2) with 
		      (* scalar ops *)
					| (Add, NumVal num1, NumVal num2) 
					| (AddElts, NumVal num1, NumVal num2) -> NumVal (num1 +. num2)  
					| (Sub, NumVal num1, NumVal num2) 
					| (SubElts, NumVal num1, NumVal num2) -> NumVal (num1 -. num2)  
					| (Mult, NumVal num1, NumVal num2) -> NumVal (num1 *. num2) 
					| (MultElts, NumVal num1, NumVal num2) -> NumVal(num1 *. num2) 
					| (Div, NumVal num1, NumVal num2) -> NumVal(num1 /. num2)  
					| (DivElts, NumVal num1, NumVal num2) -> NumVal (num1 /. num2)
					(* scalar comparison *)
					| (Gt, NumVal num1, NumVal num2) -> BoolVal(num1 > num2) 
					| (Gte, NumVal num1, NumVal num2) -> BoolVal(num1 >= num2)  
					| (Lt, NumVal num1, NumVal num2) -> BoolVal(num1 < num2)  
					| (Lte, NumVal num1, NumVal num2) -> BoolVal(num1 <= num2) 
					(* matrix ops *)
					| Add, (ArrayVal (shape1, array1) as a1), (ArrayVal(shape2, array2)as a2) -> 
							array_op Add a1 a2
	(*				| Add, NumVal num, (ArrayVal(shape, array2)as arr) 
					| Add, (ArrayVal(shape, array2)as arr), NumVal num  -> 
							array_scalar_op Add num arr*)
					| Sub, (ArrayVal (shape1, array1) as a1), (ArrayVal(shape2, array2)as a2) -> 
						  array_op Sub a1 a2
					| Mult, (ArrayVal (shape1, array1) as a1), (ArrayVal(shape2, array2) as a2)->
						  array_op Mult a1 a2
					| MultElts, (ArrayVal (shape1, array1) as a1), (ArrayVal(shape2, array2)as a2) -> 
						  array_op MultElts a1 a2
					| Div, (ArrayVal (shape1, array1) as a1), (ArrayVal(shape2, array2)as a2) -> 
						  array_op Div a1 a2
					| DivElts, (ArrayVal (shape1, array1) as a1), (ArrayVal(shape2, array2)as a2) -> 
						  array_op DivElts a1 a2
					(* boolean comparison *)
					| (And, BoolVal b1, BoolVal b2) ->  BoolVal (b1 && b2)
					| (Or, BoolVal b1, BoolVal b2) -> BoolVal (b1 || b2) 
					(* object equality *)
					| (Eq, val1, val2) -> BoolVal(val1 = val2)  
					| (Neq, val1, val2) -> BoolVal(val1 <> val2)
					| _ -> raise (InvalidBinop op)
and array_op op arr1 arr2 = 
	match arr1, arr2 with 
	| ArrayVal(shape1, arr1), ArrayVal(shape2, arr2) ->
		if shape1 = shape2  then 
			let result = Array.copy arr1 in 
			let len = Array.length result in
			let subshape = Array.sub shape1 1 ((Array.length shape1) - 1) in  		
				for i = 0 to len-1 do
					if Array.length subshape = 0 then 
						result.(i) <- eval_binop op arr1.(i) arr2.(i)
					else result.(i) <- array_op op arr1.(i) arr2.(i)
				done;
			ArrayVal (shape1, result)
		else let msg = sprintf "Cannot apply  %s to matrices of mismatching size" (binop_to_string op) in 
		 raise (EvalError msg)
  | _ ->  
		let msg = sprintf "Error while using %s operator" (binop_to_string op) in
			raise (EvalError msg);;
