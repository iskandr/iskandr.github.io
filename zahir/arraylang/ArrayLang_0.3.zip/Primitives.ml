open Base;;
open Environment;;
open Eval;;
open Interpreter;;

let primLen args = 
	  match args with 
			| [ArrayVal(shape, data)] -> NumVal(float_of_int shape.(0))
			| _ -> raise (EvalError "Wrong argument type, expected array");;

let primReduce args = 
		match args with 
			| [fn; ArrayVal(shape, data) as arr] ->
				   let len = Array.length data in 
					 if len = 0 then arr 
					 else let acc = ref data.(0) in 
					 for i = 1 to len - 1 do
							acc := (apply fn [!acc; data.(i)])
					 done;
					 !acc	 
			| _ -> raise(EvalError "Wrong argument types, expected function and array");;
  
let _ = 
	      def_prim "len" primLen;
				def_prim "reduce" primReduce;
				float_prim "cos" cos;
		    float_prim "sin" sin;
			  float_prim "tan" tan;
			  float_prim "abs" abs_float;
			  float_prim "log" log;
			  float_prim "log10" log10;
			  float_prim "sqrt" sqrt;
			  float_prim "exp" exp;
			  string_to_void_prim "load" interp_file;; 
