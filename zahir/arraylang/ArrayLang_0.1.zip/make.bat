del *.cmo
del *.cmi
ocamlyacc Parser.mly
ocamlc -c Base.ml
ocamlc -c  AST.ml
ocamlc -c  Parser.mli
ocamllex lexer.mll
ocamlc -c  lexer.ml
ocamlc -c  Parser.ml
ocamlc -c Environment.ml
ocamlc -c Interpreter.ml
ocamlc -c Primitives.ml
ocamlc -c  Main.ml
ocamlc   Base.cmo AST.cmo  Parser.cmo lexer.cmo Environment.cmo Interpreter.cmo Primitives.cmo Main.cmo -o ArrayLang.exe
