open Base;;
open AST;;
open Lexer;;
open Parser;;
open Printf;;
open Environment;;
open Interpreter;;


let rec repl () = 		
		print_string ">> ";
		let input = read_line () in 
		if input <> "exit" then 
			let lexbuf = Lexing.from_string input in 
			interp lexbuf;
		  repl ();;


let main () =	 
	 let len = Array.length Sys.argv in 
	 if len < 2 then 
		  repl ()
	 else let inFile = Sys.argv.(1) in  
	    interp_file inFile;;
 
let _ = (Printexc.print main ()); print_string "\n";