open Printf;;
open Base;;
open AST;;
open Lexer;;
open Parser;;
open Environment;;

open Array;;
open Map;;
open Hashtbl;;



exception InvalidUnop of unary_op;;
exception InvalidBinop of binary_op;;

let rec value_to_string v =  
	  match v with 
		| Nil -> "nil"
		| Void -> ""
		(*| IntVal num -> string_of_int num*)
		| NumVal num -> sprintf "%g" num (*string_of_float num*)
		| StringVal str -> str
		| BoolVal b -> string_of_bool  b
		| ArrayVal(shape, contents) -> 
			let str_list = Array.to_list(Array.map value_to_string contents) in 
			sprintf "[ %s ]" (String.concat " " str_list) 
		| LambdaVal(args, body) -> 
			  "@(" ^ (String.concat ", " args) ^ ")"
		| Primitive prim -> "<primitive-function>";;



let eval_unop op arg = 
	match (op, arg) with 
		(Not, BoolVal b) -> BoolVal (not b)
		| (Pos, NumVal num)-> NumVal num
		| (Neg, NumVal num) -> NumVal (-. num)
		| _ -> raise (InvalidUnop op);;

let rec eval_binop op arg1 arg2 = 
	match (op, arg1, arg2) with 
		      (* scalar ops *)
					| (Add, NumVal num1, NumVal num2) 
					| (AddElts, NumVal num1, NumVal num2) -> NumVal (num1 +. num2)  
					| (Sub, NumVal num1, NumVal num2) 
					| (SubElts, NumVal num1, NumVal num2) -> NumVal (num1 -. num2)  
					| (Mult, NumVal num1, NumVal num2) -> NumVal (num1 *. num2) 
					| (MultElts, NumVal num1, NumVal num2) -> NumVal(num1 *. num2) 
					| (Div, NumVal num1, NumVal num2) -> NumVal(num1 /. num2)  
					| (DivElts, NumVal num1, NumVal num2) -> NumVal (num1 /. num2)
					(* scalar comparison *)
					| (Gt, NumVal num1, NumVal num2) -> BoolVal(num1 > num2) 
					| (Gte, NumVal num1, NumVal num2) -> BoolVal(num1 >= num2)  
					| (Lt, NumVal num1, NumVal num2) -> BoolVal(num1 < num2)  
					| (Lte, NumVal num1, NumVal num2) -> BoolVal(num1 <= num2) 
					(* matrix ops *)
					| Add, (ArrayVal (shape1, array1) as a1), (ArrayVal(shape2, array2)as a2) -> 
							array_op Add a1 a2
	(*				| Add, NumVal num, (ArrayVal(shape, array2)as arr) 
					| Add, (ArrayVal(shape, array2)as arr), NumVal num  -> 
							array_scalar_op Add num arr*)
					| Sub, (ArrayVal (shape1, array1) as a1), (ArrayVal(shape2, array2)as a2) -> 
						  array_op Sub a1 a2
					| MultElts, (ArrayVal (shape1, array1) as a1), (ArrayVal(shape2, array2)as a2) -> 
						  array_op MultElts a1 a2
					| DivElts, (ArrayVal (shape1, array1) as a1), (ArrayVal(shape2, array2)as a2) -> 
						  array_op DivElts a1 a2
					(* boolean comparison *)
					| (And, BoolVal b1, BoolVal b2) ->  BoolVal (b1 && b2)
					| (Or, BoolVal b1, BoolVal b2) -> BoolVal (b1 || b2) 
					(* object equality *)
					| (Eq, val1, val2) -> BoolVal(val1 = val2)  
					| (Neq, val1, val2) -> BoolVal(val1 <> val2)
					| _ -> raise (InvalidBinop op)
and array_op op arr1 arr2 = 
	match arr1, arr2 with 
	| ArrayVal(shape1, arr1), ArrayVal(shape2, arr2) ->
		if shape1 = shape2  then 
			let result = Array.copy arr1 in 
			let len = Array.length result in
			let subshape = Array.sub shape1 1 ((Array.length shape1) - 1) in  		
				for i = 0 to len-1 do
					if Array.length subshape = 0 then 
						result.(i) <- eval_binop op arr1.(i) arr2.(i)
					else result.(i) <- array_op op arr1.(i) arr2.(i)
				done;
			ArrayVal (shape1, result)
		else let msg = sprintf "Cannot apply  %s to matrices of mismatching size" (binop_to_string op) in 
		 raise (EvalError msg)
  | _ ->  
		let msg = sprintf "Error while using %s operator" (binop_to_string op) in
			raise (EvalError msg);;

let rec array_access arrV args = 
	match arrV with 
		| ArrayVal(shape, data) -> 
			(match (Array.to_list shape), args with 
			| _, [] -> arrV
			| [], _ -> raise (EvalError "Insufficient array dimensions")
			| dim::restShape, (NumVal num)::otherArgs -> 
				let idx = int_of_float num  in 
				if idx < dim then (array_access data.(idx) otherArgs)
				else raise (EvalError "Array access out of bounds")
			| _ -> raise (EvalError "What happened?"))
		 | _ -> 
			  (match args with
					| [] -> arrV
					| _ ->raise (EvalError "Insufficient array dimensions")) ;;

let uniq lst =
  let unique_set = Hashtbl.create (List.length lst) in
    List.iter (fun x -> Hashtbl.replace unique_set x ()) lst;
    Hashtbl.fold (fun x () xs -> x :: xs) unique_set [];;

let all_same lst = List.length (uniq lst) = 1;; 

let rec  eval:environment->node->value  = fun  env ast ->
	let eval' = eval env in 
    match ast.data with 
		  | Program statements -> 
				  (match List.rev_map eval' statements with 
						| [] -> Nil
						| x::xs -> x)
   		| FunctionDefinition(id, formal_args, body) -> 
				  set_binding env.values id (LambdaVal(formal_args, body));
					Void
			| LambdaExpression(args, body) -> LambdaVal(args, body)
			| LetExpr(idExpr, valExpr, body) -> 
				 let newEnv = extend_env env idExpr (eval' valExpr) in 
				 eval newEnv body
	  	| FunctionReference(fnExpr, argsExpr) -> 
				  let fn = eval' fnExpr in
					let actuals = List.map eval' argsExpr in  
					(match fn with 
						| LambdaVal(formals, body) -> 
							  let newMap = empty_map() in 			  
							  let pairs = List.combine formals actuals in 
								List.iter (fun (formal, actual)-> set_binding newMap formal actual) pairs;
								eval {values=newMap; parent=Some env} body
					  | Primitive prim -> prim actuals
						| ArrayVal (shape, data) as arr -> 
							  array_access arr  actuals
						| _ -> raise (EvalError "Cannot call non-function")) 
			| IfExpr (testExpr, trueExpr) -> 
				let testVal = eval' testExpr in 
				 (
					match testVal with 
					| BoolVal true -> eval' trueExpr
					| BoolVal false -> Nil
					| _ -> raise (EvalError "test value must be a boolean")
					);
    	| IfElseExpr (testExpr, trueExpr, falseExpr) ->
				 let testVal = eval' testExpr in 
				 (
					match testVal with 
					| BoolVal true -> eval' trueExpr
					| BoolVal false -> eval' falseExpr
					| _ -> raise (EvalError "test value must be a boolean")
					);
    	| Id name -> lookup name env
    (*  | IntLiteral num -> IntVal num*)
		  | FloatLiteral num -> NumVal num 
      | StringLiteral str -> StringVal str
			| BoolLiteral b -> BoolVal b
      | UnaryExpression(op, arg) -> eval_unop op (eval' arg)
      | BinaryExpression(op, arg1, arg2) -> eval_binop op (eval' arg1) (eval' arg2)
			| ArrayExpression contents -> 
				  let results = List.map eval' contents in
					let dims_list = List.map (function ArrayVal (d, _) -> d | _ -> [| |])  results in
					let dims = 
						match dims_list with  d::ds -> d 
						  | [] -> raise (EvalError "Empty arrays not supported") in
					if all_same dims_list then 
				     ArrayVal (Array.append [| List.length results |] dims, Array.of_list results)
					else raise (EvalError "Ragged arrays not supported")
			| RangeExpression(left, right, stride) ->
				    let left', right', stride' = (eval' left), (eval' right), (eval' stride) in 
						match left', right', stride' with 
							| (NumVal leftVal, NumVal rightVal, NumVal strideVal) -> 
							    let size = int_of_float ((rightVal -. leftVal) /. strideVal) + 1 in 
									if size < 1 then raise (EvalError "Range of negative size")
									else 
										let resultArray  = Array.make size Nil in 
										let comp = if leftVal < rightVal then (<=) else (>=) in 
									  let counter, currVal = ref 0, ref leftVal in 
										while comp !currVal rightVal do
											resultArray.(!counter) <- NumVal (!currVal); 
											currVal := !currVal +. strideVal;
											counter := !counter + 1
										done;
										let len = !counter in 
										if len < 1 then raise (EvalError "Cannot evaluate empty range") else
									  let slice =  Array.sub resultArray 0 len   in 
										let shape = [| len |] in 
										ArrayVal(shape, slice)
							| _ -> raise (EvalError "Range bounds must be numerical");;
										
let interp lexbuf = 
	try 
		let ast = Parser.program token lexbuf in
		let result =(value_to_string (eval globalEnv ast)) in 
		if String.length result > 0 then  printf "%s \n" result
	 with 
	 | Parsing.Parse_error  ->  
		  let p = (lexbuf.Lexing.lex_curr_p.Lexing.pos_cnum - lexbuf.Lexing.lex_curr_p.Lexing.pos_bol) in 
		  let l = lexbuf.Lexing.lex_curr_p.Lexing.pos_lnum in 
		    printf "parse error occurred on line %d at position %d \n" l p
	  | BindingNotFound id -> 
		    printf "no binding found for %s \n" id
	  | EvalError msg -> 
			  printf "error occurred - %s \n" msg
		| InvalidBinop op -> 
			 printf "error while using binary %s operator \n" (binop_to_string op)
		| InvalidUnop op -> 
			 printf "error while using unary %s \n" (unop_to_string op)
		| Division_by_zero -> printf "Division by zero \n"
		| _ as e ->  raise e;;

let interp_file name = 
	try
		let cin = open_in name in 
	  let lexbuf = Lexing.from_channel cin in 
	  let result = interp lexbuf in 
		close_in cin;
		result
	with 
  	   Sys_error(msg) -> printf "Error: File not found (%s)" msg;;
