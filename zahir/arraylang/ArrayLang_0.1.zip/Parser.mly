
%{
	open Printf;;
	open AST;;

  let makeNode e = 
		let lexpos = Parsing.symbol_start_pos () in
		let line = lexpos.Lexing.pos_lnum in
		let col = (lexpos.Lexing.pos_cnum - lexpos.Lexing.pos_bol) in 
			makeASTNode (e, line, col);;
%}

%token <float> NUM 
%token <string> ID 
%token <string> STR
%token  DOT COMMA COLON SEMICOLON LPAREN RPAREN LBRACKET RBRACKET
%token AT FN DEF END
%token IF THEN ELSE LET SET IN
%token TRUE FALSE
%token NOT AND OR 
%token PLUS MINUS TIMES DIV
%token DOT_PLUS DOT_MINUS DOT_TIMES DOT_DIV 
%token EQ LT LTE GT GTE NEQ
%token EOF



%left EQ GT GTE LT LTE NEQ 
%nonassoc COLON
%left DOT_MINUS MINUS DOT_PLUS PLUS OR
%left DOT_TIMES TIMES DOT_DIV DIV MOD AND
%left UMINUS NOT

%left FCALL
%nonassoc THEN 
%nonassoc ELSE
%nonassoc LET

%start program
%type <AST.node> program


/* grammar */
%%


program:	exp_list  { makeNode(Program($1)) }
;

/*
program: exp {$1} 
;
*/


exp_list: exp rest_of_exp_list { $1 :: $2 }
;

rest_of_exp_list:
    { [] }
   | SEMICOLON exp rest_of_exp_list { $2 :: $3 }
;


function_definition:
	DEF ID identifier_list exp END 
	 { makeNode(FunctionDefinition($2, $3, $4)) }
;

lambda:
	AT identifier_list exp END { makeNode(LambdaExpression($2, $3)) }
;


identifier_list: 
   LPAREN RPAREN { [] } 
	| LPAREN ID rest_of_identifier_list { $2::$3 }
;

rest_of_identifier_list: 	
              RPAREN  { [] }
							| COMMA ID rest_of_identifier_list	{ $2::$3 }
;


identifier: ID													{ makeNode(Id($1)) }
;

function_reference: variable actual_parameter_list  { makeNode(FunctionReference($1, $2)) }
                    | function_reference actual_parameter_list { makeNode(FunctionReference($1, $2)) }
										| lambda actual_parameter_list { makeNode(FunctionReference($1, $2)) }
										| LPAREN exp RPAREN actual_parameter_list { makeNode(FunctionReference($2, $4)) } 
;

actual_parameter_list: 
            LPAREN RPAREN { [] }
						|  LPAREN exp rest_of_actual_parameter_list							{ $2 :: $3 }
;

rest_of_actual_parameter_list: 											
                RPAREN { [] }
								| COMMA exp rest_of_actual_parameter_list		{ $2 :: $3 }
;

let_expr: LET identifier SET exp IN exp END          { makeNode(LetExpr($2, $4, $6)) }
;

if_expr :   IF exp THEN exp END 							     { makeNode(IfExpr($2, $4)) }
;

if_else_expr:  IF exp THEN exp ELSE exp	END { makeNode(IfElseExpr($2, $4, $6)) }
;


array: LBRACKET exp rest_of_array						{ makeNode(ArrayExpression ($2 :: $3)) }
;

rest_of_array: 	RBRACKET 											{ [] }
								| COMMA exp rest_of_array		{ $2 :: $3 }
;


exp:		
          constant                          { $1 }
				  | STR 													  { makeNode(StringLiteral($1)) } 
					| function_reference %prec FCALL  { $1 }  
					| identifier											{ $1 }
					| let_expr                        { $1 } 
					| if_expr                         { $1 }
					| if_else_expr                    { $1 }
					| math_op                         { $1 }
					| logic_op                        { $1 }
					| comparison                      { $1 }
					| LPAREN exp RPAREN								{ $2 }  
          | array                           { $1 }
					| range_exp                             { $1 } 
					| function_definition             { $1 }
					| lambda                          { $1 }
;

math_op:
	  exp PLUS exp					{ makeNode(BinaryExpression(Add, $1, $3)) }
		| exp DOT_PLUS exp    { makeNode(BinaryExpression(AddElts, $1, $3)) }  
		| exp MINUS exp				{ makeNode(BinaryExpression(Sub, $1,  $3)) } 
		| MINUS exp %prec UMINUS 		{ makeNode(UnaryExpression(Neg, $2)) } 
		| exp DOT_MINUS exp		{ makeNode(BinaryExpression(SubElts, $1,  $3)) } 
	 	| exp TIMES exp				{ makeNode(BinaryExpression(Mult, $1, $3)) }
		| exp DOT_TIMES exp		{ makeNode(BinaryExpression(MultElts, $1, $3)) } 
	  | exp DIV exp					{ makeNode(BinaryExpression(Div, $1, $3)) }
		| exp DOT_DIV exp     { makeNode(BinaryExpression(DivElts, $1, $3)) }  
; 		

logic_op:
 			| exp OR exp 					{ makeNode(BinaryExpression(Or, $1, $3)) }
	  	| exp AND exp 				{ makeNode(BinaryExpression(And, $1, $3)) }
 			| NOT exp 									{ makeNode(UnaryExpression(Not, $2)) }
	
;

comparison:
	 				| exp EQ exp 											{ makeNode(BinaryExpression(Eq, $1, $3)) }
	 				| exp GT exp 											{ makeNode(BinaryExpression(Gt, $1, $3)) }
	 				| exp GTE exp 										{ makeNode(BinaryExpression(Gte, $1, $3)) }
	 				| exp LT exp 											{ makeNode(BinaryExpression(Lt, $1, $3)) }
	 				| exp LTE exp 										{ makeNode(BinaryExpression(Lte, $1, $3)) }
	 				| exp NEQ exp 										{ makeNode(BinaryExpression(Neq, $1, $3)) }
;

range_exp:
        exp COLON exp COLON exp { makeNode(RangeExpression($1, $5, $3)) }
;

constant: 		
				NUM														      { makeNode(FloatLiteral($1)) }
/*				| MINUS NUM %prec UMINUS            { makeNode(FloatLiteral(-. $2)) } */
				| TRUE                              { makeNode(BoolLiteral(true)) } 
				| FALSE                             { makeNode(BoolLiteral(false)) }
;

variable: identifier  { $1 }
;

			

%%
