
open Base;;
open AST;;

open Hashtbl;;
open Printf;;

exception BindingNotFound of string;;

type val_map = (string, value) Hashtbl.t;;

type environment = {values:val_map; parent:environment option};;
let empty_map () = Hashtbl.create 13;;
let set_binding map k v = Hashtbl.add map k v;;

let globalEnv:environment = { values = (Hashtbl.create 127); parent = None };;
let def_prim name fn = Hashtbl.add globalEnv.values name (Primitive fn);;

let float_prim name fn = 
	let wrapper args = match args with 
	         	 | (NumVal num)::[] -> NumVal (fn num)
						 | _::[] -> raise (EvalError "Wrong argument type, number expected")
	           | _ -> raise (EvalError (sprintf "Arity mismatch: 1 expected, %d given" (List.length args)))
  in def_prim name wrapper;;


let string_to_void_prim name fn = 
	let wrapper args = match args with 
	         	 | (StringVal str)::[] -> (fn str); Void
						 | _::[] -> raise (EvalError "Wrong argument type, string expected")
	           | _ -> raise (EvalError (sprintf "Arity mismatch: 1 expected, %d given" (List.length args)))
  in def_prim name wrapper;;



let extend_env env idExpr value = 
	match idExpr.data with 
(*	| Id id -> 	{ values = StringMap.add id value (StringMap.empty);  parent = Some env }*)
  | Id id -> 
		  let newMap = empty_map() in 
			(Hashtbl.add newMap id value;
			{values = newMap; parent = Some env})
	| _ -> raise (EvalError "let-expression cannot bind value to a non-identifier");;

let rec lookup id env = 
	try 
		(*StringMap.find id env.values  *)
		Hashtbl.find env.values id
  with _ -> 
			(match env.parent with 
				| Some parent -> lookup id parent
			  | None -> raise (BindingNotFound id));;
