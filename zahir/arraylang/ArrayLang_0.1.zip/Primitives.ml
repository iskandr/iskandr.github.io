open Environment;;
open Interpreter;;

let _ = float_prim "cos" cos;
		    float_prim "sin" sin;
			  float_prim "tan" tan;
			  float_prim "abs" abs_float;
			  float_prim "log" log;
			  float_prim "log10" log10;
			  float_prim "sqrt" sqrt;
			  float_prim "exp" exp;
			  string_to_void_prim "load" interp_file;; 

