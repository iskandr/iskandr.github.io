open Base;;
open Printf;;


let dims data = Array.length data, Array.length data.(0);;



let rec array_access arr  args = match arr,args with 
	| ArrayVal(data), [NumVal rowIdx; NumVal colIdx] -> 
		 	let rawRowIdx = int_of_float rowIdx in 
			let rawColIdx = int_of_float colIdx in 
			let rows, cols = dims data in 
				if rawRowIdx <= rows && rawColIdx <= cols && rawRowIdx > 0 && rawColIdx > 0 then 
					data.(rawRowIdx-1).(rawColIdx-1)
				else if  (-rawRowIdx) <= rows && rawColIdx <= cols && rawRowIdx < 0 && rawColIdx > 0 then 
					data.(rows + rawRowIdx).(rawColIdx)
				else if  (rawRowIdx) <= rows && (-rawColIdx) <= -cols && rawRowIdx > 0 && rawColIdx < 0 then 
					data.(rawRowIdx).(rawColIdx + cols)
				else if  (-rawRowIdx) <= rows && (-rawColIdx) <= -cols && rawRowIdx < 0 && rawColIdx < 0 then 
					data.(rawRowIdx+rows).(rawColIdx + cols)
				else raise (EvalError "Index out of bounds")
	| RowVal(data), [NumVal rawIdx] 
	| ColVal(data), [NumVal rawIdx] -> 
			let idx = int_of_float rawIdx in 
			let elts = Array.length data in 
			if idx > 0  && idx <= elts then data.(idx-1)
			else if idx < 0  && (-idx) <= elts then data.(elts + idx)
			else raise (EvalError "Index out of bounds")
	| _ ,_-> raise (EvalError "Wrong index arguments");;

(*
let get_shape vals = 
	let shape_list = List.map (function ArrayVal (d, _) -> d | _ -> [| |]) vals in
  let shape = 
		match shape_list with  
	   d::ds -> d 
		| [] -> raise (EvalError "Empty arrays not supported") 
	in if all_same shape_list then shape 
	else raise (EvalError "Ragged arrays not supported");;
*)
(*
let build_array contents = 
	  let subshape = get_shape contents in 
		if Array.length subshape == 0 then 
			RowVal (Array.of_list contents) 
		else
			ArrayVal (Array.append [| List.length contents |] subshape, Array.of_list contents);;
	*)
		
let eval_concat n1 n2 = 
	match n1, n2 with 
	| ArrayVal( arr1), ArrayVal( arr2) -> 
				ArrayVal (Array.append arr1 arr2)
	| RowVal r1, RowVal r2 -> 
				RowVal (Array.append r1 r2)
  | _ -> raise (EvalError "Cannot concatenate non-array");;

let eval_range left right stride =
		match left, right, stride with 
		| (NumVal leftVal, NumVal rightVal, NumVal strideVal) -> 
			let size = int_of_float ((rightVal -. leftVal) /. strideVal) + 1 in 
				if size < 1 then raise (EvalError "Range of negative size")
				else 
					let resultArray  = Array.make size Nil in 
					let comp = if leftVal < rightVal then (<=) else (>=) in 
					let counter, currVal = ref 0, ref leftVal in 
					while comp !currVal rightVal do
						resultArray.(!counter) <- NumVal (!currVal); 
						currVal := !currVal +. strideVal;
						counter := !counter + 1
					done;
					let len = !counter in 
					if len < 1 then raise (EvalError "Cannot evaluate empty range") else
					let slice =  Array.sub resultArray 0 len   in 
				  RowVal(slice)
			| _ -> raise (EvalError "Range bounds must be numerical");;

