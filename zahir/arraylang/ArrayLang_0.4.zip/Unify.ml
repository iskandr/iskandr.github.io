open Map;;
open Printf;;

open Base;;
open ToString;;

 module TypeID = struct
      type t = type_id
      let compare (x: type_id) y =
          if x < y then -1 else if x > y then  1 else 0
 end;;

module TypeIdMap = Map.Make(TypeID);;
type substitution = (type_expr TypeIdMap.t);;

let print_map map = 
	print_string "{ ";
	let aux key value =  printf "%d => %s, " key (type_to_str value) in 
	TypeIdMap.iter aux map;
	print_string  " } \n";;

let replace_var v subs = 
	try
		TypeIdMap.find v subs
	with 
		| _ -> TyVar v;;

let rec apply_sub theta t = match t with 
 |  TyVar v -> replace_var v theta
 |  TyTuple ts -> TyTuple (Array.map (apply_sub theta) ts)
 |  TyList t' -> TyList (apply_sub theta t')
 |  TyRow t' -> TyRow (apply_sub theta t')
 |  TyCol t' -> TyCol (apply_sub theta t')
 |  TyMat t' -> TyMat (apply_sub theta t') 
 |  TyFn (t1, t2) -> TyFn ( (apply_sub theta t1), (apply_sub theta t2))
 |  TyOverload overloads ->  TyOverload (List.map (apply_sub theta) overloads)
 |   _ -> t;;

let rec substitute v newtype t  = match t with 
 | (TyVar q) -> if v = q then newtype else (TyVar q)
 |  TyFn(targ, treturn) -> TyFn( (substitute v newtype targ), (substitute v newtype treturn))
 |  TyOverload overloads ->  TyOverload (List.map (substitute v newtype) overloads)
 |  TyTuple ts -> TyTuple (Array.map (substitute v newtype) ts)
 |  TyList t' -> TyList (substitute v newtype t')
 |  TyRow t'-> TyRow (substitute v newtype t')
 |  TyCol t' -> TyCol (substitute v newtype t')  
 |  TyMat t' -> TyMat (substitute v newtype t')
 |  _ ->  t;;


let rec member v t = match t with 
 | TyVar w -> v = w 
 | TyFn(p,q)-> member v p ||  member v q
 | TyList t' ->  member v t'
 | TyMat t' -> member v t' 
 | TyRow t' -> member v t'
 | TyCol t' -> member v t'
 | TyOverload overloads -> List.exists (member v) overloads
 | TyTuple ts -> Array.fold_left (fun b t' -> b || (member v t')) false ts 
 | _  -> false;;

exception Unify_Failure;;

let rec unify pairs theta = match pairs with 
	| [] -> theta 
	| (t1, t2)::rest -> 
			(
				match t1,t2 with 
  			| (TyVar v, exp)  ->
						(
							match exp with 
								| TyVar v' -> if v = v' then unify rest theta 
															else 
															let theta' = 
																if TypeIdMap.mem v theta 
																then TypeIdMap.add v' (TypeIdMap.find v theta) theta 
																else TypeIdMap.add v (TyVar v') theta
															in  unify rest theta'
								| _ -> 
     								if member v exp then  raise Unify_Failure else 
										let theta', texp = 
											if TypeIdMap.mem v theta then 
												let theta'' = unify [(TypeIdMap.find v theta, exp)] theta in 
												theta'', apply_sub theta'' exp 
											else theta, exp 
										in 	
										let new_rest = List.map (fun (l,r) -> (substitute v texp l, substitute v texp r)) rest in 
       							let new_theta = TypeIdMap.map (fun def -> substitute v texp def) theta' in 
			 							let new_theta2 = TypeIdMap.add v texp new_theta in 
										(*(
										printf "Unifying %d, %s" v (type_to_str exp); 
										print_map new_theta2; *)
						 				unify new_rest new_theta2
										
							)
  			| (exp, (TyVar v))  -> unify (((TyVar v),exp )::rest) theta
  			| TyFn(arg1, ret1), TyFn(arg2, ret2) -> 
						unify ((arg1,arg2)::(ret1,ret2)::rest) theta
  			| TyList eltT1, TyList eltT2 -> unify ((eltT1,eltT2)::rest) theta
  			| TyRow eltT1, TyRow eltT2 -> unify ((eltT1,eltT2)::rest) theta
  			| TyCol eltT1, TyCol eltT2 -> unify ((eltT1,eltT2)::rest) theta
  			| TyMat eltT1, TyMat eltT2 -> unify ((eltT1,eltT2)::rest) theta
				| TyTuple x, TyTuple y -> 
					if (Array.length x) <> (Array.length y) then 
						raise Unify_Failure
					else begin
						let aux acc_theta xt yt = unify [(xt, yt)] acc_theta in 
						let theta' = List.fold_left2 aux theta (Array.to_list x) (Array.to_list y) in 
					 	unify rest theta'
					end
			| (TyOverload _), (TyOverload _)  ->  raise Unify_Failure
			| (TyOverload []), _ -> raise Unify_Failure
			| (TyOverload (alt::others)), exp -> 
				(
					try 
						unify ((alt, exp)::rest) theta 
					with  _ -> unify (((TyOverload others), exp)::rest) theta
				)	
			| single, TyOverload ts -> unify ((TyOverload ts, single)::rest) theta 
			| _,_ ->
						if t1 = t2  then unify rest theta else raise Unify_Failure
		
				);;


