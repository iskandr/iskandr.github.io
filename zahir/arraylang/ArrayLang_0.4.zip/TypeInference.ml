
open Map;;
open Hashtbl;;
open Printf;;

open Base;;
open ToString;;
open Unify;;

open TypeEnvironment;;

exception StaticError of string;;
exception IdentifierExpected;;
exception ArgumentMismatch of node * type_expr * type_expr;;
exception InvalidIndex of node * type_expr;;
exception OverloadFailure of node * type_expr list * type_expr;;

let replace_data node new_data =  {id=node.id; data=new_data; line=node.line; col=node.col; t=node.t}

(* recursively replace generic type variables in type expression with fresh type variables *)
let replace_gens t non_gens = 
	let replaced = Hashtbl.create 127 in 
	let rec aux t = 
			match t with
				| TyList t' -> TyList (aux t') 
				| TyRow t' ->  TyRow (aux t')
				| TyCol t' -> TyCol (aux t')
				| TyMat t' -> TyMat (aux t')
				| TyTuple ts -> TyTuple (Array.map aux ts)
				| TyVar id ->
					if List.mem id non_gens then t
					else 
						if Hashtbl.mem replaced id then  
							(
						(*		printf "already replaced %d with %d \n" id (Hashtbl.find replaced id);*)
								TyVar (Hashtbl.find replaced id)
							)
						else 
							let id' = fresh_type_id() in 
					(*		  printf "replacing %d with %d \n" id id';*)
								Hashtbl.replace replaced id id'; 
								TyVar id'
				| TyFn (argT, resT) -> 
						let t1 = aux argT in 
						let t2= aux resT in 
						TyFn (t1, t2) 
				| _ -> t
	in aux t;;

let replace_contained container newT = 
		match container with 
			| TyList t -> TyList newT
    	| TyRow t -> TyRow newT
			| TyCol t -> TyCol newT
			| TyMat t -> TyMat newT
			| _ -> TyVoid;;


exception Type_Error of Base.node * string;;

let rec type_check node (theta:substitution) (tenv:type_environment) (non_gens : type_id list)  = 
	let resultT, resultTheta = match node.data with 
		| FloatLiteral _ -> TyNum, theta
		| StringLiteral _ -> TyString, theta
	  | BoolLiteral _ -> TyBool,theta 
    | VoidExpression -> TyVoid, theta
		| Program body -> type_check body theta tenv non_gens 
		| Id name -> check_id name theta tenv non_gens
    | ListExpression items -> check_list node theta tenv non_gens items
    | ArrayExpression items -> check_array node theta tenv non_gens items
	  | IfExpr(test, conseq) -> check_if theta tenv non_gens test conseq			
    | IfElseExpr(test, conseq, alt)-> check_ifelse theta tenv non_gens test conseq alt
	  | LambdaExpression(args, body)-> check_lambda args body theta tenv non_gens 
		| FunctionReference(fn, args) -> check_funcall theta tenv non_gens fn args
		| BlockExpression items -> check_block node theta tenv non_gens items
		| FunctionDefinition (name, args, body)-> check_fundef theta tenv non_gens name args body 				
		| LetExpr(pat, value, body) -> check_let theta tenv non_gens pat value body
	  | DefineExpression(pat, value) -> check_letdef theta tenv non_gens pat value 
		| TupleExpression nodes ->  check_tuple theta tenv non_gens nodes 
		| RangeExpression(lower, upper, step) -> check_range node theta tenv non_gens lower upper step
	  | TransposeExpression item -> check_transpose theta tenv non_gens item 	
		| ConcatExpression(lhs, rhs) -> check_concat theta tenv non_gens lhs rhs
		| UnaryExpression(op, arg) -> check_unop theta tenv non_gens op arg
		| BinaryExpression(op, arg1, arg2) -> check_binop theta tenv non_gens op arg1 arg2
		| ForExpression(pat, value, body) -> check_for theta tenv non_gens pat value body
		| _ -> raise (StaticError "Not yet implemented in type checker")
	in node.t <- resultT; resultT, resultTheta


	and	 folder tenv non_gens (types, theta_acc) arg = 
		let t, new_theta = type_check arg theta_acc tenv non_gens  in t::types, new_theta

	and check_lambda args body theta tenv non_gens = 
		let ids = List.map (fun _ -> fresh_type_id ()) args in
		let typevars =  List.map (fun id -> TyVar id) ids in  
		let new_env = new_type_env tenv (List.length typevars) in 
		List.iter2 (set_type_binding new_env) args typevars;
		let new_non_gens = ids @ non_gens in 
		let body_type, theta' = type_check body theta new_env new_non_gens in
		let body_type' = apply_sub theta' body_type in  
		let arg_types = List.map (apply_sub theta') typevars in 
		let arg_types' = 
			match arg_types with
			| [] -> TyVoid 
			| t::[] -> t
			| ts -> TyTuple (Array.of_list  ts)
		in TyFn(arg_types',  body_type'), theta'
	
	and  check_id name theta tenv  non_gens  = 
			  let t = 
					try lookup_type name tenv 
					with _ -> raise (StaticError ("Undeclared variable " ^ name))	
				in let t2 = apply_sub theta t 
				in replace_gens t2 non_gens, theta
	
	and check_list node theta tenv non_gens = function  
    |  [] -> let id = fresh_type_id () in TyList (TyVar id), theta
	  |  e1::rest ->
				let t1, theta1 = (type_check (replace_data node (ListExpression rest)) theta tenv non_gens) in 
				let t2, theta2 = (type_check e1 theta1 tenv non_gens)  in
				let t2list = TyList t2  in
				let t1' = (apply_sub theta2 t1)  in
				let theta3 = 
			 		try unify [(t1', t2list)] theta2 
			 		with Unify_Failure -> raise (Type_Error (e1, "Mismatching types in list"))
				in apply_sub theta3 t2list, theta3
				
	and check_array node theta tenv non_gens = function
	 | [] -> let id = fresh_type_id () in TyRow (TyVar id), theta
	 | e1::rest ->
			let t1, theta1 = (type_check (replace_data node (ArrayExpression rest)) theta tenv non_gens) in 
			let t2, theta2 = (type_check e1 theta1 tenv non_gens)  in
			let t2row = TyRow t2  in
			let t1' = (apply_sub theta2 t1)  in
			let theta3 = 
				try unify [(t1', t2row)] theta2 
				with Unify_Failure -> raise (Type_Error (e1, "Mismatching types in array")) in  
			apply_sub theta3 t2row, theta3

	and check_if theta tenv non_gens test conseq = 
		  let t1, theta1 = (type_check test theta tenv non_gens) in
			let theta2 = 
				try unify [(t1, TyBool)] theta1 
			  with Unify_Failure -> raise (Type_Error (test, "Condition must be of type bool")) in
			let t2, theta3 = type_check conseq theta2 tenv non_gens in
			let t2' = apply_sub theta3 t2 in
			t2', theta3
	
	and check_ifelse theta tenv non_gens test conseq alt = 
		let t1, theta1 = type_check test theta tenv non_gens in
		let theta2 = 
			try unify [(t1, TyBool)] theta1  
			with Unify_Failure -> raise (Type_Error (test, "Condition must be of type bool")) in
		let t2, theta3 = type_check conseq theta2 tenv non_gens in
		let t3, theta4 = type_check alt theta3 tenv non_gens in
		let t2' = apply_sub theta4 t2 in
		let theta5 = 
			try unify [(t2', t3)] theta4
			with Unify_Failure -> raise (Type_Error (conseq, "Both branches of if statement must be of same type")) in 
		let t3' = apply_sub theta4 t3 in
	  t3', theta5
	
	and check_funcall theta tenv non_gens fn args = 
		let funtype,theta1 = type_check fn theta tenv non_gens in 
		let (arg_types,theta2) = List.fold_left (folder tenv non_gens) ([], theta1) (List.rev args) in 
		let funtype2 = apply_sub theta2 funtype in
	  let used_args = match arg_types with
			| [] -> TyVoid 
			| t1::[] -> t1
			| ts -> TyTuple(Array.of_list ts) 
		in 
		check_funref theta2 fn funtype2 used_args
	
	and check_funref theta fNode ftype used_args =
	match ftype with
		  | TyFn(actual_args, actual_return) -> 
				let result_type = TyVar (fresh_type_id()) in 
				let usage_type = TyFn(used_args, result_type) in
				let theta' = 
					try unify [ (ftype, usage_type) ] theta
					with Unify_Failure -> raise (ArgumentMismatch (fNode, actual_args, used_args))
				in apply_sub theta' result_type, theta'
		  | TyVar id -> 
					let result_type = TyVar (fresh_type_id()) in 
					let usage_type = TyFn(used_args, result_type) in   (* figure out how to allow array access *)
					let theta' = unify [(ftype, usage_type)] theta in 
					apply_sub theta' result_type, theta' 
		  | TyRow eltT
			| TyCol eltT -> 
				 let theta' = 
					try unify[(used_args, TyNum)] theta 
					with Unify_Failure -> raise (InvalidIndex (fNode, used_args))
				in apply_sub theta' eltT, theta'	
		  | TyOverload overloads -> 
				(* iterate through list of overloaded function types *)
				(* by folding with an option accumulator.*)
				(* The first function type to unify with the args is returns as Some(ftype) *)
				(* If at the end of the fold we still have None, then there is no valid overload *)
					let aux acc f =
						(match acc with 
							| None ->  
									(try Some(check_funref theta fNode f used_args) with _ -> None)
							| _ -> acc) 
					in (
							match List.fold_left aux None overloads with 
						 	| Some (resultT, resultTheta) -> resultT, resultTheta
							| _ -> raise (OverloadFailure (fNode, overloads, used_args))
							) 
		 	| _ -> raise (Type_Error (fNode, "Object is neither a function nor an indexable container"))
		
		
and check_block node theta tenv non_gens = function 
	| []  -> TyVoid, theta
	| n::[] ->  type_check n theta tenv non_gens 
	| n::ns -> 
		let rest = replace_data node (BlockExpression ns) in 
		let node_type, theta1 = type_check n theta tenv non_gens  in 
		let trest, theta2 =  type_check rest theta1 tenv non_gens in 
		let node_type' = apply_sub theta2 node_type in 
		let theta3 = unify [(node_type', TyVoid)] theta2 in 
		apply_sub theta3 trest, theta3

and check_fundef theta tenv non_gens name args body = 
	    let new_ids = List.map (fun a -> fresh_type_id()) args in 
			let new_typevars = List.map (fun id -> TyVar id) new_ids in 
		  let unknown_args = 
				match new_typevars with 
						| [] -> TyVoid 
						| tv::[] -> tv
						| _ -> TyTuple (Array.of_list (new_typevars)) in 
			let unknown_result = TyVar (fresh_type_id()) in
			let unknown_function = TyFn(unknown_args, unknown_result) in 
			set_type_binding tenv name unknown_function;
			let non_gens' = new_ids @ non_gens in
			let t', theta' = check_lambda args body theta tenv non_gens' in 
			let theta'' = unify [(unknown_function, t')] theta' in 
			let t'' = apply_sub theta'' t' in 
			set_type_binding tenv name t'';
			TyVoid, theta''

and check_let theta tenv non_gens pat value body = 
	let new_env = new_type_env tenv 7 in
	let valType, valTheta = type_check value theta new_env non_gens in 
	let theta' = check_pat theta new_env  pat valType in 
	let tbody, theta_body = type_check body theta' new_env non_gens in 
	tbody, theta_body

(* let without a body adds binding to global env *)
and check_letdef theta tenv non_gens pat value = 
	let valType, valTheta = type_check value theta tenv non_gens in 
	let theta' = check_pat theta tenv  pat valType in 
	TyVoid, theta'


and check_pat theta new_env pat valType  = 
		match pat with 
		| IdPattern name -> 
				set_type_binding new_env name valType;
				theta
		| WildcardPattern -> theta
		| TuplePattern ps ->
			   let tvars = Array.map (fun p -> TyVar (fresh_type_id() )) ps in 
				 let theta' = 
						try
							unify [(TyTuple tvars, valType)] theta 
						with _ -> 
							raise (StaticError ("Failed to match tuple pattern (" ^ (pattern_to_string pat) ^ ") against " ^ (type_to_str  valType)))
				 in 
				 let valType' = apply_sub theta' valType in 
				 (match valType' with 
						| TyTuple ts -> 
								let aux acc p t = check_pat acc new_env p t in 
								List.fold_left2 aux theta' (Array.to_list ps) (Array.to_list ts)
					  | _ -> raise (StaticError "Mysterious error in pattern matching"))   
		| ArrayPattern ps -> raise (StaticError "Array patterns not yet supported in type checker")
		| ListPattern  (ps, whyIsThisStringHere) ->
				 raise (StaticError "List patterns not yet supported in type checker")
	   
	(* call type_check on def in an environment in which name is
			bound to a new type variable v. Since v must be non-generic,
			include v in the actual parameter for non-gens. Then call
			type_check on rest. Since name can be used polymorphically
			in rest and body, do not include v in the non-gens parameter
			when type checking rest and body. *)

(*WildcardPattern 
               | IdPattern of string 
							 | TuplePattern of pattern array
							 | ArrayPattern of pattern array
							 | ListPattern of pattern array * string option;; 
*)


and check_tuple theta tenv non_gens nodes = 
	let node_types, theta' = List.fold_left (folder tenv non_gens) ([], theta) nodes in
	let node_types' = List.map (apply_sub theta') node_types in 
	let t' = 
		match node_types' with 
		| [] -> TyVoid
		| n::[] -> n
		| _ ->  (TyTuple (Array.of_list node_types'))
	in t', theta'

and  check_range node theta tenv non_gens lower upper step =
				let t_lower, theta1= type_check lower theta tenv non_gens in
				let t_upper, theta2 = type_check upper theta1 tenv non_gens in 
				let t_step, theta3 = type_check step theta2 tenv non_gens in 
				let t_lower' = apply_sub theta3 t_lower in 
				let t_upper' = apply_sub theta3 t_upper in 
				let theta4 = 
					try unify [(t_lower', t_upper'); (t_lower', t_step)] theta3
					with Unify_Failure -> raise (Type_Error (node, "Type mismatch in range expression"))
		 		in 
				let t_step' = apply_sub theta4 t_step in 
				TyRow (t_step'), theta4		

and check_transpose theta tenv non_gens node = 
		let t, theta' = type_check node theta tenv non_gens in 
		let newT = match t with 
	   | TyRow t' -> TyCol t'
		 | TyCol t' -> TyRow t' 
		 | TyMat t' -> TyMat t'
		 | TyNum -> TyNum
		 | _ -> raise (StaticError ("Cannot apply transpose operator to type " ^ (type_to_str t)))
	  in newT, theta'

and check_unop theta tenv non_gens op arg = 
		let funT = lookup_type (unop_id op) tenv in 
		let argT, theta' = type_check arg theta tenv non_gens in 
		let result_type = TyVar (fresh_type_id()) in 
		let usage_type = TyFn(argT, result_type) in
		let theta'' = 
			try unify [ (funT, usage_type) ] theta'
			with Unify_Failure -> 
					raise  (Type_Error (arg, ("Wrong argument type for unop " ^ (unop_to_string op))))
		in apply_sub theta'' result_type, theta''
		
and check_binop theta tenv non_gens op arg1 arg2 = 
		let funT = lookup_type (binop_id op) tenv in 
		let arg1T, theta1 = type_check arg1 theta tenv non_gens in 
		let arg2T, theta2 = type_check arg2 theta1 tenv non_gens in 
		let result_type = TyVar (fresh_type_id()) in 
		let usage_type = TyFn(TyTuple [|arg1T; arg2T|], result_type) in
		let theta3 = 
			try unify [ (funT, usage_type) ] theta2
			with Unify_Failure -> raise (Type_Error (arg1, ("Wrong argument type for binop " ^ (binop_to_string op) )))
		in apply_sub theta3 result_type, theta3

and check_concat theta tenv non_gens lhs rhs = 
	let lhsT, theta1 = type_check lhs theta tenv non_gens in 
  let rhsT, theta2 = type_check rhs theta1 tenv non_gens in
	let newT =  TyVar (fresh_type_id()) in 
	let containerT = TyOverload [TyList newT; TyRow newT; TyCol newT] in 
	let theta3 = 
			try unify [ (lhsT, containerT); (rhsT, containerT); (lhsT, rhsT)] theta2
				with Unify_Failure -> raise (Type_Error (lhs, "Wrong argument type for concat " ))
		in apply_sub theta3 lhsT, theta3
		

and check_for theta tenv non_gens pat value body  = 
	  let new_env = new_type_env tenv 7 in
		let valueT, theta1 = type_check value theta new_env non_gens in 
		let theta2 = 
			match valueT with 
			| TyList t 
    	| TyRow t 
			| TyCol t 
			| TyMat t -> check_pat theta1 new_env pat t
			| _ ->   raise (Type_Error (value, "For expression requires container" ))
		in let tbody, theta_body = type_check body theta2 new_env non_gens in 
		replace_contained valueT tbody, theta_body;;
		
			
			 
 
		
	