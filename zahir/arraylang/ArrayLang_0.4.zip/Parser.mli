type token =
  | NUM of (float)
  | ID of (string)
  | STR of (string)
  | DOT
  | DOTDOT
  | COMMA
  | COLON
  | SEMICOLON
  | DOLLAR
  | BEGIN
  | END
  | LPAREN
  | RPAREN
  | LBRACKET
  | RBRACKET
  | LCURLY
  | RCURLY
  | PLUSPLUS
  | TRANS
  | PLUS
  | MINUS
  | TIMES
  | DIV
  | DOT_TIMES
  | DOT_DIV
  | EQEQ
  | LT
  | LTE
  | GT
  | GTE
  | NEQ
  | TRUE
  | FALSE
  | NOT
  | AND
  | OR
  | AT
  | FN
  | DEF
  | IF
  | THEN
  | ELSE
  | LET
  | EQ
  | IN
  | MATCH
  | WITH
  | ARROW
  | DOUBLE_ARROW
  | UNDERSCORE
  | FOR
  | DO
  | BY
  | WINDOW
  | GENERIC
  | INSTANCE
  | EOF

val program :
  (Lexing.lexbuf  -> token) -> Lexing.lexbuf -> Base.node
