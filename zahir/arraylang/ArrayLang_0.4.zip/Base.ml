
open Map;;
open Hashtbl;;

exception EvalError of string;;
exception MatchFailure of string;;

let uniq lst =
  let unique_set = Hashtbl.create (List.length lst) in
    List.iter (fun x -> Hashtbl.replace unique_set x ()) lst;
    Hashtbl.fold (fun x () xs -> x :: xs) unique_set [];;

let all_same lst = List.length (uniq lst) = 1;; 

let rec eq_array arr1 arr2 idx = 
	if idx >= Array.length arr1 then 
		idx >= Array.length arr2
	else if arr1.(idx) = arr2.(idx) then 
		 eq_array arr1 arr2 (idx+1)
	else false;; 

type unary_op = Not | Pos |  Neg;;
	
type binary_op = Add | AddElts | Sub | SubElts | 
	                 Mult | MultElts | Div | DivElts | 
									 And | Or |  Eq | Gt | Gte | Lt | Lte | Neq;;

type type_id = int;;

let max_type_id = ref 0;;

let fresh_type_id () = 
	let id = !max_type_id in 
	max_type_id := id + 1; 
	id;;

type node = {id:int; data:expr; line:int; col:int; mutable t:type_expr}
and expr = 
		     | Program of node 
				 | FunctionDefinition of string * (string list) * node
	       | GenericExpression of string list 
				 | BlockExpression of node list
		     | LetExpr of pattern * node * node 
				 | IfExpr of node * node 
         | IfElseExpr of node * node * node
         | Id of string
				 | FloatLiteral of float  
         | StringLiteral of string
				 | BoolLiteral of bool
				 | VoidExpression  
         | UnaryExpression of unary_op * node
         | BinaryExpression of binary_op * node * node
				 | DefineExpression of pattern * node  
         | FunctionReference of node * (node list)
				 | LambdaExpression of (string list) * node
				 | ArrayExpression of node list
				 | RangeExpression of node * node * node
				 | TupleExpression of node list
				 | ConcatExpression of node * node 
				 | ForExpression of pattern * node * node 
				 | TransposeExpression of node 
				 | ListExpression  of node list 
(*and obj = {myVal:value; myType:type_expr} *)
and value = Nil
						| Void 
	          | NumVal of float 
						| BoolVal of bool
						| StringVal of string
						| RowVal of value array
						| ColVal of value array
						| ArrayVal of  value array array  (* change to int * int * value array array *)
						| LambdaVal of string list * node  * environment
						| GenericVal of (type_expr, value) Hashtbl.t 
						| ListVal of value list
						| TupleVal of value array
						| Primitive of (value list -> value)
and pattern = WildcardPattern 
               | IdPattern of string 
							 | TuplePattern of pattern array
							 | ArrayPattern of pattern array
							 | ListPattern of pattern array * string option
and type_expr = TyAny
								 | TyVoid
	               | TyNum  
                 | TyString 
								 | TyBool 
                 | TyList of type_expr 
                 | TyRow of type_expr 
								 | TyCol of type_expr 
								 | TyMat of type_expr 
								 | TyTuple of type_expr array 
								 | TyData of type_id 
								 | TyFn of type_expr * type_expr
								 | TyVar of type_id
								 | TyOverload of type_expr list
(*and obj_map = (string, obj) Hashtbl.t*)
and value_map = (string, value) Hashtbl.t
and environment = {values:value_map; parent:environment option};;

type pattern_result = Success of (string * value) list | Failure;; 

(* fresh polymorphic type *)
let poly () = TyVar (fresh_type_id ());;

let node_id = ref 0;;      
  
let makeASTNode (e, l, c) = 
		let i = !node_id in 
			node_id := !node_id + 1; {id=i; data=e; line=l; col=c; t=TyAny};;
