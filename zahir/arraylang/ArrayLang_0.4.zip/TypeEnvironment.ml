open Hashtbl;;

open Base;;

type type_map = (string, type_expr) Hashtbl.t
type type_environment = {types:type_map; parent_type_env:type_environment option}

let set_type_binding e name t  = Hashtbl.replace e.types name t;;

let new_type_env parent size = {types=(Hashtbl.create size); parent_type_env=(Some parent)};; 

exception TypeBindingNotFound of string;;

let rec lookup_type id tenv = 
	try 
		Hashtbl.find tenv.types id
  with _ -> 
			(match tenv.parent_type_env with 
				| Some parent -> lookup_type id parent
			  | None -> raise (TypeBindingNotFound id));;
