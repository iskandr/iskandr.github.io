
open Base;;
open TypeEnvironment;;

open Hashtbl;;
open Printf;;

let set_binding e name value  = Hashtbl.replace e.values name value;;

(* modify current environment with list of id, value pairs *)
let rec modify_env env newBindings =  
	match newBindings with 
	| [] -> () 
	| (name, value)::rest -> 
			set_binding env name value;
			modify_env env rest;;

(* extend environment with list of id, value pairs *)
let extend_env env bindings = 
	match bindings with 
		| [] -> env 
		| _ -> 
			let newHash = Hashtbl.create (List.length bindings) in 
			let newEnv = {values = newHash; parent = Some env} in 
			modify_env newEnv bindings;
			newEnv;;    
      

exception BindingNotFound of string;;

let rec lookup id env = 
	try 
		Hashtbl.find env.values id
  with _ -> 
			(match env.parent with 
				| Some parent -> lookup id parent
			  | None -> raise (BindingNotFound id));;

(*
type type_environment  = { types : ((string, type_expr) Hashtbl.t); parent_type_env: type_environment option};;

let child_type_environment p:type_environment = {types = (empty_hash()); parent_type_env = Some p};;  
let globalTypeEnv = {types = (empty_hash()); parent_type_env = None};;


exception TypeBindingNotFound of string;;
let lookup_type t tenv = 
	try 
		Hashtbl.find tenv.types t
   with _ -> 
			(match tenv.parent_type_env with 
				| Some parent -> lookup_type t parent
			  | None -> raise (TypeBindingNotFound id));;
		
*)

		(*set_binding vEnv.values name value;
	set_binding tEnv.types name t;;
*)

(*
let bindGlobal = bindValue globalEnv globalTypeEnv;;
*)