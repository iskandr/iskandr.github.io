open Base;;
open Lexer;;
open Parser;;
open GlobalEnvironment;;
open PrimDefs;;
open Interpreter;;

open Printf;;


let rec repl () = 		
		print_string ">> ";
		let input = read_line () in 
		if input <> "exit" then 
			let lexbuf = Lexing.from_string input in 
			interp lexbuf globalEnv globalTypeEnv;
		  repl ();;

let main () =	 
	 let len = Array.length Sys.argv in 
	 if len < 2 then 
		  repl ()
	 else let inFile = Sys.argv.(1) in  
	    interp_file inFile globalEnv globalTypeEnv;;
 
let _ = (Printexc.print main ()); print_string "\n";