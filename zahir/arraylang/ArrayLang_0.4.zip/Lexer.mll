{
  open Printf;;
  open Lexing;;
  open Base;;

  open Parser;; 
  
  let incr_lineno lexbuf =
    let pos = lexbuf.lex_curr_p in
    lexbuf.lex_curr_p <- { pos with
      pos_lnum = pos.pos_lnum + 1;
      pos_bol = pos.pos_cnum;
    }
}
let digit = ['0'-'9']
let id = ['a'-'z' 'A'-'Z'] ['a'-'z' '.' 'A'-'Z' '0'-'9' '_' '?' '!']*
let str = '\"' [^ '\"']* '\"'

rule token = parse
  | "+" { PLUS }
  | "-" { MINUS } 
	| "*" { TIMES }
	| ".*" {DOT_TIMES} 
	| "/" {DIV} 
	| "./" {DOT_DIV} 
	| "'" {TRANS}
	| "==" { EQEQ }
  | "~" {NOT}
  | "<" { LT }
  | "<=" { LTE }
  | ">" { GT }
  | ">=" { GTE }
  | "~=" { NEQ }
	| "$" { DOLLAR }
	| "->" {ARROW}
	| "=>" {DOUBLE_ARROW}
	| "_" {UNDERSCORE}
  | "." { DOT }
	| ".." {DOTDOT}
  | "," { COMMA }
  | ":" { COLON }
  | ";" { SEMICOLON }
  | "(" { LPAREN }
  | ")" { RPAREN }
  | "[" { LBRACKET }
  | "]" { RBRACKET }
	| "{" { LCURLY }
	| "}" { RCURLY }
	| "++" {PLUSPLUS }
	| digit+ ('.' digit*)? as fnum { NUM (float_of_string fnum ) }
  | "&&" { AND } 
  | "||" { OR }
	| "@" {AT}
  | "fn" { FN }
	| "begin" {BEGIN} 
  | "end" {END}
	| "def" {DEF}
  | "if" { IF }
 	| "then" {THEN}
  | "else" { ELSE }
	| "true" { TRUE }
	| "false" { FALSE }
	| "let" {LET}
	| "in" {IN}
	| "=" {EQ}  
	| "for" {FOR}
	| "window" {WINDOW}
	| "by" {BY}
	| "do" {DO}
	| "generic" {GENERIC}
  | id as text { ID text }
  | str as text { STR text } 
  | '#' { single_comment lexbuf } (* eats one line *)
	| "#!" { multiline_comment lexbuf }	(* eat multiline comments *)
  | '\n' { incr_lineno lexbuf; token lexbuf }
  | [' ' '\t' ]	{ token lexbuf }	(* eat up whitespace *)
  | eof		{ EOF }
  | _ as c
  	{ printf "Unrecognized character: %c\n" c;
	  token lexbuf
	}
and multiline_comment = parse
  | "!#" { token lexbuf }
	| '\n' { incr_lineno lexbuf; multiline_comment lexbuf } 
  | _  { multiline_comment lexbuf }
and single_comment = parse
  | '\n' {incr_lineno lexbuf ; token lexbuf }
	| _ { single_comment lexbuf }

{

}
