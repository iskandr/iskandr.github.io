del *.cmo
del *.cmi
ocamlyacc Parser.mly
ocamlc -c Base.ml
ocamlc -c ToString.ml
ocamlc -c TypeEnvironment.ml
ocamlc -c Environment.ml
ocamlc -c Unify.ml
ocamlc -c TypeInference.ml
ocamlc -c  Parser.mli
ocamllex lexer.mll
ocamlc -c  lexer.ml
ocamlc -c  Parser.ml

ocamlc -c PrimitiveMath.ml
ocamlc -c EvalArray.ml
ocamlc -c EvalPatterns.ml
ocamlc -c Eval.ml
ocamlc -c GlobalEnvironment.ml
ocamlc -c Primitives.ml
ocamlc -c Interpreter.ml
ocamlc -c PrimDefs.ml
ocamlc -c  Main.ml
ocamlc -o ArrayLang.exe Base.cmo ToString.cmo TypeEnvironment.cmo Environment.cmo  Unify.cmo TypeInference.cmo Parser.cmo lexer.cmo   PrimitiveMath.cmo EvalArray.cmo EvalPatterns.cmo Eval.cmo GlobalEnvironment.cmo Primitives.cmo   Interpreter.cmo PrimDefs.cmo    Main.cmo 