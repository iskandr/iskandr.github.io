open Base;;
open TypeEnvironment;;
open Environment;;

open Printf;;

let globalEnv:environment = { values = ( Hashtbl.create 127); parent = None };;
let globalTypeEnv:type_environment = {types= Hashtbl.create 127; parent_type_env = None};;

let bind_global name v t = 
	set_binding globalEnv name v;
	set_type_binding globalTypeEnv name t;;
