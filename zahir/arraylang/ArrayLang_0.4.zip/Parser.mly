
%{
	open Printf;;
	open Base;;

  let makeNode e = 
		let lexpos = Parsing.symbol_start_pos () in
		let line = lexpos.Lexing.pos_lnum in
		let col = (lexpos.Lexing.pos_cnum - lexpos.Lexing.pos_bol+1) in 
			makeASTNode (e, line, col);;

%}

%token <float> NUM 
%token <string> ID 
%token <string> STR
%token  DOT DOTDOT COMMA COLON SEMICOLON DOLLAR
%token BEGIN END

%token LPAREN RPAREN LBRACKET RBRACKET LCURLY RCURLY
%token PLUSPLUS
%token TRANS 
%token PLUS MINUS TIMES DIV
%token DOT_TIMES DOT_DIV 

/* comparisons */
%token EQEQ LT LTE GT GTE NEQ

/* boolean */
%token TRUE FALSE
%token NOT AND OR

%token AT FN DEF 
%token IF THEN ELSE
%token LET EQ IN

/* pattern matching */
%token MATCH WITH ARROW DOUBLE_ARROW UNDERSCORE

/*for constructors */
%token FOR DO BY WINDOW /*CROSS DOT*/

/* overloading */
%token GENERIC INSTANCE 

%token EOF

%left EQEQ GT GTE LT LTE NEQ 
%left DOLLAR
%left MINUS PLUS OR
%left DOT_TIMES TIMES DOT_DIV DIV MOD AND
%left UMINUS NOT
%left FCALL

%nonassoc THEN 
%nonassoc ELSE
%nonassoc LET

%start program
%type <Base.node> program


/* grammar */
%%


program: 
 			block { makeNode(Program($1)) }
;


block: top_exp rest_of_block { makeNode(BlockExpression($1 :: $2)) }
;

rest_of_block: 
							 { [] } 
         			 |  top_exp rest_of_block { $1 :: $2 }
;

top_exp: 
	declaration optional_delimeter { $1 } 
;


optional_delimeter: 
		SEMICOLON  {}
    | {} 
; 

declaration:
   | function_definition             { $1 }
   | LET pattern EQ exp              { makeNode(DefineExpression($2, $4)) }
	 | exp                             {$1 } 
;

function_definition:
	DEF ID identifier_list EQ exp 
	 { makeNode(FunctionDefinition($2, $3, $5)) }
;

exp:
		 concat_exp rest_of_tuple { makeNode(TupleExpression($1::$2)) }
		/*
      tuple {$1 }
	    | concat_exp { $1 }*/
;

rest_of_tuple: {[]}
							| COMMA concat_exp rest_of_tuple {$2 :: $3}
;

concat_exp:
	range_exp PLUSPLUS concat_exp { makeNode(ConcatExpression($1, $3)) }
	| range_exp {$1}
;				

range_exp:
        for_exp {$1}
        | exp2 COLON exp2 BY exp2 { makeNode(RangeExpression($1, $3, $5)) }
				| exp2 COLON exp2 { makeNode(RangeExpression($1, $3, makeNode(FloatLiteral(1.)))) } 
      	| exp2 { $1 }
;

exp2:   
		  LET pattern EQ exp IN exp           { makeNode(LetExpr($2, $4, $6)) }
			| if_expr                         { $1 }
			| if_else_expr                    { $1 }
      | exp3 { $1 }
;


if_expr : IF exp2 THEN exp  { makeNode(IfExpr($2, $4)) }
;

if_else_expr: IF exp2 THEN exp ELSE exp  { makeNode(IfElseExpr($2, $4, $6)) }            
;


exp3:
			| lambda        { $1 }   
			| generic_exp   { $1 }                    
			| or_expr       { $1 }
;

or_expr:
	or_expr OR and_expr 	{ makeNode(BinaryExpression(Or, $1, $3)) }
	| and_expr {$1}
;

and_expr:
	| and_expr AND not_expr 				{ makeNode(BinaryExpression(And, $1, $3)) }
	| not_expr {$1}
;

not_expr:
 			| NOT relational									{ makeNode(UnaryExpression(Not, $2)) }
			| relational {$1}
;
relational:
	 				| relational EQEQ term 									  { makeNode(BinaryExpression(Eq, $1, $3)) }
	 				| relational GT term 											{ makeNode(BinaryExpression(Gt, $1, $3)) }
	 				| relational GTE term 										{ makeNode(BinaryExpression(Gte, $1, $3)) }
	 				| relational LT term											{ makeNode(BinaryExpression(Lt, $1, $3)) }
	 				| relational LTE term 										{ makeNode(BinaryExpression(Lte, $1, $3)) }
	 				| relational NEQ term 										{ makeNode(BinaryExpression(Neq, $1, $3)) }
					| term { $1 }
;
term:
	  	term PLUS factor					{ makeNode(BinaryExpression(Add, $1, $3)) }
			| term MINUS factor				{ makeNode(BinaryExpression(Sub, $1,  $3)) } 
		  | MINUS term %prec UMINUS  { makeNode(UnaryExpression(Neg, $2)) } 
			| factor                          {$1 }
;

factor:
          postfix   { $1 } 
				 	| factor TIMES postfix				{ makeNode(BinaryExpression(Mult, $1, $3)) }
					| factor DOT_TIMES postfix		{ makeNode(BinaryExpression(MultElts, $1, $3)) } 
				  | factor DIV postfix					{ makeNode(BinaryExpression(Div, $1, $3)) }
					| factor DOT_DIV postfix     { makeNode(BinaryExpression(DivElts, $1, $3)) }  	
;

postfix:
		      | fcall TRANS { makeNode(TransposeExpression($1)) }
					| fcall {$1} 

;
fcall: 
					| function_reference %prec FCALL  { $1 } 
					| atom                            { $1 }
;

atom:
          constant                          { $1 }
				  | STR 													  { makeNode(StringLiteral($1)) } 
					| variable											  { $1 }
					| LPAREN RPAREN                   { makeNode(VoidExpression) }
				  | LPAREN exp RPAREN								{ $2 } 
					| BEGIN block END                 { $2 }
					| array                           { $1 }
					| list                            { $1 }
;

constant: 		
				NUM														      { makeNode(FloatLiteral($1)) }
				| TRUE                              { makeNode(BoolLiteral(true)) } 
				| FALSE                             { makeNode(BoolLiteral(false)) }
;

variable: identifier  { $1 }
/*        | identifier DOT identifier { makeNode(NamespaceLookup($1, $3)) } */
;






lambda:  AT identifier_list exp  { makeNode(LambdaExpression($2, $3)) }
;

/* shouldn't be restricted to identifiers, should also allow lambdas and function calls */
generic_exp:  GENERIC identifier_list { makeNode(GenericExpression($2)) }
;


identifier_list: 
   LPAREN RPAREN { [] } 
	| LPAREN ID rest_of_identifier_list { $2::$3 }
;

rest_of_identifier_list: 	
              RPAREN  { [] }
							| COMMA ID rest_of_identifier_list	{ $2::$3 }
;


identifier: 
			ID													{ makeNode(Id($1)) }
;

function_reference: variable actual_parameter_list  { makeNode(FunctionReference($1, $2)) }
							      | function_reference actual_parameter_list { makeNode(FunctionReference($1, $2)) }
										| lambda actual_parameter_list { makeNode(FunctionReference($1, $2)) }
										| LPAREN exp RPAREN actual_parameter_list { makeNode(FunctionReference($2, $4)) } 
;

actual_parameter_list: 
            LPAREN RPAREN { [] }
						|  LPAREN concat_exp rest_of_actual_parameter_list							{ $2 :: $3 }
;

rest_of_actual_parameter_list: 											
                RPAREN { [] }
								| COMMA concat_exp rest_of_actual_parameter_list		{ $2 :: $3 }
;


array: LBRACKET exp rest_of_array						{ makeNode(ArrayExpression ($2 :: $3)) }
;

rest_of_array: 	RBRACKET 											{ [] }
  /*            | COMMA concat_exp rest_of_array {$2::$3}  */
								|   exp rest_of_array 		{ $1 :: $2 }
;



list: LCURLY concat_exp rest_of_list						{ makeNode(ListExpression ($2 :: $3)) }
		  | LCURLY RCURLY                           { makeNode(ListExpression([])) }
;

rest_of_list: 	RCURLY										{ [] }
                | COMMA concat_exp rest_of_list {$2::$3}  
;


for_exp: | FOR pattern IN exp DO exp  { makeNode(ForExpression($2, $4, $6)) }
;

/*
for_window_exp:
	  FOR WINDOW pattern IN exp DO exp { makeNode(ForWindowExpression($3, $5, $7)) }
; 
*/

pattern:   tuple_pattern { $1 }
	         | container_pattern { $1 }
;


tuple_pattern:  container_pattern COMMA container_pattern rest_of_tuple_pattern  { TuplePattern(Array.of_list ($1::$3::$4)) }
;

rest_of_tuple_pattern: 
                       {[]}
                       | COMMA container_pattern rest_of_tuple_pattern  { $2::$3 }
;

container_pattern: 
				list_pattern {$1 } 
				| array_pattern {$1} 
        | atom_pattern {$1} 
;

array_pattern:
	| LBRACKET pattern rest_of_array_pattern { ArrayPattern(Array.of_list ($2::$3)) }
;

rest_of_array_pattern:
       RBRACKET { [] }
			 | pattern rest_of_array_pattern { $1::$2 } 
;

list_pattern:
			| LCURLY container_pattern rest_of_list_pattern RCURLY
				    { ListPattern(Array.of_list ($2::$3), None)  }
			| LCURLY container_pattern rest_of_list_pattern DOTDOT ID RCURLY
			       { ListPattern(Array.of_list ($2::$3), Some($5)) }
;				
rest_of_list_pattern: 
                       {[]}
                       | COMMA container_pattern rest_of_list_pattern  { $2::$3 }
;


atom_pattern: id_pattern { $1 }
          | LPAREN pattern RPAREN { $2 }
				  | wildcard {$1}
;

wildcard: UNDERSCORE { WildcardPattern } 
;

id_pattern: ID { IdPattern($1) }
;

%%
