open Base;;
open ToString;;

let rec match_pattern pat value = 
	match pat, value with
		| _, Void -> Failure 
		| WildcardPattern, _ -> Success []
		| IdPattern name, _ -> Success [name, value]
		| TuplePattern ps, TupleVal vs -> 
			   match_arrays ps vs
		| TuplePattern _, _ -> Failure
		| ArrayPattern ps, RowVal(data) ->
			   match_arrays ps data
		| ArrayPattern _, _ -> Failure
		| ListPattern (ps, rest), ListVal data ->
		 		match_arrays ps (Array.of_list data)
		| ListPattern _, _ -> Failure	   
and match_arrays ps vs = 
	if Array.length ps <> Array.length vs then Failure else
		let result = List.map2 match_pattern (Array.to_list ps) (Array.to_list vs) in 
			if List.exists (fun x -> match x with Failure -> true | _ -> false) result then 
			   Failure
		  else let hoisted = 
				 List.map (fun x -> match x with Failure -> [] | Success xs -> xs) result 
			in  Success (List.flatten hoisted);;

let rec get_nil_bindings pat = 
	match pat with
		| IdPattern name  ->  [name, Nil]
		| TuplePattern ps -> List.flatten (Array.to_list (Array.map get_nil_bindings ps))
		| ArrayPattern ps -> List.flatten (Array.to_list (Array.map get_nil_bindings ps))
    | _ -> [];;

let get_bindings pat value =
	match match_pattern pat value with 
	| Failure -> 
		 let msg = "Failed to match pattern " ^ (pattern_to_string pat) ^ 
		           " with " ^ (value_to_string value) 
		 in raise (MatchFailure msg)
  | Success bindings -> bindings;;
