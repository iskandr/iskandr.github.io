open Printf;;

open Base;;
open ToString;;

exception InvalidUnop of unary_op;;
exception InvalidBinop of binary_op;;

let transpose value = 
	match value with 
		| RowVal v -> ColVal v
		| ColVal v -> RowVal v
		| ArrayVal (shape, data) as a -> a
		| _ -> raise (EvalError "Transpose doesn't work for this type") ;; 

let eval_unop op arg = 
	match (op, arg) with 
		(Not, BoolVal b) -> BoolVal (not b)
		| (Pos, NumVal num)-> NumVal num
		| (Neg, NumVal num) -> NumVal (-. num)
		| _ -> raise (InvalidUnop op);;

let rec eval_binop op arg1 arg2 = 
	match (op, arg1, arg2) with 
		      (* scalar ops *)
					| (Add, NumVal num1, NumVal num2) -> NumVal(num1 +. num2) 
					| (Sub, NumVal num1, NumVal num2) -> NumVal(num1 -. num2)
					| (Mult, NumVal num1, NumVal num2) -> NumVal (num1 *. num2) 
					| (MultElts, NumVal num1, NumVal num2) -> NumVal(num1 *. num2) 
					| (Div, NumVal num1, NumVal num2) -> NumVal(num1 /. num2)  
					| (DivElts, NumVal num1, NumVal num2) -> NumVal (num1 /. num2)
					(* scalar comparison *)
					| (Gt, NumVal num1, NumVal num2) -> BoolVal(num1 > num2) 
					| (Gte, NumVal num1, NumVal num2) -> BoolVal(num1 >= num2)  
					| (Lt, NumVal num1, NumVal num2) -> BoolVal(num1 < num2)  
					| (Lte, NumVal num1, NumVal num2) -> BoolVal(num1 <= num2) 
					(* homogenous vector ops *)
					| Add, (RowVal row1), (RowVal row2) -> 
							RowVal (vec_op Add row1 row2)
					| Sub, (RowVal row1), (RowVal row2) -> 
							RowVal (vec_op Sub row1 row2)
					| Add, (ColVal col1), (ColVal col2) -> 
							ColVal (vec_op Add col1 col2)
					| Sub, (ColVal col1), (ColVal col2) -> 
							ColVal (vec_op Sub col1 col2)
					| MultElts, (RowVal row1), (RowVal row2) -> 
							RowVal (vec_op MultElts row1 row2)
					| DivElts, (RowVal row1), (RowVal row2) -> 
							RowVal(vec_op DivElts row1 row2)
					| MultElts, (ColVal col1), (ColVal col2) -> 
							ColVal (vec_op Add col1 col2)
					| DivElts, (ColVal col1), (ColVal col2) -> 
							ColVal(vec_op Add col1 col2)
					(* mixed vector ops *)
					| Mult, (RowVal row), (ColVal col) -> 
							inner_product row col
					| Mult, (ColVal col), (RowVal row) -> 
						  outer_product col row

					(* matrix ops *)
					| Add, (ArrayVal (shape1, array1) as a1), (ArrayVal(shape2, array2)as a2) -> 
							array_op Add a1 a2
	(*				| Add, NumVal num, (ArrayVal(shape, array2)as arr) 
					| Add, (ArrayVal(shape, array2)as arr), NumVal num  -> 
							array_scalar_op Add num arr*)
					| Sub, (ArrayVal (shape1, array1) as a1), (ArrayVal(shape2, array2)as a2) -> 
						  array_op Sub a1 a2
					| Mult, (ArrayVal (shape1, array1) as a1), (ArrayVal(shape2, array2) as a2)->
						  array_op Mult a1 a2
					| MultElts, (ArrayVal (shape1, array1) as a1), (ArrayVal(shape2, array2)as a2) -> 
						  array_op MultElts a1 a2
					| Div, (ArrayVal (shape1, array1) as a1), (ArrayVal(shape2, array2)as a2) -> 
						  array_op Div a1 a2
					| DivElts, (ArrayVal (shape1, array1) as a1), (ArrayVal(shape2, array2)as a2) -> 
						  array_op DivElts a1 a2
					(* boolean comparison *)
					| (And, BoolVal b1, BoolVal b2) ->  BoolVal (b1 && b2)
					| (Or, BoolVal b1, BoolVal b2) -> BoolVal (b1 || b2) 
					(* object equality *)
					| (Eq, val1, val2) -> BoolVal(val1 = val2)  
					| (Neq, val1, val2) -> BoolVal(val1 <> val2)
					| _ -> raise (InvalidBinop op)
and array_op op arr1 arr2 = 
	match arr1, arr2 with 
	| ArrayVal(shape1, arr1), ArrayVal(shape2, arr2) ->
		if shape1 = shape2  then 
			let result = Array.copy arr1 in 
			let len = Array.length result in
			let subshape = Array.sub shape1 1 ((Array.length shape1) - 1) in  		
				for i = 0 to len-1 do
					if Array.length subshape = 0 then 
						result.(i) <- eval_binop op arr1.(i) arr2.(i)
					else result.(i) <- array_op op arr1.(i) arr2.(i)
				done;
			ArrayVal (shape1, result)
		else let msg = sprintf "Cannot apply  %s to matrices of mismatching size" (binop_to_string op) in 
		 raise (EvalError msg)
  | _ ->  
		let msg = sprintf "Error while using %s operator" (binop_to_string op) in
			raise (EvalError msg)
and vec_op op v1 v2 = 
	let len1 = Array.length v1 in 
	let len2 = Array.length v2 in 
	if len1 = len2 then 
		let result = Array.copy v1 in 
		for i = 0 to len1-1 do
			result.(i) <- eval_binop op v1.(i) v2.(i)
		done;
		result
	else let 
		msg = sprintf "Cannot apply  %s to matrices of mismatching size" (binop_to_string op) in 
		raise (EvalError msg)
and inner_product a1 a2 = 
	if Array.length a1 <> Array.length a2 then 
		raise (EvalError "Inner product requires vectors of same length")
	else
		let len =  (Array.length a1) in 
		if len = 0 then 
			raise (EvalError "Cannot take inner product of empty vectors")
		else
			let add = eval_binop Add in 
			let mult = eval_binop Mult in 
			let result = ref (mult a1.(0) a2.(0)) in 
			for i = 1 to (Array.length a1) -1 do
				result := add !result (mult a1.(i) a2.(i))
			done;
			!result
and outer_product a1 a2 = RowVal[|Nil|];;
	 

