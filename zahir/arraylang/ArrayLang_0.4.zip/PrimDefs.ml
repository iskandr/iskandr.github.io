open Base;;
open GlobalEnvironment;;

open Eval;;
open Printf;;

open ToString;;
open PrimitiveMath;;
open Primitives;;
open Interpreter;;


let primLen = function 
			| [ArrayVal data] -> NumVal (float_of_int (Array.length data))
			| [RowVal values]-> NumVal (float_of_int (Array.length values))
			| [ListVal(data)] -> NumVal(float_of_int (List.length data))
			| _ -> raise PrimitiveTypeError;;

let primHd = function 
	| [ListVal values] -> 
		  (match values with 
				| [] -> raise (EvalError "Cannot take hd of nil list"); 
			  | x::xs -> x
			)
	| _ -> raise PrimitiveTypeError;;

let primTl = function 
	| [ListVal values] -> 
		  (match values with 
				| [] -> raise (EvalError "Cannot take tl of nil list"); 
			  | x::xs -> ListVal xs
			)
	| _ -> raise PrimitiveTypeError;;

let primCons = function 
	| [a; b] -> 
		  (match b with 
				| ListVal xs -> ListVal (a::xs)
				| _ -> raise (EvalError "Cannot cons onto non-list"); 
			)
	| _ -> raise PrimitiveTypeError;;

let primNil = function 
		| [ListVal []] -> BoolVal true
		| [ListVal _] -> BoolVal false
	  | _ -> raise PrimitiveTypeError;;



let primReduce = function 
	| [fn; (RowVal data)] -> 
			let len = Array.length data in 
			if len = 0 then RowVal data 
			else let acc = ref data.(0) in 
		  for i = 1 to len - 1 do
				(***************************************************************
                NEED TO PASS TYPES TO APPLY TO RESOLVE OVERLOADS 
								Eventually this should be done statically 
				 ***************************************************************)
				acc := (apply fn [!acc; data.(i)] [TyVoid] )
			done;
			!acc	 
	 | _ -> raise PrimitiveTypeError;;

(*

let rec primZip args = 
		match args with 
			| [] -> raise (EvalError "Too few arguments: 2 expected, got 0")
			| ArrayVal (_)::[] -> raise (EvalError "Too few arguments: 2 expected, got 1")
			| [ArrayVal (data1); ArrayVal (data2)] ->
					if shape1 <> shape2 then raise (EvalError "Cannot zip arrays of mismatching shape")
				  else ArrayVal (shape1, zipArray data1 data2)
			| _ -> raise(EvalError "Wrong argument types for function zip")
and zipArray a1 a2 = 
	    let len = Array.length a1 in 
			let temp = Array.make len Nil in 
			for i = 0 to len -1 do
				temp.(i) <- match a1.(i), a2.(i) with 
										| (ArrayVal(_, _) as sub1), (ArrayVal(_, _) as sub2) -> primZip [sub1; sub2]
										| x,y -> TupleVal [|x; y|]
			done;
			temp;;


let rec primCross args = 
	match args with x::y::[] -> auxCross x y | _ -> raise(EvalError "Wrong argument types for function cross")
and auxCross x y = 
	match x,y with 
		| ArrayVal(shape1, data1), ArrayVal(shape2, data2)  ->  
			let len1 = Array.length data1 in
			let len2 = Array.length data2 in
			let temp1 = Array.make len1 Nil in 
				for i = 0 to len1 -1 do
					let temp2 = Array.make len2 Nil in 
					for j = 0 to len2 - 1 do
							temp2.(j) <- auxCross data1.(i) data2.(j)
					done;
					temp1.(i) <- ArrayVal (shape2, temp2)
				done;
			ArrayVal(Array.append shape1 shape2, temp1)
    | _, _ -> TupleVal [| x;y |] ;; 
*)

let _ = 
					def_prim "nil?" primNil (TyFn (TyList (TyVar (fresh_type_id())), TyBool));
					(let id = fresh_type_id() in 
						def_prim "hd" primHd (TyFn (TyList (TyVar id), TyVar id ))); 
					(let id = fresh_type_id() in  
					   def_prim "tl" primTl (TyFn (TyList (TyVar id), TyList (TyVar id))));
					(let tCons = 
						let id = fresh_type_id() in  
							TyFn (TyTuple ([|(TyVar id); TyList (TyVar id)|]), (TyList (TyVar id)))
					in def_prim "cons" primCons tCons);
				(let tEq = 
						let id = fresh_type_id() in  
							TyFn ((TyTuple [|TyVar id; TyVar id|]), TyBool)
					in def_prim (binop_id Eq) primEq tEq);
				(let tNeq = 
					let id = fresh_type_id() in  TyFn ((TyTuple [|TyVar id; TyVar id|]), TyBool)
				in def_prim (binop_id Neq) primNeq tNeq
				);
		(*		def_prim (bin_id Gt) primGt (let id = fresh_type_id() in  (TyFn (TyTuple [|TyVar id, TyVar id|]), TyBool));
				def_prim (bin_id Eq) primEq (let id = fresh_type_id() in  (TyFn (TyTuple [|TyVar id, TyVar id|]), TyBool));
				(* |   | Gt | Gte | Lt | Lte | Neq;;*)*)
				prim_op Add primPlus;
				prim_op Sub primMinus; 
				prim_op Mult primMult;
				prim_op MultElts primMultElts;
				def_prim (binop_id Div) primDiv (TyFn (TyTuple [|TyNum; TyNum|], TyNum));
				prim_op DivElts primDivElts;
				def_prim (binop_id And) primAnd (TyFn (TyTuple [|TyBool; TyBool|], TyBool)); 
				def_prim (binop_id Or) primOr (TyFn (TyTuple [|TyBool; TyBool|], TyBool));
				def_prim (unop_id Not) primNot (TyFn (TyBool, TyBool)); 
				def_prim (unop_id Neg) primNeg (TyFn (TyNum, TyNum)); 
				
				float_prim "cos" cos;
		    float_prim "sin" sin;
			  float_prim "tan" tan;
			  float_prim "abs" abs_float;
			  float_prim "log" log;
			  float_prim "log10" log10;
			  float_prim "sqrt" sqrt;
			  float_prim "exp" exp;
	      def_prim "len" primLen 
						(TyOverload
							[
								(TyFn(TyList(TyVar(fresh_type_id())), TyNum));
							  (TyFn(TyRow(TyVar(fresh_type_id())), TyNum))
							]);
			  def_prim "reduce" primReduce
						(let tid = fresh_type_id() in 
						 let tvar = TyVar tid in 
						 let tfn = TyFn (TyTuple [| tvar; tvar |], tvar) in 
						 TyOverload [
								(TyFn (TyTuple [| tfn; TyRow tvar |], tvar));
							  (TyFn (TyTuple [| tfn; TyCol tvar |], tvar));
								(TyFn (TyTuple [| tfn; TyList tvar |], tvar));
							]);
							 
			  string_to_void_prim "load" interp_file;; 