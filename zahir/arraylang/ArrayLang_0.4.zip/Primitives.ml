open Base;;
open GlobalEnvironment;;
open Eval;;
open Printf;;
open ToString;;
exception PrimitiveTypeError;; 

let def_prim name fn t = bind_global name (Primitive fn) t;;

let float_prim name fn = 
	let wrapper args = match args with 
	         	 | (NumVal num)::[] -> NumVal (fn num)
						 | _::[] -> raise (EvalError "Wrong argument type, number expected")
	           | _ -> raise (EvalError (sprintf "Arity mismatch: 1 expected, %d given" (List.length args)))
  in def_prim name wrapper (TyFn(TyNum, TyNum));;


let string_to_void_prim name fn = 
	let wrapper args = match args with 
	         	 | (StringVal str)::[] -> (fn (String.sub str 1 ((String.length str) - 2))); Void
						 | _::[] -> raise (EvalError "Wrong argument type, string expected")
	           | _ -> raise (EvalError (sprintf "Arity mismatch: 1 expected, %d given" (List.length args)))
  in def_prim name wrapper (TyFn(TyString, TyVoid));;


let prim_op op fn = 
		def_prim (binop_id op) fn 
		(TyOverload
						[
								(TyFn ( TyTuple [|TyNum; TyNum|], TyNum));
								(TyFn ( TyTuple [|TyRow TyNum; TyRow TyNum|], TyRow TyNum));
								(TyFn ( TyTuple [|TyCol TyNum; TyCol TyNum|], TyCol TyNum))
						]);;