open Printf;;
open Hashtbl;;

open Base;;
open Lexer;;
open Parser;;

open ToString;;
open Environment;;

open EvalArray;;
open EvalPatterns;;
open Eval;;
open Primitives;;

open TypeEnvironment;;
open Unify;;
open TypeInference;;


let interp lexbuf valEnv tEnv  = 
	try 
		let ast = Parser.program token lexbuf in
		let init_subs = Unify.TypeIdMap.empty in 
		let result_type, _  = type_check ast init_subs tEnv [] in 
		let result = eval valEnv ast in
		let value_str = value_to_string result in 
		let type_str = type_to_str result_type in 
		if String.length value_str > 0 then  printf "ans = %s :: %s \n" value_str type_str;
		set_binding valEnv "ans" result;
		set_type_binding tEnv "ans" result_type;
	 with
	 | Parsing.Parse_error  ->  
		  let p = (lexbuf.Lexing.lex_curr_p.Lexing.pos_cnum - lexbuf.Lexing.lex_curr_p.Lexing.pos_bol) in 
		  let l = lexbuf.Lexing.lex_curr_p.Lexing.pos_lnum in 
		    printf "parse error occurred on line %d at position %d \n" l p
		| Unify_Failure -> printf "Type check failed \n"
		| Type_Error(node, msg) -> printf "Type error: %s on line %d at column %d \n" msg node.line node.col
		| StaticError msg -> 
				printf "static error: %s \n" msg
		| TypeBindingNotFound id -> 
			   printf "no type information found for %s \n" id
	  | BindingNotFound id -> 
		    printf "no binding found for %s \n" id
	  | EvalError msg -> 
			  printf "run-time error occurred - %s \n" msg
		| MatchFailure msg -> 
			 printf "match failure - %s \n" msg
		| ArgumentMismatch (node, actual, used) -> 
			 printf "argument mismatch on line %d at column %d \n" node.line node.col;
			 printf "--- expected: %s \n" (type_to_str actual);
			 printf "--- got:      %s \n " (type_to_str used)
		| InvalidIndex (node, used_args) ->
			 printf "invalid index on line %d at column %d \n" node.line node.col;
			 print_string "--- expected: num \n";
			 printf       "--- got:      %s \n " (type_to_str used_args)
		| OverloadFailure (node, overloads, used_args) -> 
				printf "overload failure on line %d at column %d \n" node.line node.col;
			  print_string "--- valid overloads:  \n";
				List.iter (fun t -> printf "      %s \n" (type_to_str t)) overloads;
				printf "--- got: %s \n" (type_to_str used_args)
		| Division_by_zero -> printf "Division by zero \n"
		| PrimitiveTypeError -> printf "wrong argument types applied to primitive function \n"
		| _ as e ->  raise e


let interp_file name valEnv tEnv = 
	try
		let cin = open_in name in 
	  let lexbuf = Lexing.from_channel cin in 
	  let _ = interp lexbuf valEnv tEnv in 
		close_in cin
	with 
  	   Sys_error(msg) -> printf "Error: File not found (%s) \n" msg;;
