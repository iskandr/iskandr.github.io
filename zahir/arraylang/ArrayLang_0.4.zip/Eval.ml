open Printf;;
open Base;;
open Lexer;;
open Parser;;
open ToString;;
open Environment;;

(*open EvalMath;;*)
open EvalArray;;
open EvalPatterns;;

open PrimitiveMath;;

let rec  eval:environment->node->value  = fun  env ast ->
	let eval' = eval env in 
	match ast.data with 
		  | Program exp -> eval' exp 
   		| BlockExpression statements -> eval_block statements env
			| FunctionDefinition(id, formal_args, body) -> eval_fundef id formal_args body env
		  | GenericExpression(fns) -> raise(EvalError "Overloading not yet implemented") 
			| DefineExpression(pat, exp) -> 				 
					let bindings = get_bindings pat (eval' exp) in 
				  	modify_env env bindings;
						Void
			| LambdaExpression(args, body) -> LambdaVal(args, body, env)
			| LetExpr(pat, valExpr, body) -> eval_letrec env pat valExpr body
			| FunctionReference(fnExpr, argsExpr) -> 
				  let fn = eval' fnExpr in
					let ts = List.map (fun e -> e.t) argsExpr in 
					let actuals = List.map eval' argsExpr in  
					apply fn actuals ts
		  | UnaryExpression(op, arg) ->
				   let f = lookup (unop_id op) env in 
					 let ts = [arg.t] in 
				   apply f [eval' arg] ts
      | BinaryExpression(op, arg1, arg2) -> 
					let f = lookup (binop_id op) env in 
					let ts = [arg1.t; arg2.t] in 
					apply f [eval' arg1; eval' arg2] ts
			| IfExpr (testExpr, trueExpr) -> eval_if testExpr trueExpr env
    	| IfElseExpr (testExpr, trueExpr, falseExpr) -> eval_ifelse testExpr trueExpr falseExpr env
    	| Id name -> lookup name env
		  | FloatLiteral num -> NumVal num 
      | StringLiteral str -> StringVal str
			| BoolLiteral b -> BoolVal b
			| TupleExpression nodes -> eval_tuple nodes env
			| ListExpression (nodes) -> ListVal (List.map eval' nodes)
	 
			| ArrayExpression contents ->  RowVal (Array.of_list (List.map eval' contents)) (*build_array (List.map eval' contents)*)
			| ConcatExpression(n1, n2) -> eval_concat (eval' n1) (eval' n2)
			| RangeExpression(left, right, stride) -> eval_range (eval' left) (eval' right) (eval' stride)
			| ForExpression(pat, exp, body) -> eval_for pat (eval' exp) body env
		  | TransposeExpression exp -> primTranspose [eval' exp]
		  | VoidExpression -> Void 

and apply fn args arg_types = 
		match fn with 
	  | LambdaVal(formals, body, closure_env) -> 
			let nformals = (List.length formals) in 
			let nactuals = (List.length args) in 
			if nformals <> nactuals then 
				raise (EvalError (sprintf "arity mismatch - expected %d, got %d" nformals nactuals))
			else let bindings = List.combine formals args in
				eval (extend_env closure_env bindings) body
		| Primitive prim -> 
				prim args
		| ArrayVal data  -> 
		     array_access fn args
		| RowVal data  -> 
		     array_access fn args
		| ColVal data  -> 
		     array_access fn args
		| GenericVal fns -> 
			  resolve_overload fns args arg_types
		| _ -> raise (EvalError "Cannot call non-function") 
	and resolve_overload fns args tlist = 
			let t = match tlist with 
		  [] -> TyVoid
			| [x] -> x
			| xs -> TyTuple (Array.of_list xs)
		in try 
			let f = Hashtbl.find fns t in 
			apply f args tlist 
		with _ -> raise (EvalError "Overload failure")
	and eval_letrec env pat expr body = 
		    (* To allow recursive functions we first create an environment of nil*)
				(*  bindings and later modify them to reflect their real values *)
				 let nilBindings = get_nil_bindings pat  in
				 let newEnv = extend_env env nilBindings in
				 let value = eval newEnv expr in 
				 let bindings = get_bindings pat value in  
			   begin 
				 	modify_env newEnv bindings;
					eval newEnv body
				 end
	and match_and_eval env pat value body = 
				 let bindings = get_bindings pat value in  
			   let newEnv = extend_env env bindings in
					 eval newEnv body
	and eval_for pat value body env = 
		match value with
		| RowVal(data) -> 
				RowVal (Array.map (fun datum -> match_and_eval env pat datum body) data) 
		| ColVal(data) -> 
				ColVal (Array.map (fun datum -> match_and_eval env pat datum body) data) 
		| ListVal(data) -> 
				ListVal (List.map (fun datum -> match_and_eval env pat datum body) data)
		| _ -> raise (EvalError "Iteration requires an array type")

(*
and iter_for pat data body env  =  
			let len = (Array.length data) in
			let newData = Array.make len  Nil in 
				for i = 0 to len  - 1 do
					newData.(i) <-  match_and_eval env pat data.(i) body
				done; 
				newData
*)
and eval_if testExpr trueExpr env = 
		let testVal = eval env testExpr in 
		match testVal with 
		| BoolVal true -> eval env trueExpr
		| BoolVal false -> Void
		| _ -> raise (EvalError "test value must be a boolean")

and eval_ifelse testExpr trueExpr falseExpr env = 
		let testVal = eval env testExpr in 
		match testVal with 
		| BoolVal true -> eval env trueExpr
		| BoolVal false -> eval env falseExpr
		| _ -> raise (EvalError "test value must be a boolean")

and eval_block statements env = 
	 match List.rev_map (eval env) statements with 
	 | [] -> Void
	 | x::xs -> x

and eval_fundef id formal_args body env = 
			set_binding env id (LambdaVal(formal_args, body, env));
			Void
			
and eval_tuple nodes env = 
	match nodes with 
	| n::[] -> eval env n
	| _ -> TupleVal (Array.of_list (List.map (eval env) nodes))
;;