open Base;;
open Printf;;

  let unop_to_string = function 
		| Not -> "not"
		| Pos -> "+"
		| Neg -> "-";;

  let unop_name = function 
		| Not -> "not"
		| Pos -> "unary_plus"
		| Neg -> "unary_minus";;


  let binop_to_string = function 
		| Add -> "+"
		| AddElts -> ".+"
		| Sub -> "-"
		| SubElts -> ".-"
		| Mult -> "*"
		| MultElts -> ".*"
		| Div -> "/"
		| DivElts -> "./"
		| And -> "&&"
		| Or -> "||"
		| Eq -> "=="
		| Gt -> ">"
		| Gte -> ">="
		| Lt -> "<"
		| Lte -> "<="
		| Neq -> "~=";;

  

  let binop_name = function 
		| Add -> "plus"
		| AddElts -> "plus_elts"
		| Sub -> "minus"
		| SubElts -> "minus_elts"
		| Mult -> "mult"
		| MultElts -> "mult_elts"
		| Div -> "div"
		| DivElts -> "div_elts"
		| And -> "and"
		| Or -> "or"
		| Eq -> "eq"
		| Gt -> "gt"
		| Gte -> "gte"
		| Lt -> "lt"
		| Lte -> "lte"
		| Neq -> "neq";;

let unop_id op = "op." ^ (unop_name op);;
let binop_id op = "op." ^ (binop_name op);;

let intvec_to_string v = 
	let str_list = Array.to_list(Array.map string_of_int v) in 
			sprintf "[ %s ]" (String.concat " " str_list);;


let rec value_to_string v =  
	  match v with 
		| Nil -> "nil"
		| Void -> ""
		(*| IntVal num -> string_of_int num*)
		| NumVal num -> sprintf "%g" num (*string_of_float num*)
		| StringVal str -> str
		| BoolVal b -> string_of_bool  b
		| TupleVal data -> 
			   "(" ^ String.concat ", " (Array.to_list (Array.map value_to_string data)) ^ ")"
		| ArrayVal(contents) -> "<array>"
			(*
			   "[\n"^(String.concat "\n"  (Array.to_list (String.concat ", " (Array.to_list (Array.map (fun row ->  value_to_string rows) contents ))^ "\n]"
		  *)
			| ListVal(contents) -> 
				let str_list = List.map value_to_string contents in 
						sprintf "{ %s }" (String.concat ", " str_list)
		| RowVal(data) ->  vec_to_string data
		| ColVal(data) ->  (vec_to_string data) ^ "'"
		| LambdaVal(args, _, _) -> 
			  "@(" ^ (String.concat ", " args) ^ ")"
		| Primitive prim -> "<primitive-function>"
	  | GenericVal _ -> "<generic>"
and vec_to_string v = 
	let str_list = Array.to_list(Array.map value_to_string v) in 
			sprintf "[ %s ]" (String.concat " " str_list);;

let rec pattern_to_string = function
	  WildcardPattern -> "_"
		| IdPattern name -> name
		| TuplePattern ps -> String.concat ", " (Array.to_list (Array.map pattern_to_string ps))
		| ArrayPattern ps -> "[" ^ (String.concat " " (Array.to_list (Array.map pattern_to_string ps))) ^ "]"
		| ListPattern (ps, rest) ->
				let body = String.concat ", " (Array.to_list (Array.map pattern_to_string ps)) in 
				let rest = match rest with 
					| None ->  "" 
					| Some name -> " .. " ^ name
				in 		"{" ^ body ^ rest ^ "}";;


let rec type_to_str = function 
	| TyAny -> "*" 
	| TyVoid -> "()"
	| TyNum -> "num"
	| TyBool -> "bool" 
	| TyString -> "string"
	| TyList t -> "list (" ^ type_to_str' t ^ ")"
	| TyRow t -> "row (" ^ type_to_str' t ^ ")"
	| TyCol t -> "col (" ^ type_to_str' t ^ ")"
	| TyMat t -> "mat (" ^ type_to_str' t ^ ")"
	| TyTuple ts -> "(" ^ (String.concat ", " (Array.to_list (Array.map type_to_str' ts))) ^ ")"
	| TyFn (argT, resT) ->  (type_to_str' argT) ^ " -> " ^ (type_to_str' resT)
	| TyVar i -> "?" ^ (string_of_int i)
	| TyData id -> "??DATA??"(*lookup_type id*)
	| TyOverload ts -> String.concat "\n | " (List.map type_to_str' ts)
	(* type_to_str' wraps all function parameters in parens *)
and type_to_str' t = match t with  
		| TyFn _   -> "(" ^  (type_to_str t) ^ ")"
		| _ -> type_to_str t;;
