open Printf;;

open Base;;
open ToString;;

exception InvalidUnop of unary_op;;
exception InvalidBinop of binary_op;;
exception DynamicTypeError;; 

let rec vec_op f v1 v2  = 
	let len1 = Array.length v1 in 
  let len2 = Array.length v2 in 
	if len1 <> len2 then 
		  raise (EvalError "Cannot apply operation to vectors of mismatching length")
	else
		let result = Array.copy v1 in 
			for i = 0 to len1-1 do
				result.(i) <- f [ v1.(i); v2.(i) ]
		done;
		result;;

let rec array_op f a1 a2  = ArrayVal a1;;(*
	let rows1 = Array.length a1 in 
  let rows2 = Array.length a2 in 
	if rows1 = 0 || rows2 = 0 then 
		  raise (EvalError "Cannot apply operation to empty vector")
  else if rows1 <> rows2 then 
		  raise (EvalError "Cannot apply operation to vectors of mismatching length")
	else
	  let cols1 = Array.length a1.(0) in 
		let cols2 = Array.length a2.(0) in 
		if rows1 = 0 || rows2 = 0 then 
		  raise (EvalError "Cannot apply operation to empty vector")
  else if rows1 <> rows2 then 
		  raise (EvalError "Cannot apply operation to vectors of mismatching length")
		let result = Array.copy v1 in 
			for i = 0 to len1-1 do
				result.(i) <- f [v1.(i); v2.(i)]
		done;
		result;;



and array_op op arr1 arr2 = 
	match arr1, arr2 with 
	| ArrayVal(shape1, arr1), ArrayVal(shape2, arr2) ->
		if shape1 = shape2  then 
			let result = Array.copy arr1 in 
			let len = Array.length result in
			let subshape = Array.sub shape1 1 ((Array.length shape1) - 1) in  		
				for i = 0 to len-1 do
					if Array.length subshape = 0 then 
						result.(i) <- eval_binop op arr1.(i) arr2.(i)
					else result.(i) <- array_op op arr1.(i) arr2.(i)
				done;
			ArrayVal(result)
		else let msg = sprintf "Cannot apply  %s to matrices of mismatching size" (binop_to_string op) in 
		 raise (EvalError msg)
  | _ ->  
		let msg = sprintf "Error while using %s operator" (binop_to_string op) in
			raise (EvalError msg)
and 

	*)

let primTranspose value = 
	match value with 
		| [RowVal v] -> ColVal v
		| [ColVal v] -> RowVal v
		| [ArrayVal(data) as a] -> a
		| _ -> raise (EvalError "Wrong type for TRANSPOSE operator");; 

let primNot arg = match arg with 
	| [BoolVal b] -> BoolVal (not b)
	| _ -> raise (EvalError "Wrong type argument for NOT operator");;

let primNeg arg = match arg with 
	| [NumVal n] -> NumVal (-. n)
	| _ -> raise (EvalError "Wrong type argument for unary MINUS operator");;

let primPos arg = match arg with 
	[NumVal num]-> NumVal num
	| _ -> raise (EvalError "Wrong type argument for unary PLUS operator");;


let primAnd = function 
	|  [BoolVal b1; BoolVal b2] ->  BoolVal (b1 && b2)
	| _ -> raise DynamicTypeError;;

let primOr = function 
	| [BoolVal b1; BoolVal b2] -> BoolVal (b1 || b2) 
	| _ -> raise DynamicTypeError;;
				
let rec primPlus args = 
	match args with 
		| [ NumVal n1; NumVal n2] -> NumVal (n1 +. n2)
		| [RowVal row1;  RowVal row2] -> RowVal (vec_op primPlus row1 row2)
		| [ColVal col1; ColVal col2] -> ColVal (vec_op primPlus col1 col2)
		| [(ArrayVal a1);  (ArrayVal  a2)] -> 
				array_op primPlus a1 a2
		| _ -> raise (EvalError "Wrong type argument for PLUS operator ");;

let rec primMinus args = 
	match args with 
		| [NumVal num1; NumVal num2]  -> NumVal(num1 -. num2)
		| [RowVal row1;  RowVal row2] -> RowVal (vec_op primMinus row1 row2)
		| [ColVal col1; ColVal col2] -> ColVal (vec_op primMinus col1 col2)
		| [(ArrayVal a1); (ArrayVal a2)] -> 
				array_op primMinus a1 a2
		|  _ -> raise (EvalError "Wrong type argument for MINUS operator ");;

let rec primMult args = 
		match args with 
		| [NumVal num1; NumVal num2] -> NumVal (num1 *. num2) 
		| [RowVal row; ColVal col] -> 
				if Array.length row <> Array.length col then 
					raise (EvalError "Inner product requires vectors of same length")
				else
				let len =  (Array.length row) in 
				if len = 0 then 
					raise (EvalError "Cannot take inner product of empty vectors")
				else
				let result = ref (primMult [row.(0); col.(0)]) in 
					for i = 1 to (Array.length row) -1 do
						result := primPlus [(!result); (primMult [row.(i); col.(i)])]
					done;
				!result
		| [ColVal col; RowVal row] ->  RowVal[|Nil|]
		| [(ArrayVal a1); (ArrayVal a2)]->
				array_op primMult a1 a2
		| _ -> raise (EvalError "Wrong type argument for TIMES operator");;


let rec primMultElts args = 
			match args with 
			| [NumVal num1; NumVal num2] -> NumVal(num1 *. num2)
			| [RowVal row1; RowVal row2] -> RowVal (vec_op primMultElts row1 row2)
			| [ColVal col1; ColVal col2] -> ColVal (vec_op primMultElts col1 col2)
			| [(ArrayVal  a1); (ArrayVal  a2)] -> 
						  array_op MultElts a1 a2
			| _ -> raise (EvalError "Wrong type argument for ELEMENT TIMES operator");;

let rec primDiv = function  
	| [NumVal num1; NumVal num2] -> NumVal(num1 /. num2)
	| [ArrayVal a1; ArrayVal a2] -> 
			  array_op primDiv a1 a2			
	| _ -> raise DynamicTypeError;;
	  
let rec primDivElts = function  
	| [NumVal num1; NumVal num2] -> NumVal (num1 /. num2)
	| [RowVal row1; RowVal row2] -> RowVal(vec_op primDivElts row1 row2)
	| [ColVal col1; ColVal col2] -> ColVal(vec_op primDivElts col1 col2)
	| [(ArrayVal a1); (ArrayVal a2)] -> 
						  array_op primDivElts a1 a2
	| _ -> raise DynamicTypeError;;

let primGt = function  
	| [NumVal num1; NumVal num2] -> BoolVal(num1 > num2) 
	| _ -> raise DynamicTypeError;;

let primGte = function  
	| [NumVal num1; NumVal num2] -> BoolVal(num1 >= num2) 
	| _ -> raise DynamicTypeError;;
	
let primLt = function  
 | [NumVal num1; NumVal num2] -> BoolVal(num1 < num2)
 | _ -> raise DynamicTypeError;;

let primLte = function    
		[NumVal num1; NumVal num2] -> BoolVal(num1 <= num2)
		| _ -> raise DynamicTypeError;;

let primEq = function 
	| [val1; val2] -> BoolVal(val1 = val2)  
	| _ -> raise DynamicTypeError;;

let primNeq = function 
	|  [val1; val2] -> BoolVal(val1 <> val2) 
	| _ -> raise DynamicTypeError;;

