﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Joiners.Engine
{
   
    class ReverseComparison<T> : IComparer<T> where  T : IComparable<T>  
    {
          public int Compare(T x, T y )  
          {
              return -1 * x.CompareTo(y); 
          }
    }
}
