﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Joiners.Engine
{
    class JoinerListViewItem : ListViewItem
    {
        private JoinerImage _image = null;

        public JoinerImage JoinerImage
        {
            get { return _image; }
            set { _image = value; }
        }
    }
}
