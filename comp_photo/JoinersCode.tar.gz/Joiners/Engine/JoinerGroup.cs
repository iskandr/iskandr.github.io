﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Joiners.Math;
using Tao.OpenGl;

namespace Joiners.Engine
{
  public class JoinerGroup
  {
    #region Members

    private ArrayList _items = new ArrayList();

    #endregion //Members

    #region Properties

    public ArrayList Items
    {
      get { return _items; }
    }

    #endregion //Properties

    #region Methods

    public void   Add(JoinerImage image)
    {
      if (_items.Contains(image) == false)
        _items.Add(image);
    }

    public void   Remove(JoinerImage image)
    {
      _items.Remove(image);
    }

    public void   Select()
    {
      foreach (JoinerImage current in _items)
        current.Selected = JoinerImage.Selection.GROUP_SELECT;
    }

    public void   UnSelect()
    {
      foreach (JoinerImage current in _items)
        current.Selected = JoinerImage.Selection.NONE;
    }

    public void   Move(float distanceX, float distanceY)
    {
      foreach (JoinerImage current in _items)
      {
        Vector3D pos = current.GetPosition();
        current.SetPosition(pos.x + distanceX, pos.y + distanceY, pos.z);
      }
    }
    public void   Rotate(float angle)
    {
      foreach (JoinerImage current in _items)
      {
        Gl.glPushMatrix();
        current.RotateX(angle);
        Gl.glPopMatrix();
      }
    }

    #endregion //Methods
  }
}
