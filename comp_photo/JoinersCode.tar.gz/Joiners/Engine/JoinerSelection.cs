﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Joiners.Math;

namespace Joiners.Engine
{
  class JoinerSelection : IEnumerable
  {
    #region Members

    private ArrayList   _selectedItems = new ArrayList();
    private Vector3D    _extentMin = new Vector3D();
    private Vector3D    _extentMax = new Vector3D();
    private JoinerImage _soloSelection = null;

    #endregion //Members

    #region Properties

    public int Count
    {
      get { return _selectedItems.Count; }
    }

    public JoinerImage SoloSelection
    {
      get { return _soloSelection; }
      set { _soloSelection = value; }
    }

    #endregion //Properties

    #region Methods

    public Vector3D GetCenter()
    {
      return new Vector3D((_extentMin.x + _extentMax.x) / 2,
                          (_extentMin.y + _extentMax.y) / 2,
                          (_extentMin.z + _extentMax.z) / 2);
    }

    private void FindExtents()
    {
      if (_selectedItems.Count == 0)
        return;
      JoinerImage firstElem = (JoinerImage)_selectedItems[0];
      _extentMin.Set(firstElem.GetPosition());
      _extentMax.Set(firstElem.GetPosition());
      foreach (JoinerImage current in _selectedItems)
      {
        if (current.GetPosition().x < _extentMin.x)
          _extentMin.x = current.GetPosition().x;
        if (current.GetPosition().y < _extentMin.y)
          _extentMin.y = current.GetPosition().y;
        if (current.GetPosition().z < _extentMin.z)
          _extentMin.z = current.GetPosition().z;

        if (current.ExtentMax.x > _extentMax.x)
          _extentMax.x = current.GetPosition().x;
        if (current.GetPosition().y > _extentMax.y)
          _extentMax.y = current.GetPosition().y;
        if (current.GetPosition().z > _extentMax.z)
          _extentMax.z = current.GetPosition().z;
      }
    }

    public void Add(JoinerImage image)
    {
      _selectedItems.Add(image);
      Console.WriteLine(_extentMin.ToString() + " " + _extentMax.ToString());
      Console.WriteLine(image.ExtentMin.ToString() + " " + image.ExtentMax.ToString());
      if (image.GetPosition().x < _extentMin.x)
        _extentMin.x = image.GetPosition().x;
      if (image.GetPosition().y < _extentMin.y)
        _extentMin.y = image.ExtentMin.y;
      if (image.GetPosition().z < _extentMin.z)
        _extentMin.z = image.GetPosition().z;

      if (image.GetPosition().x > _extentMax.x)
        _extentMax.x = image.GetPosition().x;
      if (image.GetPosition().y > _extentMax.y)
        _extentMax.y = image.GetPosition().y;
      if (image.GetPosition().z > _extentMax.z)
        _extentMax.z = image.GetPosition().z;

      Console.WriteLine(_extentMin.ToString() + " " + _extentMax.ToString());
    }

    public void Remove(JoinerImage image)
    {
      _selectedItems.Remove(image);
      FindExtents();
    }

    public void ClearSelection()
    {
      foreach (JoinerImage current in _selectedItems)
        if (current != null)
          current.Selected = JoinerImage.Selection.NONE;
      _selectedItems.Clear();
      _soloSelection = null;
    }

    public void SetSoloSelection(JoinerImage image)
    {
      if (_soloSelection == null)
      {
        _soloSelection = image;
        image.Selected = JoinerImage.Selection.SOLO_SELECT;
        return;
      }
      _soloSelection.Selected = JoinerImage.Selection.GROUP_SELECT;
      _soloSelection = image;
      if (image != null)
        image.Selected = JoinerImage.Selection.SOLO_SELECT;
    }

    public JoinerImage this[int index]
    {
      get
      {
        if (index < 0 || index >= _selectedItems.Count)
          return null;
        return (JoinerImage)_selectedItems[index];
      }
    }

    public IEnumerator GetEnumerator()
    {
      return _selectedItems.GetEnumerator();
    }

    #endregion //Methods
  }
}
