﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Tao.OpenGl;
using Tao.Platform.Windows;

using Joiners.Graphic;

namespace Joiners.Engine
{
  class JoinersEngine
  {
    #region Members

    static private volatile JoinersEngine _instance;
    private int                           _tickCount;
    private bool                          _end = false;
    private float                         _fpsCount = 0;
    private float                         _fps = 0;

    #endregion //Members

    #region Properties

    public bool End
    {
      get { return _end; }
    }

    #endregion //Properties

    #region Constructor

    private JoinersEngine()
    {
    }

    public static JoinersEngine Instance
    {
      get
      {
        if (_instance == null)
        {
          lock (typeof(JoinersEngine))
          {
            if (_instance == null)
              _instance = new JoinersEngine();
          }
        }
        return _instance;
      }
    }

    #endregion //Constructor

    #region Methods

    public void   Quit()
    {
      _end = true;
    }

    public float  GetFPS()
    {
      int _tickCountNow = Environment.TickCount;
      _fpsCount++;
      if (_tickCountNow - _tickCount > 1000.0f)
      {
        _fps = _fpsCount;
        _fpsCount = 0;
        _tickCount = _tickCountNow;
      }
      return (_fps);
    }

    public bool   Initialize(int width, int height)
    {
      GraphicEngine.Instance.Initialize(width, height);
      GraphicEngine.Instance.Scene = new Scene();
      GraphicEngine.Instance.Scene.Initialize();
      _tickCount = Environment.TickCount;
      return true;
    }

    public void   MainLoop()
    {
      Gl.glClear(Gl.GL_COLOR_BUFFER_BIT | Gl.GL_DEPTH_BUFFER_BIT);
      Gl.glLoadIdentity();
      Gl.glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);

      Gl.glPushMatrix();

      GraphicEngine.Instance.Scene.Render();

      Gl.glPopMatrix();

      Gl.glFlush();
    }

    #endregion //Methods
  }
}
