﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Drawing;
using Joiners.Math;
using Joiners.Graphic;

using Tao.OpenGl;
using Tao.Platform.Windows;

using AForge.Imaging.Filters;

namespace Joiners.Engine
{
  public class JoinerImage : Mesh
  {
    #region Members

    private   Texture     _texture;
    private   Selection   _selection = Selection.NONE;
    protected Vector2D[]  _screenBoundingBox;
    private   JoinerGroup _group = null;
    private   string      _fileName = null;
    private static float   RATIO = 2048.0f;
    private int _index = 0;
    private Vector3D _lastMousePos = new Vector3D();


    private int _thumbWidth;
    private int _thumbHeight; 
    private Bitmap _thumbnail = null;
    private Bitmap _paddedThumbnail = null; 
    
    public enum Selection { GROUP_SELECT, SOLO_SELECT, NONE };


    #endregion //Members

    #region Properties

    public JoinerGroup     Group
    {
      get { return _group; }
      set { _group = value; }
    }

    public Selection       Selected
    {
      get { return _selection; }
      set { _selection = value; }
    }

    public int             TextureID
    {
      get { return _texture.ID; }
    }

    public Bitmap Image
    {
      get { return _texture.Image;  }
      set { SetImage(value); }
    }

    public Bitmap Thumbnail
    {
        get { return _thumbnail; }
        set { _thumbnail = value; }
    }

    public Bitmap PaddedThumbnail
    {
        get { return _paddedThumbnail; }
        set { _paddedThumbnail = value; }
    }

    public string FileName
    {
      get { return _fileName; }
    }

    public int Index
    {
        get { return _index; }
        set { _index = value; }
    }

    public Vector3D GetLastMousePosition()
    {
        return _lastMousePos;
    }

    public void SetLastMousePosition(Vector3D newPos)
    {
        _lastMousePos.Set(newPos);
    }

    public void SetLastMousePosition(float x, float y, float z)
    {
        _lastMousePos.Set(x, y, z);
    }

    #endregion //Properties

    #region Constructor

    public JoinerImage(Bitmap bmp, string textureFilePath, int tWidth, int tHeight)
    {
        _fileName = textureFilePath;

        if (bmp.Height > 1024 || bmp.Width > 1024)
        {
            bmp = smartResize(bmp, 1024, 1024);
        }

        _texture = new Texture(bmp, textureFilePath);

        _thumbWidth = tWidth;
        _thumbHeight = tHeight; 
        LoadThumbnail(bmp);
        
        _drawType = DrawType.FacetHighlight;
        SetPosition(new Vector3D());
        _name = Path.GetFileName(textureFilePath);
        Material = new Material();
        Material.SetToDefault();
        Material.Texture = _texture;
        this.DrawType = DrawType.Textured;

        Build();
        BuildInterleavedArray();
        ExtentsCompute();
        //bmp.Dispose(); 
         
    }

    #endregion //Constructor

    void LoadThumbnail(Bitmap bitmap)
    {
        _thumbnail = smartResize(bitmap, _thumbWidth, _thumbHeight);
        _paddedThumbnail = padBitmap(_thumbnail, _thumbWidth, _thumbHeight); 
    }

    public void SetImage(Bitmap bitmap)
    {
        LoadThumbnail(bitmap); 
        Material = new Material();
        Material.SetToDefault();
        _texture.Load(bitmap);
        Material.Texture = _texture;
        TextCoords.Clear();
        Build();
        BuildInterleavedArray();
        ExtentsCompute();
    }

    #region Methods

    private void           Build()
    {
      Vertices.Clear();
      Faces.Clear();
      int vertexId1 = Vertices.Add(new MetaVertex(-(_texture.Image.Size.Width * 2) / RATIO, -(_texture.Image.Size.Height * 2) / RATIO, 0.0f));
      TextCoords.Add(new Vector2D(0.0f, 0.0f));
      int vertexId2 = Vertices.Add(new MetaVertex((_texture.Image.Size.Width * 2) / RATIO, -(_texture.Image.Size.Height * 2) / RATIO, 0.0f));
      TextCoords.Add(new Vector2D(1.0f, 0.0f));
      int vertexId3 = Vertices.Add(new MetaVertex(-(_texture.Image.Size.Width * 2) / RATIO, (_texture.Image.Size.Height * 2) / RATIO, 0.0f));
      TextCoords.Add(new Vector2D(0.0f,1.0f));
      Face face = new Face(vertexId1, vertexId2, vertexId3);
      face.index = Faces.Add(face);
      face.TextureVertexIds[0] = vertexId1;
      face.TextureVertexIds[1] = vertexId2;
      face.TextureVertexIds[2] = vertexId3;
      vertexId1 = Vertices.Add(Vertices[vertexId2]);
      TextCoords.Add(new Vector2D(1.0f, 0.0f));
      vertexId2 = Vertices.Add(new MetaVertex((_texture.Image.Size.Width * 2) / RATIO, (_texture.Image.Size.Height * 2) / RATIO, 0.0f));
      TextCoords.Add(new Vector2D(1.0f,1.0f));
      vertexId3 = Vertices.Add(Vertices[vertexId3]);
      TextCoords.Add(new Vector2D(0.0f, 1.0f));
      face = new Face(vertexId1, vertexId2, vertexId3);
      face.index = Faces.Add(face);
      face.TextureVertexIds[0] = vertexId1;
      face.TextureVertexIds[1] = vertexId2;
      face.TextureVertexIds[2] = vertexId3;
    }

    public virtual void    UpdateScreenBoundingBox()
    {
      Vector3D[] boundingBoxPoints = new Vector3D[8];
      Vector2D[] points = new Vector2D[8];

      boundingBoxPoints[0].x = this.ExtentMin.x; boundingBoxPoints[0].y = this.ExtentMin.y; boundingBoxPoints[0].z = this.ExtentMin.z;
      boundingBoxPoints[1].x = this.ExtentMin.x; boundingBoxPoints[1].y = this.ExtentMin.y; boundingBoxPoints[1].z = this.ExtentMax.z;
      boundingBoxPoints[2].x = this.ExtentMin.x; boundingBoxPoints[2].y = this.ExtentMax.y; boundingBoxPoints[2].z = this.ExtentMin.z;
      boundingBoxPoints[3].x = this.ExtentMin.x; boundingBoxPoints[3].y = this.ExtentMax.y; boundingBoxPoints[3].z = this.ExtentMax.z;
      boundingBoxPoints[4].x = this.ExtentMax.x; boundingBoxPoints[4].y = this.ExtentMin.y; boundingBoxPoints[4].z = this.ExtentMin.z;
      boundingBoxPoints[5].x = this.ExtentMax.x; boundingBoxPoints[5].y = this.ExtentMin.y; boundingBoxPoints[5].z = this.ExtentMax.z;
      boundingBoxPoints[6].x = this.ExtentMax.x; boundingBoxPoints[6].y = this.ExtentMax.y; boundingBoxPoints[6].z = this.ExtentMin.z;
      boundingBoxPoints[7].x = this.ExtentMax.x; boundingBoxPoints[7].y = this.ExtentMax.y; boundingBoxPoints[7].z = this.ExtentMax.z;

      int i = 0;
      foreach (Vector3D v in boundingBoxPoints)
      {
        Vector3D projectedPoint = GraphicEngine.Instance.Project(GraphicEngine.Instance.Scene.CurrentCamera.Matrix * this.GetAbsoluteMatrix(), v);
        points[i++].Set(projectedPoint.x, projectedPoint.y);
      }
      _screenBoundingBox = Math.Math.ComputeConvexHull(points);
    }

    public virtual bool    IsPointHovering(Vector3D point)
    {
      Vector2D pt = new Vector2D(point.x, point.y);
      Vector3D pos = this.GetPosition();
      if (pt.x > (ExtentMin.x * GetScale().x + pos.x) && pt.x < (ExtentMax.x * GetScale().x + pos.x) &&
          pt.y > (ExtentMin.y * GetScale().y + pos.y) && pt.y < (ExtentMax.y * GetScale().y + pos.y))
        return true;
      return false;
    }

    public virtual bool    IsPointHovering(Vector2D point)
    {
      if (point.x > ExtentMin.x && point.x < ExtentMax.x && 
          point.y > ExtentMin.y && point.y < ExtentMax.y)
        return true;
      return false;
    }

    public virtual bool    IsPointInRect(Vector3D topLeft, Vector3D bottomRight)
    {
      if (topLeft.x < ExtentMin.x && bottomRight.x > ExtentMax.x &&
          bottomRight.y < ExtentMin.y && topLeft.y > ExtentMax.x)
        return true;
      return false;
    }

    public void            Move(float x, float y, float z)
    {
      Vector3D pos = this.GetPosition();
      this.SetPosition(pos.x + x, pos.y + y, pos.z + z);
    }

    public void            Rotate(float angle)
    {
      Gl.glPushMatrix();
      this.RotateZ(angle);
      Gl.glPopMatrix();
    }

    public override void   Draw()
    {
      base.Draw();
      if (Selected == Selection.NONE)
        return;
      Gl.glPushMatrix();
      if (Selected == Selection.GROUP_SELECT)
        Gl.glColor3f(0.0f, 1.0f, 0.0f);
      else
        Gl.glColor3f(1.0f, 0.0f, 0.0f);
      ExtentsDraw();
      Gl.glColor3f(1.0f, 1.0f, 1.0f);
      Gl.glPopMatrix();
    }
 
      //resize image while preserving aspect ratio
    private Bitmap smartResize(Bitmap bmp, int desiredWidth, int desiredHeight)
    {
        /* Conserve Aspect Ratio */
        int newWidth = 0;
        int newHeight = 0;

        if (bmp.Width >= bmp.Height)
        {
            newWidth = desiredWidth;
            newHeight = (desiredWidth * bmp.Height) / bmp.Width;
        }
        else
        {
            newHeight = desiredHeight;
            newWidth = (desiredHeight * bmp.Width) / bmp.Height;
        }

        ResizeBilinear resizer = new ResizeBilinear(newWidth, newHeight);
        return resizer.Apply(bmp); 
  /*      Bitmap newBmp = new Bitmap(newWidth, newHeight, bmp.PixelFormat);
        using (Graphics g = Graphics.FromImage(newBmp))
        {
            g.DrawImage(bmp, 0, 0);
           
        }
        return newBmp;
   */
    }

    private Bitmap padBitmap(Bitmap bmp, int desiredWidth, int desiredHeight)
    {
        
      /*  Used to conform to bmp's PixelFormat, but it looks better if we
       *  make it 32bpp and use transparency
       *  ---- Bitmap bmpPadded = new Bitmap(desiredWidth, desiredHeight, bmp.PixelFormat);
       */
       Bitmap bmpPadded = new Bitmap(desiredWidth, desiredHeight, System.Drawing.Imaging.PixelFormat.Format32bppArgb);
    
 
        // resize image if it's current bigger than the padded result
        if (desiredWidth < bmp.Width || desiredHeight < bmp.Height)
            bmp = smartResize(bmp, desiredWidth, desiredHeight); 


        
        using (Graphics g = Graphics.FromImage(bmpPadded))
        {
            g.Clear(System.Drawing.Color.Transparent); 
            g.DrawImage(bmp, 0, 0, bmp.Width, bmp.Height);
           
        }

        return bmpPadded;
    }

    #endregion //Methods
  }
}
