﻿
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Drawing;
    using AForge.Imaging;

    namespace Joiners.Engine
    {
        class SaturationBorder : BorderComparison, ImageComparison
        {

            private double histogramDifference(ImageStatisticsHSL stats1, ImageStatisticsHSL stats2)
            {
                int nBins = stats1.Saturation.Values.Length;

                int[] s1 = stats1.Saturation.Values;
                int[] s2 = stats2.Saturation.Values; 

                double count1 = Convert.ToDouble(stats1.PixelsCount);
                double count2 = Convert.ToDouble(stats2.PixelsCount);

                double dS = 0.0; 
                double diff = 0.0;

                for (int i = 0; i < nBins; ++i)
                {

                    dS = Convert.ToDouble(s1[i]) / count1 - Convert.ToDouble(s2[i]) / count2;
                    diff += System.Math.Abs(dS);
                }
                return diff;
            }
            public float compare(Bitmap map1, Bitmap map2)
            {
                //iterate over combinations of edges
                //in order top, right, left, bottom
                double minDiff = 1000000.0;
                double currDiff = 0.0;


                Rectangle rect1;
                Rectangle rect2;

                System.Drawing.Imaging.BitmapData edge1;
                System.Drawing.Imaging.BitmapData edge2;

                ImageStatisticsHSL stats1;
                ImageStatisticsHSL stats2;

                for (int i = 0; i < 4; ++i)
                {
                    rect1 = borderRect(map1, i);
                    rect2 = borderRect(map2, 3 - i);

                    edge1 = map1.LockBits(rect1, System.Drawing.Imaging.ImageLockMode.ReadOnly, map1.PixelFormat);
                    edge2 = map2.LockBits(rect2, System.Drawing.Imaging.ImageLockMode.ReadOnly, map2.PixelFormat);

                    stats1 = new ImageStatisticsHSL (edge1);
                    stats2 = new ImageStatisticsHSL (edge2);

                    map1.UnlockBits(edge1);
                    map2.UnlockBits(edge2);

                    currDiff = histogramDifference(stats1, stats2);

                    if (currDiff < minDiff)
                        minDiff = currDiff;
                }

                return Convert.ToSingle(1.0 - minDiff);
            }
        }
    }