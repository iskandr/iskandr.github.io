﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using AForge.Imaging.Filters;

namespace Joiners.Engine
{
    class EuclideanDistance :  ImageComparison
    {

        public float compare(Bitmap map1, Bitmap map2)
        {
            int width = map1.Width;
            int height = map1.Height;

            //if images differ in size, resize the second
            if (width != map2.Width || height != map2.Height)
            {
                ResizeBilinear resizer = new ResizeBilinear(width, height);
                map2 = resizer.Apply(map2); 
            }

            BitmapData data1 = map1.LockBits(new Rectangle(0, 0, width, height), ImageLockMode.ReadOnly, map1.PixelFormat);
            BitmapData data2;
            bool sameImage = (map1 == map2);
            if (sameImage)
                data2 = data1;    
            else 
                data2 = map2.LockBits(new Rectangle(0, 0, width, height), ImageLockMode.ReadOnly, map2.PixelFormat);
          
            int stride = data1.Stride;
            System.IntPtr scan0_1 = data1.Scan0;
            System.IntPtr scan0_2 = data2.Scan0;

            int sum = 0;

            /*  
             * if images are laid out as BGR then increment pointers
             * by 3 bytes as we traverse the image. If there is an alpha
             * channel, then we increment by 4 bytes
             */
            int nBytes1=3;
            if (map1.PixelFormat == PixelFormat.Format32bppArgb)
                nBytes1 = 4; 

            int nBytes2=3; 
            if (map2.PixelFormat == PixelFormat.Format32bppArgb)
                nBytes2 = 4; 
            
            unsafe
            {
                byte* p1 = (byte*)(data1.Scan0);
                byte* p2 = (byte*)(data2.Scan0); 
                
                int[] diff = new int[3]; 
 

                for (int i = 0; i < height; ++i)
                {
                    for (int j = 0; j < width; ++j)
                    {
                        
                        diff[0] =((byte)p1[0] - (byte)p2[0]);
                        diff[1] = ((byte)p1[1] - (byte)p2[1]);
                        diff[2] = ((byte)p1[2] - (byte)p2[2]);
                        

                        sum += diff[0] * diff[0] + diff[1] * diff[1]+diff[2] * diff[2]; 

                        p1 += nBytes1;
                        p2 += nBytes2; 
                    }

                    p1 += stride - width * nBytes1;
                    p2 += stride - width * nBytes2; 
                }
            }


            map1.UnlockBits(data1);
            if (!sameImage) map2.UnlockBits(data2);

            double imgArea = Convert.ToDouble(width * height);
            double normalized =  Convert.ToDouble(sum) / (System.Math.Pow(255.0f, 2.0f) * imgArea * 3.0); 
            return 1.0f - Convert.ToSingle(normalized);

        }
    }
}
