﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using AForge.Imaging;

namespace Joiners.Engine
{
    class RGB_Histogram : ImageComparison
    {
        public float compare(Bitmap map1, Bitmap map2)
        {
            ImageStatistics stats1 = new ImageStatistics(map1);
            ImageStatistics stats2 = new ImageStatistics(map2);

            int nBins = stats1.Red.Values.Length;
            
            int[] red1 = stats1.Red.Values;
            int[] red2 = stats2.Red.Values;
            int[] green1 = stats1.Green.Values;
            int[] green2 = stats2.Green.Values;
            int[] blue1 = stats1.Blue.Values;
            int[] blue2 = stats2.Blue.Values;

            double count1 = Convert.ToDouble(stats1.PixelsCount);
            double count2 = Convert.ToDouble(stats2.PixelsCount); 


            double dRed = 0.0;
            double dGreen = 0.0;
            double dBlue = 0.0;

            double diff = 0.0;
            
            for (int i = 0; i < nBins; ++i)
            {
                dRed = Convert.ToDouble(red1[i])/count1 - Convert.ToDouble(red2[i])/count2;
                dGreen = Convert.ToDouble(green1[i])/count1 - Convert.ToDouble(green2[i])/count2; 
                dBlue = Convert.ToDouble(blue1[i])/count1 - Convert.ToDouble(blue2[i])/count2;

                diff += System.Math.Abs(dRed) + System.Math.Abs(dGreen) + System.Math.Abs(dBlue); 
            }
            return Convert.ToSingle(1.0 - diff / 3.0); 
        }
    }
}
