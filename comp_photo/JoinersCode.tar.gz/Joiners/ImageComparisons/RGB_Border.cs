﻿
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Drawing;
    using AForge.Imaging;

    namespace Joiners.Engine
    {
        class RGB_Border : BorderComparison, ImageComparison
        {

            private double histogramDifference(ImageStatistics stats1, ImageStatistics stats2)
            {
                int nBins = stats1.Red.Values.Length;

                int[] r1 = stats1.Red.Values;
                int[] r2 = stats2.Red.Values;
                int[] g1 = stats1.Green.Values;
                int[] g2 = stats2.Green.Values; 
                int[] b1 = stats1.Blue.Values;
                int[] b2 = stats2.Blue.Values;
              
                double count1 = Convert.ToDouble(stats1.PixelsCount);
                double count2 = Convert.ToDouble(stats2.PixelsCount);

                double dR = 0.0f;
                double dG = 0.0f;
                double dB = 0.0f; 

                double diff = 0.0f;

                for (int i = 0; i < nBins; ++i)
                {
                    dR = Convert.ToDouble(r1[i]) / count1 - Convert.ToDouble(r2[i]) / count2;
                    dG = Convert.ToDouble(g1[i]) / count1 - Convert.ToDouble(g2[i]) / count2;
                    dB = Convert.ToDouble(b1[i]) / count1 - Convert.ToDouble(b2[i]) / count2;

                    diff += System.Math.Abs(dR) + System.Math.Abs(dG) + System.Math.Abs(dB);
                }
                return diff;
            }
            public float compare(Bitmap map1, Bitmap map2)
            {
                //iterate over combinations of edges
                //in order top, right, left, bottom
                double minDiff = 1000000.0;
                double currDiff = 0.0;


                Rectangle rect1;
                Rectangle rect2;

                System.Drawing.Imaging.BitmapData edge1;
                System.Drawing.Imaging.BitmapData edge2;

                ImageStatistics stats1;
                ImageStatistics stats2;

                for (int i = 0; i < 4; ++i)
                {
                    rect1 = borderRect(map1, i);
                    rect2 = borderRect(map2, 3 - i);

                    edge1 = map1.LockBits(rect1, System.Drawing.Imaging.ImageLockMode.ReadOnly, map1.PixelFormat);
                    edge2 = map2.LockBits(rect2, System.Drawing.Imaging.ImageLockMode.ReadOnly, map2.PixelFormat);

                    stats1 = new ImageStatistics(edge1);
                    stats2 = new ImageStatistics(edge2);

                    map1.UnlockBits(edge1);
                    map2.UnlockBits(edge2);

                    currDiff = histogramDifference(stats1, stats2);

                    if (currDiff < minDiff)
                        minDiff = currDiff;
                }

                return Convert.ToSingle(1.0 - minDiff / 3.0);
            }
        }
    }

