﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;

namespace Joiners.Engine
{
    interface ImageComparison
    {
       float compare(Bitmap img1, Bitmap img2); 
    }
}
