﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using AForge.Imaging;

namespace Joiners.Engine
{
    class ChromaHistogram : ImageComparison
    {
        public float compare(Bitmap map1, Bitmap map2)
        {
          
            ImageStatisticsYCbCr stats1 = new ImageStatisticsYCbCr(map1);
            ImageStatisticsYCbCr stats2 = new ImageStatisticsYCbCr(map2);
          

            int nBins = stats1.Cb.Values.Length;

            int[] cb1 = stats1.Cb.Values;
            int[] cb2 = stats2.Cb.Values;
            int[] cr1 = stats1.Cr.Values;
            int[] cr2 = stats2.Cr.Values;
      
            double count1 = Convert.ToDouble(stats1.PixelsCount);
            double count2 = Convert.ToDouble(stats2.PixelsCount);

            double dCb = 0.0f;
            double dCr = 0.0f;

            double diff = 0.0f;

            for (int i = 0; i < nBins; ++i)
            {
                dCb = Convert.ToDouble(cb1[i]) / count1 - Convert.ToDouble(cb2[i]) / count2;
                dCr = Convert.ToDouble(cr1[i]) / count1 - Convert.ToDouble(cr2[i]) / count2;

                diff += System.Math.Abs(dCb) + System.Math.Abs(dCr);
            }

            return Convert.ToSingle(1.0 - diff / 2.0);
        }
    }
}
