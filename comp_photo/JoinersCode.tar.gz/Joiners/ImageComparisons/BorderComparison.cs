﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

namespace Joiners.Engine
{
    abstract class BorderComparison 
    {
        public BorderComparison()
        {
            _edgeSize = 10; 
        }

        public BorderComparison(int edgeSize)
        {
            _edgeSize = edgeSize; 
        }

      // public abstract float compare(Bitmap b1, Bitmap b2); 

        protected int _edgeSize; 

        protected System.Drawing.Rectangle borderRect(Bitmap map, int edgeNum)
        {
            int height = 0; int width = 0;
            switch (edgeNum)
            {
                case 1: //left
                case 2: //right
                    width = System.Math.Min(_edgeSize, map.Width);
                    height = map.Height;
                    break;

                default: //top
                    //bottom
                    width = map.Width;
                    height = System.Math.Min(_edgeSize, map.Height);
                    break;


            }

            switch (edgeNum)
            {

                case 0: //top
                    return new Rectangle(0, 0, width, _edgeSize);


                case 1: //left
                    return new Rectangle(0, 0, _edgeSize, height);

                case 2: //right
                    return new Rectangle(width - _edgeSize, 0, _edgeSize, height);

                default: //bottom
                    return new Rectangle(0, height - _edgeSize, width - 1, _edgeSize);

            }
        }
    }
}
