//----------------------------------------------------------------------------
//  Project     : EdenArts.Graphic
//  Author      : Michel Courtine
//  Date        : 01/02/2005
//  File        : MetaVertex.cs
//  Description : MetaVertex class
//----------------------------------------------------------------------------
//  EdenArts.Graphic is a 3D graphic engine library.
//  The project is running under QPL licence.
//    (QPL Licence specifications: http://www.trolltech.com/licenses/qpl.html)
//  Zion is part of Eden Arts Team Work
//  Members are:
//      Nadim Awad        (awad_n@epitech.net)
//      Michel Courtine   (courti_m@epitech.net)
//      Matthieu Dehaussy (dehaus_m@epitech.net)
//      Julien Ferrero    (ferrer_j@epitech.net)
//      Nicolas Goubaux   (goubau_n@epitech.net)
//      Valerie Tching    (tching_v@epitech.net)
//  You can have further information on Zion website:
//         http://zion.labtech.epitech.net
//----------------------------------------------------------------------------

using System;
using Joiners.Math;

namespace Joiners.Graphic
{
	/// <summary>
	/// Class used to bind a Vertex to its neighbor faces.
	/// </summary>
	public class              MetaVertex : ICloneable
	{
    #region Members

    public Vertex	    Vertex            = new Vertex();
    public ArrayFace	    NeighborFaces     = new ArrayFace();
    public ArrayMetaVertex  NeighborVertices  = new ArrayMetaVertex();
    public Vector3D         Normal            = new Vector3D(0.0f, 0.0f, 0.0f);

    public int              NormalId;
    public int              VertexId;

    public bool             IsValid           = false;

    #endregion Members

    #region Constructors

    public                  MetaVertex()
    {
    }

    public                  MetaVertex(float x, float y, float z)
    {
      Vertex.Position.x = x;
      Vertex.Position.y = y;
      Vertex.Position.z = z;
    }
    
    #endregion Constructors

    public void             Set(MetaVertex metaVertex)
    {
      Vertex.Set(metaVertex.Vertex);
      NeighborFaces = (ArrayFace)metaVertex.NeighborFaces.Clone();
      NeighborVertices = (ArrayMetaVertex)metaVertex.NeighborVertices.Clone();
      Normal.Set(metaVertex.Normal);
      NormalId = metaVertex.NormalId;
      VertexId = metaVertex.VertexId;
      IsValid = metaVertex.IsValid;
    }

    #region Neighbors

    public int 				      HasNeighbor(Face face)              { return NeighborFaces.Find(face); }
    public int 				      HasNeighbor(MetaVertex metaVertex)  { return NeighborVertices.Find(metaVertex); }	
    public int				      NbFaceNeighbor()                    { return NeighborFaces.Count; }
    public Face				      GetFaceNeighbor(int neighbor)       { return NeighborFaces[neighbor]; }
    
    public void				      AddNeighbor(Face face)
		{
			if(HasNeighbor(face) == -1)
				NeighborFaces.Add(face);
		}

		public void			        AddNeighbor(MetaVertex metaVertex)
		{
			if (metaVertex == this)
				return;
	
			if (HasNeighbor(metaVertex) == -1)
				NeighborVertices.Add(metaVertex);
		}

		public void					    RemoveAllFaceNeighbors()
		{
      NeighborFaces.Clear();
// TODO: ARRAY Changes Ok ?
//			for (int i = 0; i < NeighborFaces.Last; i++)
//				NeighborFaces.Remove(i);
		}

		public void					    RemoveAllVertexNeighbors()
		{
      NeighborVertices.Clear();
// TODO: ARRAY Changes Ok ?
//			for (int i = 0; i < NeighborVertices.Last; i++)
//				NeighborVertices.Remove(i);
    }

    #endregion Neighbors

    #region ICloneable Members

    public object           Clone()
    {
      MetaVertex            metaVertex = new MetaVertex();

      metaVertex.Set(this);
      return (metaVertex);
    }

    #endregion
  }
}
