//----------------------------------------------------------------------------
//  Project     : EdenArts.Graphic
//  Author      : Michel Courtine
//  Date        : 01/02/2005
//  File        : TextureManager.cs
//  Description : TextureManager class
//----------------------------------------------------------------------------
//  EdenArts.Graphic is a 3D graphic engine library.
//  The project is running under QPL licence.
//    (QPL Licence specifications: http://www.trolltech.com/licenses/qpl.html)
//  Zion is part of Eden Arts Team Work
//  Members are:
//      Nadim Awad        (awad_n@epitech.net)
//      Michel Courtine   (courti_m@epitech.net)
//      Matthieu Dehaussy (dehaus_m@epitech.net)
//      Julien Ferrero    (ferrer_j@epitech.net)
//      Nicolas Goubaux   (goubau_n@epitech.net)
//      Valerie Tching    (tching_v@epitech.net)
//  You can have further information on Zion website:
//         http://zion.labtech.epitech.net
//----------------------------------------------------------------------------

using System;
using System.Collections;

namespace Joiners.Graphic
{
	/// <summary>
	/// Summary description for TextureManager.
	/// </summary>
	public class TextureManager
	{
    #region Members

    private Hashtable   _hash = new Hashtable();

    #endregion Members

    #region Constructors

		public TextureManager()
		{
		}

    #endregion Constructors

    public Texture      GetTexture(string filename)
    {
      if (_hash[filename] != null)
        return ((Texture)_hash[filename]);
      else
      {
        Texture texture = new Texture(filename);
        _hash[filename] = texture;
        return (texture);
      }
    }
	}
}
