//----------------------------------------------------------------------------
//  Project     : EdenArts.Graphic
//  Author      : Valerie Tching
//  Date        : 01/02/2005
//  File        : Entity.cs
//  Description : Entity class
//                Base class
//                Inherited classes are: Mesh, Light, Group
//----------------------------------------------------------------------------
//  EdenArts.Graphic is a 3D graphic engine library.
//  The project is running under QPL licence.
//    (QPL Licence specifications: http://www.trolltech.com/licenses/qpl.html)
//  Zion is part of Eden Arts Team Work
//  Members are:
//      Nadim Awad        (awad_n@epitech.net)
//      Michel Courtine   (courti_m@epitech.net)
//      Matthieu Dehaussy (dehaus_m@epitech.net)
//      Julien Ferrero    (ferrer_j@epitech.net)
//      Nicolas Goubaux   (goubau_n@epitech.net)
//      Valerie Tching    (tching_v@epitech.net)
//  You can have further information on Zion website:
//         http://zion.labtech.epitech.net
//----------------------------------------------------------------------------

namespace Joiners.Graphic
{
  using System;
  using Tao.OpenGl;
  using Joiners.Math;

  /// <summary>
  /// Summary description for Entity.
  /// </summary>
  public class                  Entity : Transformable, IDrawable, ICloneable
  {
    #region Members

    protected Entity            _parent     = null;
    protected int               _id;
    protected string            _name       = String.Empty;
    protected Vector3D          _extentMin  = new Vector3D();
    protected Vector3D          _extentMax  = new Vector3D();
    protected Vector3D          _center     = new Vector3D();
    protected bool              _visible    = true;
    protected bool              _editable   = false;

    #endregion Members

    #region Properties

    public Entity               Parent
    {
      get { return (_parent); }
      set { _parent = value;  }
    }

    public int                  Id
    {
      get { return (_id); }
      set { _id = value;  }
    }

    public string               Name
    {
      get { return (_name); }
      set { _name = value;  }
    }

    public Vector3D             ExtentMin
    {
      get { return (_extentMin); }
      set { _extentMin = value; }
    }

    public Vector3D             ExtentMax
    {
      get { return (_extentMax); }
      set { _extentMax = value; }
    }

    public Vector3D             Center
    {
      get { return (_center); }
      set { _center = value;  }
    }

    public bool                 Visible
    {
      get { return (_visible); }
      set { _visible = value;  }
    }

    public bool                 Editable
    {
      get { return (_editable); }
      set { _editable = value;  }
    }

    public Vector3D []          ExtentsPoints
    {
      get
      {
        Vector3D []         points = new Vector3D[8];
        points[0].x = ExtentMin.x; points[0].y = ExtentMin.y; points[0].z = ExtentMin.z;
        points[1].x = ExtentMin.x; points[1].y = ExtentMax.y; points[1].z = ExtentMin.z;
        points[2].x = ExtentMax.x; points[2].y = ExtentMin.y; points[2].z = ExtentMin.z;
        points[3].x = ExtentMax.x; points[3].y = ExtentMax.y; points[3].z = ExtentMin.z;
        points[4].x = ExtentMin.x; points[4].y = ExtentMin.y; points[4].z = ExtentMax.z;
        points[5].x = ExtentMin.x; points[5].y = ExtentMax.y; points[5].z = ExtentMax.z;
        points[6].x = ExtentMax.x; points[6].y = ExtentMin.y; points[6].z = ExtentMax.z;
        points[7].x = ExtentMax.x; points[7].y = ExtentMax.y; points[7].z = ExtentMax.z;
        return (points);
      }
    }

    #endregion Properties

    #region Initialization

    public void                 Set(Entity entity)
    {
      _parent                   = entity.Parent;
      _id                       = entity.Id;
      _name                     = entity.Name;

      SetGeometry(entity);

      _extentMin                = entity.ExtentMin;
      _extentMax                = entity.ExtentMax;
      _center                   = entity.Center;
    }

    #endregion Initialization

    #region Transformable

    private Vector3D            GetAbsolutePosition(Entity entity, Vector3D v)
    {
      if (entity.Parent == null)
        return (v);
      return (GetAbsolutePosition(entity.Parent, entity.Parent.Matrix * v));
    }
    private Quaternion          GetAbsoluteQuaternion(Entity entity)
    {
      if (entity == null)
        return (Quaternion.Identity);
      return (entity.GetQuaternion() * GetAbsoluteQuaternion(entity.Parent));
    }
    private Vector3D            GetAbsoluteScale(Entity entity)
    {
      if (entity == null)
        return (new Vector3D(1, 1, 1));
      return (GetAbsoluteScale(entity.Parent) * entity.GetScale());
    }

    public void                 SetAbsoluteMatrix(Entity entity)
    {
      SetPosition(GetAbsolutePosition(entity, entity.GetPosition()));
      SetQuaternion(GetAbsoluteQuaternion(entity));
      SetScale(GetAbsoluteScale(entity));
    }

    private Matrix4D            GetAbsoluteMatrix(Entity entity)
    {
      if (entity == null)
        return (Matrix4D.Identity);
      return (GetAbsoluteMatrix(entity.Parent) * entity.Matrix);
    }

    public Matrix4D             GetAbsoluteMatrix()
    {
      return (GetAbsoluteMatrix(this));
    }

    #endregion Transformable

    #region IDrawable Members

    public virtual void         Draw()
    {
    }

    #endregion

    #region Extents

    public virtual void         ExtentsCompute()
    {
    }

    public void                 ExtentsDraw()
    {
      // Saving OpenGL state
      Gl.glPushAttrib(Gl.GL_LIGHTING_BIT);

      Gl.glDisable(Gl.GL_LIGHTING);
      Gl.glBegin(Gl.GL_LINE_STRIP);
      Gl.glVertex3f(_extentMin.x, _extentMin.y, _extentMin.z);
      Gl.glVertex3f(_extentMax.x, _extentMin.y, _extentMin.z);
      Gl.glVertex3f(_extentMax.x, _extentMax.y, _extentMin.z);
      Gl.glVertex3f(_extentMin.x, _extentMax.y, _extentMin.z);
      Gl.glVertex3f(_extentMin.x, _extentMin.y, _extentMin.z);
      Gl.glVertex3f(_extentMin.x, _extentMin.y, _extentMax.z);
      Gl.glVertex3f(_extentMin.x, _extentMin.y, _extentMax.z);
      Gl.glVertex3f(_extentMax.x, _extentMin.y, _extentMax.z);
      Gl.glVertex3f(_extentMax.x, _extentMax.y, _extentMax.z);
      Gl.glVertex3f(_extentMin.x, _extentMax.y, _extentMax.z);
      Gl.glVertex3f(_extentMin.x, _extentMin.y, _extentMax.z);
      Gl.glEnd();
      Gl.glBegin(Gl.GL_LINES);
      Gl.glVertex3f(_extentMax.x, _extentMin.y, _extentMin.z);
      Gl.glVertex3f(_extentMax.x, _extentMin.y, _extentMax.z);
      Gl.glVertex3f(_extentMax.x, _extentMax.y, _extentMin.z);
      Gl.glVertex3f(_extentMax.x, _extentMax.y, _extentMax.z);
      Gl.glVertex3f(_extentMin.x, _extentMax.y, _extentMin.z);
      Gl.glVertex3f(_extentMin.x, _extentMax.y, _extentMax.z);
      Gl.glEnd();

      // Restoring OpenGL state
      Gl.glPopAttrib();
    }

    #endregion Extents

    public Vector3D             EntityToWorldCoordinates(Vector3D point)
    {
      return (GetAbsoluteMatrix() * point);
    }

    public Vector3D             WorldToEntityCoordinates(Vector3D point)
    {
      Vector3D                  v = new Vector3D(point);
      v = v - GetPosition();
      Quaternion                qInverse = !GetQuaternion();
      v = qInverse.RotateVector(v);
      v = v * (new Vector3D(1, 1, 1) / GetScale());
      return (v);
    }

    public bool                 PointInBoundingBox(Vector3D pointInWorldCoordinates)
    {
      Vector3D                  pointInEntityCoordinates = WorldToEntityCoordinates(pointInWorldCoordinates);
      return (!(pointInEntityCoordinates.x < _extentMin.x || pointInEntityCoordinates.x > _extentMax.x ||
                pointInEntityCoordinates.y < _extentMin.y || pointInEntityCoordinates.y > _extentMax.y ||
                pointInEntityCoordinates.z < _extentMin.z || pointInEntityCoordinates.z > _extentMax.z));
    }

    #region ICloneable Members

    public virtual object          Clone()
    {
      return (new object());
    }

    #endregion

  }
}
