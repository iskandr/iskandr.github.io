//----------------------------------------------------------------------------
//  Project     : EdenArts.Graphic
//  Author      : Matthieu Dehaussy
//  Date        : 01/02/2005
//  File        : OpenglLights.cs
//  Description : OpenglLights class
//----------------------------------------------------------------------------
//  EdenArts.Graphic is a 3D graphic engine library.
//  The project is running under QPL licence.
//    (QPL Licence specifications: http://www.trolltech.com/licenses/qpl.html)
//  Zion is part of Eden Arts Team Work
//  Members are:
//      Nadim Awad        (awad_n@epitech.net)
//      Michel Courtine   (courti_m@epitech.net)
//      Matthieu Dehaussy (dehaus_m@epitech.net)
//      Julien Ferrero    (ferrer_j@epitech.net)
//      Nicolas Goubaux   (goubau_n@epitech.net)
//      Valerie Tching    (tching_v@epitech.net)
//  You can have further information on Zion website:
//         http://zion.labtech.epitech.net
//----------------------------------------------------------------------------

using System;
using System.ComponentModel;
using System.Collections;
using Tao.OpenGl;
//using EdenArts.Input;
using Joiners.Math;


namespace Joiners.Graphic
{
  /// <summary>
  /// Summary description for OpenglLights.
  /// </summary>
  public class LightInf
  {
    #region Members


    public int  OpenglLightID;
    public bool IsinUse = false;


    #endregion Members


    #region Constructors


    public LightInf()
    {
      
    }


    #endregion Constructors
  }


  public class OpenglLights
  {
    #region Members


    private LightInf[] _lights = new LightInf[7];
    private int _count = 0;


    #endregion Members


    #region Properties


    public  int  CountActivated
    {
      get{return(_count);}
    }


    public  int  CountDesActivated
    {
      get{return(7 - _count);}
    }


    #endregion Properties


    public OpenglLights()
    {
      int index;


      for (index = 0; index < 7; index++)
      {
        _lights[index] = new LightInf();
      }


      //_lights[0].OpenglLightID = Gl.GL_LIGHT0;
      //_lights[0].IsinUse = true; //for light interface
      _lights[0].OpenglLightID = Gl.GL_LIGHT1;
      _lights[1].OpenglLightID = Gl.GL_LIGHT2;
      _lights[2].OpenglLightID = Gl.GL_LIGHT3;
      _lights[3].OpenglLightID = Gl.GL_LIGHT4;
      _lights[4].OpenglLightID = Gl.GL_LIGHT5;
      _lights[5].OpenglLightID = Gl.GL_LIGHT6;
      _lights[6].OpenglLightID = Gl.GL_LIGHT7;
    }


    public int              GetALightID()
    {
      int index;
 
      for (index = 0; index < 7; index++)
      {
        if (_lights[index].IsinUse == false)
        {
          _lights[index].IsinUse = true;
          _count++;
          return (_lights[index].OpenglLightID);
        }
      }
      return (-1);
    }


    public int             SetALightID(int lightid)
    {
      if (lightid != - 1)
      {
        int index;


        for (index = 0; index < 7; index++)
        {
          if (_lights[index].OpenglLightID == lightid)
          {
            _lights[index].IsinUse = false;
            _count--;
            return (_count);
          }
        }
        return (_count);
      }
      return (_count);
    }
  }
}