//----------------------------------------------------------------------------
//  Project     : EdenArts.Graphic
//  Author      : Matthieu Dehaussy
//  Date        : 01/02/2005
//  File        : SpotLight.cs
//  Description : SpotLight class
//----------------------------------------------------------------------------
//  EdenArts.Graphic is a 3D graphic engine library.
//  The project is running under QPL licence.
//    (QPL Licence specifications: http://www.trolltech.com/licenses/qpl.html)
//  Zion is part of Eden Arts Team Work
//  Members are:
//      Nadim Awad        (awad_n@epitech.net)
//      Michel Courtine   (courti_m@epitech.net)
//      Matthieu Dehaussy (dehaus_m@epitech.net)
//      Julien Ferrero    (ferrer_j@epitech.net)
//      Nicolas Goubaux   (goubau_n@epitech.net)
//      Valerie Tching    (tching_v@epitech.net)
//  You can have further information on Zion website:
//         http://zion.labtech.epitech.net
//----------------------------------------------------------------------------

using System;
using Joiners.Math;
using Tao.OpenGl;
//using EdenArts.Interface;

namespace Joiners.Graphic
{
	/// <summary>
	/// Class derived from Light used to represent a directional light
	/// </summary>
  public class              SpotLight : Light
  {

    #region Members

    private Boolean         _spotFormCircle;
    private float           _targetDistance = 30.0f;
    private float           _attenuationEndHeight = 0.0f;
    private float           _beam = 5.0f;
    
    #endregion Members

    #region Properties

    public float            CutOff
    {
      set
      {
        _cutOff = value;
        Gl.glLightf(_openGLId, Gl.GL_SPOT_CUTOFF, _cutOff);
      }
      get{ return(_cutOff); }
    }

    public float            TargetDistance
    {
      set
      { 
        _targetDistance = value;
        CutOff = Joiners.Math.Math.RadToDeg(Joiners.Math.Math.Atan(_field / _targetDistance));
      }
      get { return (_targetDistance); }
    }

    public override bool    SpotFormCircle
    {
      set 
      {
        if (_spotFormCircle == true)
          _spotFormCircle = false;
        else
          _spotFormCircle = true;
      }
      get { return (_spotFormCircle); }
    }

    public override float   Field
    {
      set
      { 
        _field = value / 2;
        CutOff = Joiners.Math.Math.RadToDeg(Joiners.Math.Math.Atan(_field / _targetDistance));
      }
      get { return (_field * 2); }
    }

    public override float   Angle
    {
      set
      { 
        _angle = value;
        Field = Joiners.Math.Math.Tan(Joiners.Math.Math.DegToRad(_angle / 2)) * _targetDistance;
      }
      get { return (_angle); }
    }

    public override float   DirectionX{set{;} get{return(0.0f);}}
    public override float   DirectionY{set{;} get{return(0.0f);}}
    public override float   DirectionZ{set{;} get{return(0.0f);}}
    #endregion Properties
    
    #region Constructors

    public                SpotLight()
      :this(Gl.GL_LIGHT0)
    {
    }

    public                SpotLight(int openglid)
      :this(openglid, "SpotLight_1")
    {
    }

    public                SpotLight(int openglid, string name)
      :this(openglid, 0.0f, 0.0f, 0.0f, name)
    {
    }

    public                SpotLight(int openglid, float xpos, float ypos, float zpos, string name)
      :this(openglid, xpos, ypos, zpos, 90.0f, name)
    {
    }

    public                SpotLight(int openglid, float xpos, float ypos, float zpos, float angle, string name)
      :this(openglid, xpos, ypos, zpos, angle, name, -1.0f, 0.0f, 0.0f)
    {
    }

    public                SpotLight(int openglid, float xpos, float ypos, float zpos, float angle, string name,
      float xdir, float ydir, float zdir)
      :this(openglid, xpos, ypos, zpos, xdir, ydir, zdir, 0.35f, 0.35f, 0.35f, 0.35f, 0.35f, 0.35f, 0.0f, 0.0f, 0.0f, angle,  name)
    {
    }

    public                SpotLight(int openglid, float xpos, float ypos, float zpos,
      float xdir, float ydir, float zdir,
      float rambient, float gambient, float bambient,
      float rdiffuse, float gdiffuse, float bdiffuse,
      float rspecular, float gspecular, float bspecular,
      float angle, string name)
      : base()
    {
      _openGLId = openglid;
      SetPosition(xpos, ypos, zpos);
      _position.Values[3] = 1.0f;
      _direction[0] = -1.0f;
      _direction[1] = 0.0f;
      _direction[2] = 0.0f;
      Ambient.Values[0] = rambient;
      Ambient.Values[1] = gambient;
      Ambient.Values[2] = bambient;
      Diffuse.Values[0] = rdiffuse;
      Diffuse.Values[1] = gdiffuse;
      Diffuse.Values[2] = bdiffuse;
      Specular.Values[0] = rspecular;
      Specular.Values[1] = gspecular;
      Specular.Values[2] = bspecular;
      Angle = angle;
      Name = name;
    }

    public void                     Set(SpotLight spotLight)
    {
      base.Set(this);
      _spotFormCircle       = spotLight._spotFormCircle;
      _targetDistance       = spotLight._targetDistance;
      _attenuationEndHeight = spotLight._attenuationEndHeight;
      _beam                 = spotLight._beam;
    }

    #endregion Constructors

    #region Methods

    public override void             Initialize()
    {
      _type = LightType.Spotlight;
      _spotFormCircle = false;
      AttenuationStart = 1.0f;
      
      Gl.glLightfv(_openGLId, Gl.GL_AMBIENT, Ambient.Values);
      Gl.glLightfv(_openGLId, Gl.GL_DIFFUSE, Diffuse.Values);
      Gl.glLightfv(_openGLId, Gl.GL_SPECULAR, Specular.Values);
      Gl.glLightf(_openGLId, Gl.GL_SPOT_CUTOFF, _cutOff);
      //Gl.glLightf(_openGLId, Gl.GL_SPOT_EXPONENT, 10.0f);
      UpdatePosition();
      Gl.glLightfv(_openGLId, Gl.GL_SPOT_DIRECTION, _direction);
    }


    public override void    Draw()
    {
      Gl.glDisable(Gl.GL_LIGHTING);

      Gl.glPushMatrix();
        Gl.glColor3f(_colorPosition.r, _colorPosition.g, _colorPosition.b);
        Primitives.DrawCircleCone(TargetDistance, _field);
        Gl.glRotatef(90.0f, 0.0f, 1.0f, 0.0f);
        
        //Draw Field circle
        Gl.glColor3f(0.7f, 0.7f, 0.7f);
        //Gl.glColor3f(0.5f, 0.5f, 0.5f);
        Gl.glPushMatrix();
          Gl.glTranslatef(0.0f, 0.0f, -TargetDistance);
          Primitives.DrawCircle(_field, 15);
        Gl.glPopMatrix();
    
        //Draw Attenuation End Circle
        Gl.glColor3f(1.0f, 1.0f, 1.0f);
//        Gl.glColor3f(_attenuationEndColor.r, _attenuationEndColor.g, _attenuationEndColor.b);
        Gl.glPushMatrix();
          Gl.glTranslatef(0.0f, 0.0f, -_distance);
          Primitives.DrawCircle(_attenuationEndHeight, 15);
        Gl.glPopMatrix();
      Gl.glPopMatrix();
      Gl.glLightfv(_openGLId, Gl.GL_SPOT_DIRECTION, _direction);
      UpdatePosition();
      Gl.glEnable(Gl.GL_LIGHTING);
    }

    public override object Clone()
    {
      SpotLight spot = new SpotLight();
      spot.Set(this);
      spot.LightID = GraphicEngine.Instance.Scene.LightsID.GetALightID();
      spot.Activate();
      return spot;
    }


  }

  #endregion Methods
}
