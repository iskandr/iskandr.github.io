//----------------------------------------------------------------------------
//  Project     : EdenArts.Graphic
//  Author      : Matthieu Dehaussy
//  Date        : 01/02/2005
//  File        : OmniLight.cs
//  Description : OmniLight class
//----------------------------------------------------------------------------
//  EdenArts.Graphic is a 3D graphic engine library.
//  The project is running under QPL licence.
//    (QPL Licence specifications: http://www.trolltech.com/licenses/qpl.html)
//  Zion is part of Eden Arts Team Work
//  Members are:
//      Nadim Awad        (awad_n@epitech.net)
//      Michel Courtine   (courti_m@epitech.net)
//      Matthieu Dehaussy (dehaus_m@epitech.net)
//      Julien Ferrero    (ferrer_j@epitech.net)
//      Nicolas Goubaux   (goubau_n@epitech.net)
//      Valerie Tching    (tching_v@epitech.net)
//  You can have further information on Zion website:
//         http://zion.labtech.epitech.net
//----------------------------------------------------------------------------

using System;
using Joiners.Math;
using Tao.OpenGl;

namespace Joiners.Graphic
{
  /// <summary>
  /// Class derived from Light used to represent an omnidirectional light
  /// </summary>
  public class                OmniLight : Light
  {

    #region Properties  
    
    public override bool      SpotFormCircle{set{;}get{return(true);}}
    public override float     Field{set{;}get{return(0.0f);}}
    public override float     Angle{set{;}get{return(360.0f);}}
    public override float     DirectionX{set{;} get{return(0.0f);}}
    public override float     DirectionY{set{;} get{return(0.0f);}}
    public override float     DirectionZ{set{;} get{return(0.0f);}}

    #endregion Properties

    #region Constructors

    public                OmniLight()
      :this(Gl.GL_LIGHT0)
    {
    }

    public                OmniLight(int openglid)
      :this(openglid, "OmniLight_1")
    {
    }

    public                OmniLight(int openglid, string name)
      :this(openglid, 0.0f, 0.0f, 0.0f, name)
    {
    }

    public                OmniLight(int openglid, float xpos, float ypos, float zpos, string name)
      :this(openglid, xpos, ypos, zpos, name, 0.0f, 0.0f, -1.0f)
    {
    }

    public                OmniLight(int openglid, float xpos, float ypos, float zpos, string name,
      float xdir, float ydir, float zdir)
      :this(openglid, xpos, ypos, zpos, xdir, ydir, zdir, 0.35f, 0.35f, 0.35f, 0.35f, 0.35f, 0.35f, 0.0f, 0.0f, 0.0f, name)
    {
    }

    public                OmniLight(int openglid, float xpos, float ypos, float zpos,
      float xdir, float ydir, float zdir,
      float rambient, float gambient, float bambient,
      float rdiffuse, float gdiffuse, float bdiffuse,
      float rspecular, float gspecular, float bspecular,
      string name)
      : base()
    {
      _openGLId = openglid;
      SetPosition(xpos, ypos, zpos);
      _position.Values[3] = 1.0f;
      _direction[0] = xdir;
      _direction[1] = ydir;
      _direction[2] = zdir;
      Ambient.Values[0] = rambient;
      Ambient.Values[1] = gambient;
      Ambient.Values[2] = bambient;
      Diffuse.Values[0] = rdiffuse;
      Diffuse.Values[1] = gdiffuse;
      Diffuse.Values[2] = bdiffuse;
      Specular.Values[0] = rspecular;
      Specular.Values[1] = gspecular;
      Specular.Values[2] = bspecular;
      Name = name;
    }

    #endregion Constructors

    #region Methods

    public override void               Initialize()
    {
      _type = LightType.Omnilight;
      AttenuationStart = 1.0f;

      Gl.glLightfv(_openGLId, Gl.GL_AMBIENT, Ambient.Values);
      Gl.glLightfv(_openGLId, Gl.GL_DIFFUSE, Diffuse.Values);
      Gl.glLightfv(_openGLId, Gl.GL_SPECULAR, Specular.Values);
      UpdatePosition();
      Gl.glLightf(_openGLId, Gl.GL_SPOT_CUTOFF, 180.0f);
    }

    public override void      Draw()
    {
      
      
      Gl.glDisable(Gl.GL_LIGHTING);

      
      
      Gl.glPushMatrix();
      Gl.glColor3f(_colorPosition.r, _colorPosition.g, _colorPosition.b);
      Primitives.DrawPyramid(2.0f, 3.0f);
      Primitives.DrawPyramid(2.0f, -3.0f);
      
      //Draw Attenuation End Circle    1
      //Gl.glColor3f(_attenuationEndColor.r, _attenuationEndColor.g, _attenuationEndColor.b);
      //Primitives.DrawCircle(_distance, _circleNbSegments);
      

      //Draw Attenuation End Circle    2
      //Gl.glRotatef(90.0f, 0.0f, 1.0f, 0.0f);
      //Gl.glColor3f(_attenuationEndColor.r, _attenuationEndColor.g, _attenuationEndColor.b);
      //Primitives.DrawCircle(_distance, _circleNbSegments);

      //Draw Attenuation End Circle    3
      //Gl.glRotatef(90.0f, 1.0f, 0.0f, 0.0f);
      //Gl.glColor3f(_attenuationEndColor.r, _attenuationEndColor.g, _attenuationEndColor.b);
      //Primitives.DrawCircle(_distance, _circleNbSegments);
      UpdatePosition();
      Gl.glPopMatrix();
      Gl.glEnable(Gl.GL_LIGHTING);
      //Gl.glPopAttrib();
    }

    public override object    Clone()
    {
      OmniLight omni = new OmniLight();
      omni.Set(this);
      omni.LightID = GraphicEngine.Instance.Scene.LightsID.GetALightID();
      omni.Activate();
      return omni;
    }


   #endregion Methods
  }
}
