//----------------------------------------------------------------------------
//  Project     : EdenArts.Graphic
//  Author      : Matthieu Dehaussy
//  Date        : 01/02/2005
//  File        : Light.cs
//  Description : Light class
//                Base class
//                Inherited classes are: OmniLight, DirectionalLight, SpotLight
//----------------------------------------------------------------------------
//  EdenArts.Graphic is a 3D graphic engine library.
//  The project is running under QPL licence.
//    (QPL Licence specifications: http://www.trolltech.com/licenses/qpl.html)
//  Zion is part of Eden Arts Team Work
//  Members are:
//      Nadim Awad        (awad_n@epitech.net)
//      Michel Courtine   (courti_m@epitech.net)
//      Matthieu Dehaussy (dehaus_m@epitech.net)
//      Julien Ferrero    (ferrer_j@epitech.net)
//      Nicolas Goubaux   (goubau_n@epitech.net)
//      Valerie Tching    (tching_v@epitech.net)
//  You can have further information on Zion website:
//         http://zion.labtech.epitech.net
//----------------------------------------------------------------------------

using System;
using Joiners.Math;
using Tao.OpenGl;

namespace Joiners.Graphic
{
  /// <summary>
  /// Root class for spot and omni lights.
  /// </summary>
  public abstract class Light : Entity
  {
    public enum             LightType {Omnilight, Spotlight, DirectionalLight}

    #region Members

    protected LightType     _type;
    protected Color         _colorPosition = new Color(1.0f, 1.0f, 1.0f, 1.0f);
    protected float         _attenuationStart;
    protected float         _distance = 0.0f;
    protected Color         _attenuationEndColor = new Color(0.12f, 0.39f, 0.59f, 0.0f);
    protected Vector4D      _position = new Vector4D();
    protected float[]       _direction = new float[3];
    protected float         _field = 5.0f;
    protected float         _exponent = 0.0f;
    protected float         _constantAttenuation = 1.0f;
    protected float         _linearAttenuation = 0.0f;
    protected float         _quadraticAttenuation = 0.0f;
    protected float         _angle;
    protected int           _openGLId;
    protected int           _circleNbSegments = 30;
    protected bool          _isActive = false;
    protected float         _cutOff = 180.0f;

    public Vector4D         Ambient = new Vector4D(1.0f, 1.0f, 1.0f,1.0f);
    public Vector4D         Diffuse = new Vector4D(1.0f, 1.0f, 1.0f,1.0f);
    public Vector4D         Specular = new Vector4D(1.0f, 1.0f, 1.0f,1.0f);
    public float            Intensity;
    public bool             ActiveInScene = false;
    
    #endregion Members

    #region Constructors

    public                  Light()
    {
      ExtentsCompute();
    }

    public                  Light(Light light)
      : base()
    {
      Set(light);
    }

    public void             Set(Light light)
    {
      _type                 = light.Type;
      _colorPosition.Set(light._colorPosition);
      _attenuationStart     = light._attenuationStart;
      _distance             = light._distance;
      _attenuationEndColor.Set(light._attenuationEndColor);
      _position.Set(light._position);
      _direction            = light._direction;
      _field                = light._field;
      _exponent             = light._exponent;
      _constantAttenuation  = light._constantAttenuation;
      _linearAttenuation    = light._linearAttenuation;
      _quadraticAttenuation = light._quadraticAttenuation;
      _angle                = light._angle;
      _openGLId             = light._openGLId;
      _circleNbSegments     = light._circleNbSegments;
      _isActive             = light._isActive;
      _cutOff               = light._cutOff;
      Ambient.Set(light.Ambient);
      Diffuse.Set(light.Diffuse);
      Specular.Set(light.Specular);
      Intensity             = light.Intensity;
    }

    #endregion Constructors

    #region Properties

    public int              LightID
    {
      get{ return(_openGLId); }
      set{_openGLId = value;}
    }

    public float            Distance
    {
      set
      {
        _distance = value;
        if (_distance == 0.0f)
          _linearAttenuation = 0.0f;
        else
          CalculateAttenuation();
      }
    }

    public float            AttenuationStart
    {
      set
      { 
        if (value < 0.0f)
          _attenuationStart = 0.0f;
        else
        {
          _attenuationStart = value;
          CalculateAttenuation();
        }
      }
      get { return (_attenuationStart); }
    }

    public LightType        Type
    {
      get{ return(_type); }
    }

    public bool             IsActive
    {
      get{ return(_isActive); }
    }

    public abstract bool    SpotFormCircle{set; get;}
    public abstract float   Field{set; get;}
    public abstract float   Angle{set; get;}

    public abstract float   DirectionX{set; get;}
    public abstract float   DirectionY{set; get;}
    public abstract float   DirectionZ{set; get;}

    #endregion Properties

    #region Methods
    
    public abstract void    Initialize();

    private void            UpdateAllParams()
    {
      Gl.glLightfv(_openGLId, Gl.GL_AMBIENT, Ambient.Values);
      Gl.glLightfv(_openGLId, Gl.GL_DIFFUSE, Diffuse.Values);
      Gl.glLightfv(_openGLId, Gl.GL_SPECULAR, Specular.Values);
      Gl.glLightf(_openGLId, Gl.GL_SPOT_CUTOFF, _cutOff);
      Gl.glLightf(_openGLId, Gl.GL_SPOT_EXPONENT, 10.0f);
      _position.Set(GetPosition());
      Gl.glLightfv(_openGLId, Gl.GL_POSITION, _position.Values);
      Gl.glLightfv(_openGLId, Gl.GL_SPOT_DIRECTION, _direction);
    }

    public void             Activate()
    {
      Gl.glEnable(_openGLId);
      UpdateAllParams();
      _isActive = true;
    }

    public void             Desactivate()
    {
      Gl.glDisable(_openGLId);
      _isActive = false;
    }

    public void             IsSelected(bool isselected)
    {
      if (isselected == true)
        _colorPosition.SetRGBA(1.0f, 0.0f, 0.0f, 1.0f);
      else
        _colorPosition.SetRGBA(1.0f, 1.0f, 1.0f, 1.0f);
    }

    public void             UpdateAmbient()
    {
      Gl.glLightfv(_openGLId, Gl.GL_AMBIENT, Ambient.Values);
    }

    public void             UpdateDiffuse()
    {
      Gl.glLightfv(_openGLId, Gl.GL_DIFFUSE, Diffuse.Values);
    }

    public void             UpdateSpecular()
    {
      Gl.glLightfv(_openGLId, Gl.GL_SPECULAR, Specular.Values);
    }

    public void             UpdatePosition()
    {
      _position.Set(GetPosition());
      Gl.glLightfv(_openGLId, Gl.GL_POSITION, _position.Values);
    }

    public void             UpdateAttenuation()
    {
      Gl.glLightf(_openGLId, Gl.GL_CONSTANT_ATTENUATION, _constantAttenuation);
      Gl.glLightf(_openGLId, Gl.GL_LINEAR_ATTENUATION, _linearAttenuation);
    }

    private void            CalculateAttenuation()
    {
      _constantAttenuation = 100 / _attenuationStart;
      if (_distance != 0.0f)
        _linearAttenuation = (1.0f - _constantAttenuation) / _distance;
      else
        _linearAttenuation = 0.0f;
    }

    private float            GetIntensityAtDistance(float distance)
    {
      float intensity;

      intensity = 1 * ((_constantAttenuation + (_linearAttenuation * distance)) / 100);

      return (intensity);
    }

    #endregion Methods

    public override void      ExtentsCompute()
    {
      _extentMin.Set(-1, -1, -1);
      _extentMax.Set(1, 1, 1);
    }

  }
}
