//----------------------------------------------------------------------------
//  Project     : EdenArts.Graphic
//  Author      : Matthieu Dehaussy
//  Date        : 01/02/2005
//  File        : DirectionalLight.cs
//  Description : DirectionalLight class
//----------------------------------------------------------------------------
//  EdenArts.Graphic is a 3D graphic engine library.
//  The project is running under QPL licence.
//    (QPL Licence specifications: http://www.trolltech.com/licenses/qpl.html)
//  Zion is part of Eden Arts Team Work
//  Members are:
//      Nadim Awad        (awad_n@epitech.net)
//      Michel Courtine   (courti_m@epitech.net)
//      Matthieu Dehaussy (dehaus_m@epitech.net)
//      Julien Ferrero    (ferrer_j@epitech.net)
//      Nicolas Goubaux   (goubau_n@epitech.net)
//      Valerie Tching    (tching_v@epitech.net)
//  You can have further information on Zion website:
//         http://zion.labtech.epitech.net
//----------------------------------------------------------------------------

using System;
using Joiners.Math;
using Tao.OpenGl;

namespace Joiners.Graphic
{
  /// <summary>
  /// Class derived from Light used to represent a directional light
  /// </summary>
  public class                DirectionalLight : Light
  {
    #region Properties  
    
    public override bool      SpotFormCircle{set{;}get{return(true);}}
    public override float     Field{set{;}get{return(0.0f);}}
    public override float     Angle{set{;}get{return(360.0f);}}
    public override float     DirectionX{set{;} get{return(0.0f);}}
    public override float     DirectionY{set{;} get{return(0.0f);}}
    public override float     DirectionZ{set{;} get{return(0.0f);}}

    #endregion Properties

    #region Constructors

    public                DirectionalLight()
      :this(Gl.GL_LIGHT0)
    {
    }

    public                DirectionalLight(int openglid)
      :this(openglid, "DirectionalLight_1")
    {
    }

    public                DirectionalLight(int openglid, string name)
      :this(openglid, -1.0f, -1.0f, 0.1f, name)
    {
    }

    public                DirectionalLight(int openglid, float xdir, float ydir, float zdir, string name)
      :this(openglid, xdir, ydir, zdir, 0.35f, 0.35f, 0.35f, 0.35f, 0.35f, 0.35f, 0.0f, 0.0f, 0.0f, name)
    {
    }

    public                DirectionalLight(int openglid, float xdir, float ydir, float zdir,
      float rambient, float gambient, float bambient,
      float rdiffuse, float gdiffuse, float bdiffuse,
      float rspecular, float gspecular, float bspecular,
      string name)
      : base()
    {
      _openGLId = openglid;
      SetPosition(xdir, ydir, zdir);
      _position.Values[3] = 0.0f;
      Ambient.Values[0] = rambient;
      Ambient.Values[1] = gambient;
      Ambient.Values[2] = bambient;
      Diffuse.Values[0] = rdiffuse;
      Diffuse.Values[1] = gdiffuse;
      Diffuse.Values[2] = bdiffuse;
      Specular.Values[0] = rspecular;
      Specular.Values[1] = gspecular;
      Specular.Values[2] = bspecular;
      Name = name;
    }

    #endregion Constructors

    #region Methods

    public override void               Initialize()
    {
      _type = LightType.DirectionalLight;

      UpdateAmbient();
      UpdateDiffuse();
      UpdateSpecular();
      UpdatePosition();
      Gl.glLightf(_openGLId, Gl.GL_SPOT_CUTOFF, 180.0f);
    }
    
    public override void              Place()
    {
    }

    public override void              Draw()
    {
      Gl.glDisable(Gl.GL_LIGHTING);
      Gl.glLineWidth(5.0f);
      Gl.glBegin(Gl.GL_LINES);
        Gl.glColor3f(_colorPosition.r, _colorPosition.g, _colorPosition.b);
        Gl.glVertex3f(0.0f, 0.0f, 0.0f);
        //Gl.glVertex3f(_position.Values[0] * 10, _position.Values[1] * 10, _position.Values[2] * 10);
        Vector3D  position = GetPosition();
        Gl.glVertex3f(position.x * 10, position.y * 10, position.z * 10);
      Gl.glEnd();
      Gl.glLineWidth(1.0f);
      Gl.glLightfv(_openGLId, Gl.GL_POSITION, _position.Values);
      UpdatePosition();
      Gl.glEnable(Gl.GL_LIGHTING);
    }

    public override object Clone()
    {
      DirectionalLight directional = new DirectionalLight();
      directional.Set(this);
      directional.LightID = GraphicEngine.Instance.Scene.LightsID.GetALightID();
      directional.Activate();
      return directional;
    }


    #endregion Methods
  }
}
