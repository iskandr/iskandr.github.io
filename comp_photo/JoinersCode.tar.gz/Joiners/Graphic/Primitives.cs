//----------------------------------------------------------------------------
//  Project     : EdenArts.Graphic
//  Author      : Matthieu Dehaussy
//  Date        : 01/02/2005
//  File        : Primitives.cs
//  Description : Primitives class
//----------------------------------------------------------------------------
//  EdenArts.Graphic is a 3D graphic engine library.
//  The project is running under QPL licence.
//    (QPL Licence specifications: http://www.trolltech.com/licenses/qpl.html)
//  Zion is part of Eden Arts Team Work
//  Members are:
//      Nadim Awad        (awad_n@epitech.net)
//      Michel Courtine   (courti_m@epitech.net)
//      Matthieu Dehaussy (dehaus_m@epitech.net)
//      Julien Ferrero    (ferrer_j@epitech.net)
//      Nicolas Goubaux   (goubau_n@epitech.net)
//      Valerie Tching    (tching_v@epitech.net)
//  You can have further information on Zion website:
//         http://zion.labtech.epitech.net
//----------------------------------------------------------------------------

using System;
using Joiners.Math;
using Tao.OpenGl;

namespace Joiners.Graphic
{
	/// <summary>
	/// Global primitives class containing function for drawing circle, square, etc..
	/// </summary>
	public sealed class Primitives
	{
    #region Constructors

		public Primitives()
		{
		}
    #endregion Constructors

    #region 2D Primitives Functions

    #region Circle

    public static void            DrawCircle(float radius, int nbSegments)
    {
      DrawCircle(0.0f, 0.0f, 0.0f, radius, nbSegments);
    }

    public static void            DrawCircle(float x, float y, float z, float radius, int nbSegments)
    {
      float newX;
      float newY;

      Gl.glBegin(Gl.GL_LINE_STRIP);
      Gl.glVertex3f(radius + x, y, z);
      for (int i = 1; i < nbSegments; i++)
      {
        newX = (float)(radius * System.Math.Cos(i * Joiners.Math.Math.PIMULT2 / nbSegments)) + x;
        newY = (float)(radius * System.Math.Sin(i * Joiners.Math.Math.PIMULT2 / nbSegments)) + y;
        Gl.glVertex3f(newX, newY, 0.0f);
      }
      Gl.glVertex3f(radius + x, y, z);
      Gl.glEnd();
    }

    #endregion Circle

    #region partial circle

    public static void            DrawPartialCircle(float radius, int nbPrecisionSegments, int nbSegments)
    {
      DrawPartialCircle(0.0f, 0.0f, 0.0f, radius, nbPrecisionSegments, nbSegments);
    }

    public static void            DrawPartialCircle(float x, float y, float z, float radius, int nbPrecisionSegments, int nbSegments)
    {
      float lastX;
      float lastY;
      float newX;
      float newY;

      Gl.glBegin(Gl.GL_LINE_STRIP);
      Gl.glVertex3f(radius + x, y, z);
      for (int i = 1; i < nbSegments; i++)
      {
        newX = (float)(radius * System.Math.Cos(i * Joiners.Math.Math.PIMULT2 / nbPrecisionSegments)) + x;
        newY = (float)(radius * System.Math.Sin(i * Joiners.Math.Math.PIMULT2 / nbPrecisionSegments)) + y;
        Gl.glVertex3f(newX, newY, 0.0f);
        lastX = newX;
        lastY = newY;
      }
      Gl.glVertex3f(radius + x, y, z);
      Gl.glEnd();
    }

    #endregion partial circle

    #region Square

    public static void            DrawSquare(float width)
    {
      DrawSquare(0.0f, 0.0f, 0.0f, width);
    }
    
    public static void            DrawSquare(float x, float y, float z, float width)
    {
      Gl.glBegin(Gl.GL_LINE_STRIP);
      Gl.glVertex3f(x, y+width, z+width);
      Gl.glVertex3f(x, y+width, z-width);
      Gl.glVertex3f(x, y-width, z-width);
      Gl.glVertex3f(x, y-width, z+width);
      Gl.glVertex3f(x, y+width, z+width);
      Gl.glEnd();

      Gl.glBegin(Gl.GL_LINE_STRIP);
      Gl.glVertex3f(x, z+width, z+width);
      Gl.glVertex3f(x, z+width, z-width);
      Gl.glVertex3f(x, z-width, z-width);
      Gl.glVertex3f(x, z-width, z+width);
      Gl.glVertex3f(x, z+width, z+width);
      Gl.glEnd();
    }
 
    #endregion Square

    #region Rectangle

    

    #endregion Rectangle

    #endregion 2D Primitives Functions

    #region 3D Primitives Functions

    #region Cube

    public static void            DrawCube(float size)
    {
      float   halfsize = size / 2.0f;

      Gl.glBegin(Gl.GL_LINE_STRIP);
      Gl.glVertex3f(-halfsize,  halfsize,  halfsize);
      Gl.glVertex3f( halfsize,  halfsize,  halfsize);
      Gl.glVertex3f( halfsize, -halfsize,  halfsize);
      Gl.glVertex3f(-halfsize, -halfsize,  halfsize);
      Gl.glVertex3f(-halfsize,  halfsize,  halfsize);
      Gl.glEnd();

      Gl.glBegin(Gl.GL_LINE_STRIP);
      Gl.glVertex3f(-halfsize,  halfsize, -halfsize);
      Gl.glVertex3f( halfsize,  halfsize, -halfsize);
      Gl.glVertex3f( halfsize, -halfsize, -halfsize);
      Gl.glVertex3f(-halfsize, -halfsize, -halfsize);
      Gl.glVertex3f(-halfsize,  halfsize, -halfsize);
      Gl.glEnd();

      Gl.glBegin(Gl.GL_LINES);
      Gl.glVertex3f(-halfsize,  halfsize,  halfsize);
      Gl.glVertex3f(-halfsize,  halfsize, -halfsize);
      Gl.glVertex3f(-halfsize, -halfsize,  halfsize);
      Gl.glVertex3f(-halfsize, -halfsize, -halfsize);
      Gl.glVertex3f( halfsize,  halfsize,  halfsize);
      Gl.glVertex3f( halfsize,  halfsize, -halfsize);
      Gl.glVertex3f( halfsize, -halfsize,  halfsize);
      Gl.glVertex3f( halfsize, -halfsize, -halfsize);
      Gl.glEnd();

    }

    public static Mesh            CreateBox(float width, float height, float depth)
    {
      Mesh                        mesh = new Mesh();

      mesh.Vertices.Add(new MetaVertex(-width/2,  depth/2, height/2));
      mesh.Vertices.Add(new MetaVertex( width/2,  depth/2, height/2));
      mesh.Vertices.Add(new MetaVertex( width/2,  depth/2, -height/2));
      mesh.Vertices.Add(new MetaVertex(-width/2,  depth/2, -height/2));

      mesh.Faces.Add(new Face(0, 2, 1));
      mesh.Faces.Add(new Face(0, 3, 2));

      mesh.CalculateAllNormals();
      mesh.ExtentsCompute();
      mesh.BuildInterleavedArray();

      mesh.Material = new Material();
      mesh.Material.SetToRandom();

      return mesh;
    }

    #endregion Cube

    #region Pyramid

    public static void            DrawPyramid(float width, float height)
    {
      DrawPyramid(0.0f, 0.0f, 0.0f, width, height);
    }

    public static void            DrawPyramid(float x, float y, float z, float width, float height)
    {
      float rwidth = width / 2;

      Gl.glPolygonMode(Gl.GL_FRONT_AND_BACK, Gl.GL_LINE);
      Gl.glEnable(Gl.GL_POLYGON_OFFSET_LINE);

      Gl.glBegin(Gl.GL_LINE_STRIP);
      Gl.glVertex3f(x, height + y, z);
      Gl.glVertex3f(-rwidth + x, y, rwidth + z);
      Gl.glVertex3f(rwidth + x, y, rwidth + z);
      Gl.glVertex3f(x, height + y, z);
      Gl.glVertex3f(-rwidth + x, y, -rwidth + z);
      Gl.glVertex3f(rwidth + x, y, -rwidth + z);
      Gl.glVertex3f(x, height + y, z);
      Gl.glEnd();
      Gl.glBegin(Gl.GL_LINES);
      Gl.glVertex3f(-rwidth + x, y, rwidth + z);
      Gl.glVertex3f(-rwidth + x, y, -rwidth + z);
      Gl.glVertex3f(rwidth + x, y, -rwidth + z);
      Gl.glVertex3f(rwidth + x, y, rwidth + z);
      Gl.glEnd();

      Gl.glDisable(Gl.GL_POLYGON_OFFSET_LINE);
      Gl.glPolygonMode(Gl.GL_FRONT_AND_BACK, Gl.GL_FILL);
    }

    #endregion Pyramid

    #region Square Cone

    public static void            DrawSquareCone(float distance, float radius)
    {
      DrawSquareCone(0.0f, 0.0f, 0.0f, distance, radius);
    }

    public static void            DrawSquareCone(float x, float y, float z, float distance, float radius)
    {
      Gl.glBegin(Gl.GL_LINES);
      Gl.glVertex3f(x, y, z);
      Gl.glVertex3f(x - distance, y - radius, z - radius);
      Gl.glVertex3f(x, y, z);
      Gl.glVertex3f(x - distance, y + radius, z + radius);
      Gl.glVertex3f(x, y, z);
      Gl.glVertex3f(x - distance, y - radius, z + radius);
      Gl.glVertex3f(x, y, z);
      Gl.glVertex3f(x - distance, y + radius, z - radius);
      Gl.glEnd();
    }

    #endregion Square Cone

    #region Circle cone

    public static void            DrawCircleCone(float distance, float radius)
    {
      DrawCircleCone(0.0f, 0.0f, 0.0f, distance, radius);
    }

    public static void            DrawCircleCone(float x, float y, float z, float distance, float radius)
    {
      Gl.glBegin(Gl.GL_LINES);
      Gl.glVertex3f(x, y, z);
      Gl.glVertex3f(x - distance, y, z - radius);  
      Gl.glVertex3f(x, y, z);
      Gl.glVertex3f(x - distance, y, z + radius);  
      Gl.glVertex3f(x, y, z);
      Gl.glVertex3f(x - distance, y - radius, z);
      Gl.glVertex3f(x, y, z);
      Gl.glVertex3f(x - distance, y + radius, z);
      Gl.glEnd();
    }

    #endregion Circle cone

    #endregion 3D Primitives Functions
	}
}
