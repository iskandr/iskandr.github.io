using System;
using Joiners.Math;

namespace Joiners.Graphic
{
  /// <summary>
  /// Summary description for Drawable.
  /// </summary>
  public abstract class         Drawable : Transformable, IDrawable, ICloneable
  {
    #region Members

    protected string            _name       = String.Empty;
    protected Vector3D          _extentMin  = new Vector3D();
    protected Vector3D          _extentMax  = new Vector3D();
    protected Vector3D          _center     = new Vector3D();
    protected bool              _visible    = true;
    protected bool              _editable   = false;

    #endregion // Members

    #region Properties

    public string               Name
    {
      get { return (_name); }
      set { _name = value;  }
    }

    public Vector3D             ExtentMin
    {
      get { return (_extentMin); }
      set { _extentMin = value; }
    }

    public Vector3D             ExtentMax
    {
      get { return (_extentMax); }
      set { _extentMax = value; }
    }

    public Vector3D             Center
    {
      get { return (_center); }
      set { _center = value;  }
    }

    public bool                 Visible
    {
      get { return (_visible); }
      set { _visible = value;  }
    }

    public bool                 Editable
    {
      get { return (_editable); }
      set { _editable = value;  }
    }

    public Vector3D []          ExtentsPoints
    {
      get
      {
        Vector3D []         points = new Vector3D[8];
        points[0].x = ExtentMin.x; points[0].y = ExtentMin.y; points[0].z = ExtentMin.z;
        points[1].x = ExtentMin.x; points[1].y = ExtentMax.y; points[1].z = ExtentMin.z;
        points[2].x = ExtentMax.x; points[2].y = ExtentMin.y; points[2].z = ExtentMin.z;
        points[3].x = ExtentMax.x; points[3].y = ExtentMax.y; points[3].z = ExtentMin.z;
        points[4].x = ExtentMin.x; points[4].y = ExtentMin.y; points[4].z = ExtentMax.z;
        points[5].x = ExtentMin.x; points[5].y = ExtentMax.y; points[5].z = ExtentMax.z;
        points[6].x = ExtentMax.x; points[6].y = ExtentMin.y; points[6].z = ExtentMax.z;
        points[7].x = ExtentMax.x; points[7].y = ExtentMax.y; points[7].z = ExtentMax.z;
        return (points);
      }
    }

    #endregion // Properties

    #region Initialization
    public void                 Set(Drawable drawable)
    {
      _name       = drawable.Name;
      SetGeometry(drawable);
      _extentMin  = drawable.ExtentMin;
      _extentMax  = drawable.ExtentMax;
      _center     = drawable.Center;
    }

    #endregion  // Initialization

    #region IDrawable Members

    public abstract void         Draw();

    #endregion

    #region Extents

    public abstract void         ExtentsCompute();

    #endregion Extents

    #region ICloneable Members

    public abstract object       Clone();

    #endregion
  }
}
