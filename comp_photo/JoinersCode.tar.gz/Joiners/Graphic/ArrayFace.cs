//----------------------------------------------------------------------------
//  Project     : EdenArts.Graphic
//  Author      : Michel Courtine
//  Date        : 01/02/2005
//  File        : ArrayFace.cs
//  Description : ArrayFace class
//----------------------------------------------------------------------------
//  EdenArts.Graphic is a 3D graphic engine library.
//  The project is running under QPL licence.
//    (QPL Licence specifications: http://www.trolltech.com/licenses/qpl.html)
//  Zion is part of Eden Arts Team Work
//  Members are:
//      Nadim Awad        (awad_n@epitech.net)
//      Michel Courtine   (courti_m@epitech.net)
//      Matthieu Dehaussy (dehaus_m@epitech.net)
//      Julien Ferrero    (ferrer_j@epitech.net)
//      Nicolas Goubaux   (goubau_n@epitech.net)
//      Valerie Tching    (tching_v@epitech.net)
//  You can have further information on Zion website:
//         http://zion.labtech.epitech.net
//----------------------------------------------------------------------------

using System;
using System.Collections;
using System.Diagnostics;
using Joiners.Graphic;
using Joiners.Math;

namespace Joiners.Graphic
{
  /// <summary>
  /// Array Face Enumerator
  /// This class allows Array walking with foreach keyword
  /// </summary>
  public class ArrayFaceEnumerator : IEnumerator
  {

    #region Members

    private ArrayFace   _data;
    private IEnumerator _dataEnumerator;
    private int         _last;
    private int         _indexCurrent;

    #endregion Members

    #region Constructors

    public              ArrayFaceEnumerator(ArrayFace data)
    {
      _data = data;
      _last = data.Last;
      Reset();
    }

    #endregion Constructors

    #region IEnumerator Members

    public void         Reset()
    {
      _dataEnumerator = _data.Items.GetEnumerator();
      _dataEnumerator.Reset();
      _indexCurrent = -1;
    }

    public object       Current
    {
      get
      {
        // TODO: Current Index must be check but for performance question, this is not done
        return _dataEnumerator.Current;
      }
    }

    public bool         MoveNext()
    {
      _indexCurrent++;
      if (_indexCurrent >= _last)
        return (false);
      _dataEnumerator.MoveNext();
      if (_dataEnumerator.Current != null)
        return (true);
      while (_indexCurrent < _last && _dataEnumerator.MoveNext() && _dataEnumerator.Current == null)
        _indexCurrent++;
      return (_indexCurrent < _last);
    }

    #endregion

    public bool         MoveRealNext()
    {
      _indexCurrent++;
      if (_indexCurrent >= _last)
        return (false);
      _dataEnumerator.MoveNext();
      return (true);
    }

  }

  /// <summary>
  /// Dynamic buffered array of Face
  /// </summary>
  public class ArrayFace : ICloneable
  {

    #region Members

    private Face []   _items;
    private ArrayList _freeItems = new ArrayList();
    private int       _size;
    private int       _bufferSize;
    private int       _last;
    private int				_count;

    #endregion Members

    #region Properties

    public Face [] Items
    {
      get { return (_items); }
    }

    /// <summary>
    /// Returns the last added elements' index + 1
    /// </summary>
    public int        Last
    {
      get { return _last; }
    }

    /// <summary>
    /// Returns the number of elements
    /// </summary>
    public int				Count
    {
      get { return _count; }
    }

    /// <summary>
    /// Operator [] to access to the i-th element
    /// </summary>
    public Face	      this[int index]
    {
      get { return(_items[index]); }
      set { _items[index] = value; }
    }

    #endregion Properties

    #region Constructors

    public            ArrayFace()
      : this (0, 256)
    {
    }

    public            ArrayFace(int size)
      : this (size, 256)
    {
    }

    public            ArrayFace(int size, int bufferSize)
    {
      _size = size;
      _bufferSize = bufferSize;
      _items = new Face[_size];
    }

    #endregion Constructors

    #region Events

    public event EventHandler ArrayChanged;

    #endregion Events

    #region Element manipulations

    /// <summary>
    /// Find a specified face
    /// </summary>
    /// <param name="face"></param>
    /// <returns>returns -1 if item not found, else returns item index</returns>
    public int 				Find(Face face)
    {
      for (int i = 0; i < _size; i++)
        if (_items[i] == face)
          return i;
      return -1;
    }

    public int        Add(Face face)
    {
      _count++;
      // Check if there is an element in free items
      if (_freeItems.Count > 0)
      {
        // Get first free index
        int index = (int)_freeItems[0];
        _items[index] = face;
        _freeItems.RemoveAt(0);
        if (ArrayChanged != null)
          ArrayChanged(this, new EventArgs());
        return index;
      }
      // If data array is too small, grow it
      if (_last >= _size)
        Resize(_size + _bufferSize);
      // Add the element in the data array
      _items[_last++] = face;
      if (ArrayChanged != null)
        ArrayChanged(this, new EventArgs());
      return (_last - 1);
    }

    public void       AddRange(ArrayFace faceArray)
    {
      int             nbNewElts = faceArray.Count;
      int             faceArrayIndex = 0;
      // Check if there is an element in free items
      _count += nbNewElts;
      if (_freeItems.Count > 0)
      {
        for (faceArrayIndex = 0; faceArrayIndex < nbNewElts && _freeItems.Count > 0; faceArrayIndex++)
        {
          int index = (int)_freeItems[0];
          _items[index] = faceArray[faceArrayIndex];
          _freeItems.RemoveAt(0);
        }
        if (faceArrayIndex == nbNewElts && ArrayChanged != null)
        {
          ArrayChanged(this, new EventArgs());
          return ;
        }
      }
      // If data array is too small, grow it
      if (_last + (nbNewElts - faceArrayIndex) >= _size)
        Resize(_size + (((nbNewElts - faceArrayIndex) / _bufferSize) + 1) * _bufferSize);
      // Add the elements in the data array
      while (faceArrayIndex < nbNewElts)
      {
        _items[_last++] = faceArray[faceArrayIndex++];
      }
      if (ArrayChanged != null)
        ArrayChanged(this, new EventArgs());
    }

    public void       Remove(int index)
    {
      if (_count == 0)
        return;
      _items[index] = null;
      _count--;
      if (index == _last - 1)
        _last--;
      else
        _freeItems.Add(index);
      if (ArrayChanged != null)
        ArrayChanged(this, new EventArgs());
    }

    // NOTE: This is correct only for the references that has an index member
    public void				Remove(Face face)
    {
      if (_count == 0)
        return;
      _count--;
      _items[face.index] = null;
      if (face.index == _last - 1)
        _last--;
      else
        _freeItems.Add(face.index);
      if (ArrayChanged != null)
        ArrayChanged(this, new EventArgs());
    }

    #endregion Element manipulations

    #region Array manipulations

    public int        Resize(int size)
    {
      _size = size;
      Face [] array = new Face[_size];
      _items.CopyTo(array, 0);
      _items = array;
      return (_size);
    }

    //    public ArrayFace  Clone()
    //    {
    //      ArrayFace array = new ArrayFace(_size, _bufferSize);
    //      array._freeItems = (ArrayList)_freeItems.Clone();
    //      array._last = _last;
    //      array._count = _count;
    //      return (array);
    //    }

    public object     Clone()
    {
      ArrayFace newItems = new ArrayFace();
      
      newItems._items = new Face[_size];
      newItems._freeItems = (ArrayList)_freeItems.Clone();
      newItems._size = _size;
      newItems._bufferSize = _bufferSize;
      newItems._last = _last;
      newItems._count = _count;

      for (int i = 0; i < _size; i++)
      {
        if (_items[i] != null)
          newItems._items[i] = (Face)_items[i].Clone();
      }

      if (ArrayChanged != null)
        newItems.ArrayChanged = (EventHandler)ArrayChanged.Clone();

      return newItems;
    }

    public void				Clear()
    {
      // TODO: Test if this works, Ask shaman
      //      foreach (Face face in _items)
      //        face = null;
      for (int i = 0; i < _last; i++)
        _items[i] = null;
      _last = 0;
      _count = 0;
      _freeItems.Clear();
      if (ArrayChanged != null)
        ArrayChanged(this, new EventArgs());
    }

    #endregion Array manipulations

    public IEnumerator GetEnumerator()
    {
      return (new ArrayFaceEnumerator(this));
    }

    public void       TraceArray()
    {
      Trace.WriteLine("Array Size: " + _size);
      Trace.WriteLine("Buffer Size: " + _bufferSize);
      Trace.WriteLine("Free Items Count: " + _freeItems.Count);
      foreach (Face face in _items)
      {
        if (face == null)
          Trace.WriteLine("Empty Slot !!!");
        else
          Trace.WriteLine(face.ToString());
      }
    }
  }
}
