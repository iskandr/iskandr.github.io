//----------------------------------------------------------------------------
//  Project     : EdenArts.Graphic
//  Author      : Michel Courtine
//  Date        : 01/02/2005
//  File        : GraphicEngine.cs
//  Description : GraphicEngine class
//----------------------------------------------------------------------------
//  EdenArts.Graphic is a 3D graphic engine library.
//  The project is running under QPL licence.
//    (QPL Licence specifications: http://www.trolltech.com/licenses/qpl.html)
//  Zion is part of Eden Arts Team Work
//  Members are:
//      Nadim Awad        (awad_n@epitech.net)
//      Michel Courtine   (courti_m@epitech.net)
//      Matthieu Dehaussy (dehaus_m@epitech.net)
//      Julien Ferrero    (ferrer_j@epitech.net)
//      Nicolas Goubaux   (goubau_n@epitech.net)
//      Valerie Tching    (tching_v@epitech.net)
//  You can have further information on Zion website:
//         http://zion.labtech.epitech.net
//----------------------------------------------------------------------------

using System;
using System.Collections;
using System.ComponentModel;
using Tao.OpenGl;
using Joiners.Math;

namespace Joiners.Graphic
{

  #region Enums

  public enum             DrawType
  {
    None,
    WireFrame,
    WireFrameHighlight,
    //      Facet,
    FacetHighlight,
    Smooth,
    SmoothHighlight,
    Textured,
    CallList,
    Last,
  }

  #endregion Enums 
  
  /// <summary>
	/// Class representing the entire graphic engine with references on the scene
	/// </summary>
	public class                            GraphicEngine
	{

    #region Members

    static private volatile GraphicEngine _instance;

    private int                           _viewWidth;             // View Width
    private int                           _viewHeight;            // View Height
    private float                         _fieldOfViewY = 45.0f;  // Field of view angle, in degrees, in the y-direction
    private float                         _aspectRatio  = 1.0f;   // Aspect Ratio of the field of view
    private float                         _zNear        = 1.0f;   // Near Clipping Plane Distance
    private float                         _zFar         = 700.0f; // Far Clipping Plane Distance
    private Matrix4D                      _projectionMatrix  = new Matrix4D();
    private int []                        _viewport          = new int[4];
    public Scene                          Scene;
    public TextureManager                 TextureManager = new TextureManager();

    #endregion Members

    #region Constructors

    private                               GraphicEngine()
    {

    }

    #endregion Constructors

    #region Properties

    static public GraphicEngine           Instance
    {
      get
      {
        if (_instance == null)
        {
          lock(typeof(GraphicEngine))
          {
            if (_instance == null)
              _instance = new GraphicEngine();
          }
        }
        return _instance;
      }
    }


    public int                            ViewWidth
    {
      get { return (_viewWidth); }
    }
    public int                            ViewHeight
    {
      get { return (_viewHeight); }
    }

    public float                          FieldOfViewY
    {
      get { return (_fieldOfViewY); }
    }
    public float                          AspectRatio
    {
      get { return (_aspectRatio); }
    }

    #endregion Properties

    #region Initialization && Uninitialization

    public bool                   Initialize(int width, int height)
    {
      ResizeWindow(width, height);

      Gl.glShadeModel(Gl.GL_SMOOTH);
      Gl.glClearColor(0.0f,0.0f,0.0f,0.0f);
      Gl.glClearDepth(1.0f);
      Gl.glEnable(Gl.GL_DEPTH_TEST);
      Gl.glCullFace(Gl.GL_FRONT);
      Gl.glFrontFace(Gl.GL_CW);
      Gl.glEnable(Gl.GL_CULL_FACE);
      Gl.glDepthFunc(Gl.GL_LEQUAL);
      Gl.glHint(Gl.GL_PERSPECTIVE_CORRECTION_HINT, Gl.GL_NICEST);
//      Gl.glPolygonOffset(1, -1.0f);

      Gl.glBlendFunc(Gl.GL_SRC_ALPHA, Gl.GL_ONE_MINUS_SRC_ALPHA);

      return (true);
     }

    public void                   ResizeWindow(int width, int height)
    {
      double []                   projectionMatrix = new double[16];

      _viewWidth = width; _viewHeight = height;
      _aspectRatio = (float)_viewWidth / (float) _viewHeight;
      if (_aspectRatio == 0)
        _aspectRatio = 1.0f;
      Gl.glViewport(0, 0, _viewWidth, _viewHeight);
      Gl.glGetIntegerv(Gl.GL_VIEWPORT, _viewport);
      Gl.glMatrixMode(Gl.GL_PROJECTION);
      Gl.glLoadIdentity();
      Glu.gluPerspective(_fieldOfViewY, _aspectRatio, _zNear, _zFar);
      Gl.glGetDoublev(Gl.GL_PROJECTION_MATRIX, projectionMatrix);
      for (int i = 0; i < 16; i++)
        _projectionMatrix.Values[i] = (float)projectionMatrix[i];
      Gl.glMatrixMode(Gl.GL_MODELVIEW);
      Gl.glLoadIdentity();
    }

    #endregion Initialization && Uninitialization

    #region Projection

    public float                  GetPlaneHeight(float depth)
    {
      return ((float)(depth * System.Math.Tan(Math.Math.DegToRad(_fieldOfViewY))));
    }

    public float                  GetPlaneWidth(float depth)
    {
      return (/*_aspectRatio */ GetPlaneHeight(depth));
    }

    public Vector3D               Project(Vector3D point)
    {
      double []                   modelMatrix       = new double[16];
      double []                   projectionMatrix  = new double[16];
      double                      x, y, z;

      Gl.glGetDoublev(Gl.GL_MODELVIEW_MATRIX,  modelMatrix);
      for (int i = 0; i < 16; i++)
        projectionMatrix[i] = _projectionMatrix.Values[i];
      Glu.gluProject(point.x, point.y, point.z, modelMatrix, projectionMatrix, _viewport, out x, out y, out z);
      return (new Vector3D((float)x, (float)y, (float)z));
    }

    public Vector3D               Project(Matrix4D localModelMatrix, Vector3D point)
    {
      Matrix4D                    sceneMatrix = new Matrix4D();
      Matrix4D                    cameraMatrix = new Matrix4D();
      double []                   modelMatrix       = new double[16];
      double []                   projectionMatrix  = new double[16];
      double                      x, y, z;

      sceneMatrix.FromEuler(-90.0f, 0.0f, 0.0f);
      sceneMatrix.Multiply(localModelMatrix);
      sceneMatrix.Transpose();
      for (int i = 0; i < 16; i++)
        modelMatrix[i] = sceneMatrix.Values[i];
      for (int i = 0; i < 16; i++)
        projectionMatrix[i] = _projectionMatrix.Values[i];
      Glu.gluProject(point.x, point.y, point.z, modelMatrix, projectionMatrix, _viewport, out x, out y, out z);
      return (new Vector3D((float)x, (float)y, (float)z));
    }

    public Vector3D UnProject(Vector3D point)
    {
      SwitchTo2DMode();
      double[] modelMatrix = new double[16];
      double[] projectionMatrix = new double[16];
      double x, y, z;
      double[] winZ = new double[1];

      Gl.glGetDoublev(Gl.GL_MODELVIEW_MATRIX, modelMatrix);
      for (int i = 0; i < 16; i++)
        projectionMatrix[i] = _projectionMatrix.Values[i];
      Gl.glReadPixels((int)point.x, (int)(point.y), 1, 1, Gl.GL_DEPTH_COMPONENT, Gl.GL_FLOAT, winZ);
      Glu.gluUnProject(point.x, point.y, winZ[0], modelMatrix, projectionMatrix, _viewport, out x, out y, out z);
      Vector3D v = new Vector3D((float)x, (float)y, (float)z);
      UnswitchFrom2DMode();
      return (v);
    }

    public static Vector3D        ProjectOnZPlan(Vector3D point, float zPlan)
    {
      double []                   modelMatrix       = new double[16];
      double []                   projectionMatrix  = new double[16];
      int []                      viewport          = new int[4];
      double                      x, y, z;

      Gl.glGetDoublev(Gl.GL_MODELVIEW_MATRIX,  modelMatrix);
      Gl.glGetDoublev(Gl.GL_PROJECTION_MATRIX, projectionMatrix);
      Gl.glGetIntegerv(Gl.GL_VIEWPORT, viewport);
      //Glu.gluProject(point.x, point.y, point.z, modelMatrix, projectionMatrix, viewport, out x, out y, out z);
      Glu.gluUnProject(point.x, point.y, point.z/*zPlan / 500.0f*/, modelMatrix, projectionMatrix, viewport, out x, out y, out z);
      return (new Vector3D((float)x, (float)y, (float)z));
    }

    #endregion Projection

    /*public int                            GetALightID(int indexlight)
    {
      switch (indexlight)
      {
        case 0:
          return(Gl.GL_LIGHT0);
        case 1:
          return(Gl.GL_LIGHT1);
        case 2:
          return(Gl.GL_LIGHT2);
        case 3:
          return(Gl.GL_LIGHT3);
        case 4:
          return(Gl.GL_LIGHT4);
        case 5:
          return(Gl.GL_LIGHT5);
        case 6:
          return(Gl.GL_LIGHT6);
        case 7:
          return(Gl.GL_LIGHT7);
      }
      return (-1);
    }*/

    public void                           SwitchTo2DMode()
    {
      Gl.glDisable(Gl.GL_LIGHTING);
      Gl.glDisable(Gl.GL_DEPTH_TEST);
      Gl.glPushMatrix();
      Gl.glLoadIdentity();
      Gl.glMatrixMode(Gl.GL_PROJECTION);
      Gl.glPushMatrix();
      Gl.glLoadIdentity();
      Gl.glOrtho(0, _viewWidth, 0, _viewHeight, -1.0f, 1.0f);
    }

    public void                           UnswitchFrom2DMode()
    {
      Gl.glPopMatrix();
      Gl.glMatrixMode(Gl.GL_MODELVIEW);
      Gl.glPopMatrix();
      Gl.glEnable(Gl.GL_DEPTH_TEST);
      Gl.glEnable(Gl.GL_LIGHTING);
    }
  }
}
