//----------------------------------------------------------------------------
//  Project     : EdenArts.Graphic
//  Author      : Michel Courtine
//  Date        : 01/02/2005
//  File        : Material.cs
//  Description : Material class
//----------------------------------------------------------------------------
//  EdenArts.Graphic is a 3D graphic engine library.
//  The project is running under QPL licence.
//    (QPL Licence specifications: http://www.trolltech.com/licenses/qpl.html)
//  Zion is part of Eden Arts Team Work
//  Members are:
//      Nadim Awad        (awad_n@epitech.net)
//      Michel Courtine   (courti_m@epitech.net)
//      Matthieu Dehaussy (dehaus_m@epitech.net)
//      Julien Ferrero    (ferrer_j@epitech.net)
//      Nicolas Goubaux   (goubau_n@epitech.net)
//      Valerie Tching    (tching_v@epitech.net)
//  You can have further information on Zion website:
//         http://zion.labtech.epitech.net
//----------------------------------------------------------------------------

using System;
using Joiners.Math;

namespace Joiners.Graphic
{
  /// <summary>
  /// Definition of Ambient, Diffuse and Specular values for a material.
  /// </summary>
  public class          Material
  {
    public string                     Name;
    public Color                      Diffuse;
    public Color                      Ambient;
    public Color                      Specular;
    public float                      Opacity;
    public float                      Glossiness;
    public float                      SpecularLevel;
    public Texture                    Texture;
    public bool                       Used = false;

    #region Constructors

    public                            Material()
    {
      SetToDefault();
    }

    public                            Material(Material material)
    {
      Set(material);  
    }

    #endregion Constructors

    public void                       Set(Material material)
    {
      this.Name                       = material.Name;
      this.SpecularLevel              = material.SpecularLevel;
      this.Opacity                    = material.Opacity;
      this.Glossiness                 = material.Glossiness;

      this.Diffuse.Set(material.Diffuse);
      this.Ambient.Set(material.Ambient);
      this.Specular.Set(material.Specular);
      
    }
    

    public void                       SetToDefault()
    {
      this.Name                       = "Default Material";
      this.Diffuse                    = new Color(0.58f, 0.68f, 0.93f);
      this.Ambient                    = new Color(0.68f, 0.78f, 1.0f);
      this.Specular                   = new Color(0.7f, 0.7f, 0.7f);
      this.Opacity                    = 1.0f;
      this.Glossiness                 = 1.0f;
      this.SpecularLevel              = 1.0f;
    }

    public void                       SetToRandom()
    {
      Random  r                       = new Random(~unchecked((int)DateTime.Now.Ticks)); 
      
      this.Name                       = "Default Random Material";
      this.Diffuse                    = new Color((float)r.NextDouble() % 0.5f + 0.5f,
        (float)r.NextDouble() % 0.5f + 0.5f,
        (float)r.NextDouble() % 0.5f + 0.5f);
      this.Ambient                    = new Color(Diffuse.r - 0.3f, Diffuse.g - 0.3f, Diffuse.b - 0.3f);
      this.Specular                   = Color.White;
    }

    public void                       SetColor(Color color)
    {
      Diffuse                         = color;
    }
  }
}
