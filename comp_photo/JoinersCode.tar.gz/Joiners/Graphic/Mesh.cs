//----------------------------------------------------------------------------
//  Project     : EdenArts.Graphic
//  Author      : Michel Courtine
//  Date        : 01/02/2005
//  File        : Mesh.cs
//  Description : Mesh class
//----------------------------------------------------------------------------
//  EdenArts.Graphic is a 3D graphic engine library.
//  The project is running under QPL licence.
//    (QPL Licence specifications: http://www.trolltech.com/licenses/qpl.html)
//  Zion is part of Eden Arts Team Work
//  Members are:
//      Nadim Awad        (awad_n@epitech.net)
//      Michel Courtine   (courti_m@epitech.net)
//      Matthieu Dehaussy (dehaus_m@epitech.net)
//      Julien Ferrero    (ferrer_j@epitech.net)
//      Nicolas Goubaux   (goubau_n@epitech.net)
//      Valerie Tching    (tching_v@epitech.net)
//  You can have further information on Zion website:
//         http://zion.labtech.epitech.net
//----------------------------------------------------------------------------

using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using Joiners;
using Joiners.Math;
using Tao.OpenGl;

namespace Joiners.Graphic
{
  /// <summary>
  /// Class used to store the 3D geometry data such as Vertices, Faces, Position, Material ....
  /// </summary>
  public class                        Mesh : Entity
  {
    #region Members

    private ArrayMetaVertex           _vertices    = new ArrayMetaVertex(0, 256);
    private ArrayFace                 _faces       = new ArrayFace(0, 256);
    public ArrayVector2D              TextCoords  = new ArrayVector2D(0, 256);

    protected DrawType                _drawType   = DrawType.SmoothHighlight;

    public MetaMaterial []            MetaMaterials;
    public int                        MaterialId  = -1;
    public Material                   Material;
    public int                        NodeId;
    public int                        GroupId     = 0;
    public int                        ParentNodeId;

    bool                              _interleavedArrayActivated;
    unsafe float *                    _interleavedArray;
    int                               _interleavedArrayLength;

    #endregion Members

    #region Constructors

    public                  Mesh()
    {
      Material = new Material();
      Material.SetToDefault();
      MaterialId = -1;
      _interleavedArrayActivated = true;
      _editable = true;
    }

    #endregion

    #region Properties

    public int             InterleavedArrayLength
    {
      set { _interleavedArrayLength = value; }
    }
    public bool           InterleavedArrayActivated
    {
      set { _interleavedArrayActivated = value; }
    }

    public DrawType         DrawType
    {
      set { _drawType = ((value == DrawType.CallList) ? DrawType.None + 1 : value); }
      get { return (_drawType); }
    }

    public virtual Vector3D WorldPosition
    {
      get { return GetPosition(); }
    }

    public ArrayMetaVertex  Vertices
    {
      get { return (_vertices); }
      set { _vertices = value; OnVerticesChanged(); }
    }

    public ArrayFace        Faces
    {
      get { return (_faces); }
      set { _faces = value; OnFacesChanged(); }
    }

    #endregion Properties

    #region Events

    public event EventHandler         VerticesChanged;
    public event EventHandler         FacesChanged;

    protected void            OnVerticesChanged()
    {
      if (VerticesChanged != null)
        VerticesChanged(this, EventArgs.Empty);
    }

    protected void            OnFacesChanged()
    {
      if (FacesChanged != null)
        FacesChanged(this, EventArgs.Empty);
    }

    #endregion Events

    #region Basic Drawing

    public override void    Draw()
    {
      //      float [] ambientMaterial = {0.2f, 0.2f, 0.2f, 1.0f};
      //      float [] diffuseMaterial = {0.8f, 0.675f, 0.59f, 1.0f};
      float [] specularMaterial = {1.0f, 1.0f, 1.0f, 1.0f};
      float [] lowShininess = {5.0f};
      float [] highShininess = {100.0f};

      // Saving OpenGL state
      Gl.glPushAttrib(Gl.GL_ENABLE_BIT | Gl.GL_CURRENT_BIT | Gl.GL_POLYGON_BIT | Gl.GL_LIGHTING_BIT);
      // Draw Type

      if (Material != null && Material.Texture != null)
        Gl.glBindTexture(Gl.GL_TEXTURE_2D, Material.Texture.ID);
      else if (MaterialId != -1 && GraphicEngine.Instance.Scene != null)//&& /*Name != "hand"*/ MaterialId > -1)
      {
        Gl.glLightModeli(Gl.GL_LIGHT_MODEL_LOCAL_VIEWER, Gl.GL_TRUE);
        Gl.glLightModeli(Gl.GL_LIGHT_MODEL_COLOR_CONTROL, Gl.GL_SEPARATE_SPECULAR_COLOR);
        Gl.glMaterialfv(Gl.GL_FRONT_AND_BACK, Gl.GL_AMBIENT, GraphicEngine.Instance.Scene.Materials[MaterialId].Ambient.Values);
        Gl.glMaterialfv(Gl.GL_FRONT_AND_BACK, Gl.GL_DIFFUSE, GraphicEngine.Instance.Scene.Materials[MaterialId].Diffuse.Values);
        Gl.glMaterialfv(Gl.GL_FRONT_AND_BACK, Gl.GL_SPECULAR, GraphicEngine.Instance.Scene.Materials[MaterialId].Specular.Values);
        Gl.glMaterialf(Gl.GL_FRONT_AND_BACK, Gl.GL_SHININESS, GraphicEngine.Instance.Scene.Materials[MaterialId].SpecularLevel);
      }
      else if (Material != null)
      {
        Gl.glLightModeli(Gl.GL_LIGHT_MODEL_LOCAL_VIEWER, Gl.GL_TRUE);
        Gl.glLightModeli(Gl.GL_LIGHT_MODEL_COLOR_CONTROL, Gl.GL_SEPARATE_SPECULAR_COLOR);
        Gl.glMaterialfv(Gl.GL_FRONT_AND_BACK, Gl.GL_AMBIENT, Material.Ambient.Values);
        Gl.glMaterialfv(Gl.GL_FRONT_AND_BACK, Gl.GL_DIFFUSE, Material.Diffuse.Values);
        Gl.glMaterialfv(Gl.GL_FRONT_AND_BACK, Gl.GL_SPECULAR, Material.Specular.Values);
        Gl.glMaterialf(Gl.GL_FRONT_AND_BACK, Gl.GL_SHININESS, Material.SpecularLevel);
      }

      switch (_drawType)
      {
        case DrawType.Smooth              : DrawSmooth();             break ;
        case DrawType.SmoothHighlight     : DrawSmoothHighlight();    break ;
        case DrawType.WireFrame           : DrawWireFrame();          break ;
        case DrawType.WireFrameHighlight  : DrawWireFrameHighlight(); break ;
//        case DrawType.Facet               : DrawFacet();              break ;
        case DrawType.FacetHighlight      : DrawFacetHighlight();     break ;
        case DrawType.CallList            : DrawCallList();           break ;
        case DrawType.Textured            : DrawTextured();           break ;

      }
      // Restoring OpenGL state
      Gl.glPopAttrib();
    }

    private void            DrawVertices()
    {
      if (_interleavedArrayActivated)
      {
        unsafe
        {
          if (_interleavedArray == null)
            BuildInterleavedArray();
          Gl.glInterleavedArrays(Gl.GL_V3F, sizeof(float) * (6 + 2), (IntPtr)(_interleavedArray + 3 + 2));
          Gl.glDrawArrays(Gl.GL_TRIANGLES, 0, _interleavedArrayLength / 8);
        }
      }
      else
      {
        Gl.glBegin(Gl.GL_TRIANGLES);
        foreach (Face face in Faces)
        {
          Gl.glVertex3f(Vertices[face.VertexIds[0]].Vertex.Position.x, Vertices[face.VertexIds[0]].Vertex.Position.y, Vertices[face.VertexIds[0]].Vertex.Position.z);
          Gl.glVertex3f(Vertices[face.VertexIds[1]].Vertex.Position.x, Vertices[face.VertexIds[1]].Vertex.Position.y, Vertices[face.VertexIds[1]].Vertex.Position.z);
          Gl.glVertex3f(Vertices[face.VertexIds[2]].Vertex.Position.x, Vertices[face.VertexIds[2]].Vertex.Position.y, Vertices[face.VertexIds[2]].Vertex.Position.z);
        }
        Gl.glEnd();
      }
    }

    private void            DrawVerticesNormals()
    {
      if (_interleavedArrayActivated)
      {        
        unsafe
        {
          if (_interleavedArray == null)
            BuildInterleavedArray();
          Gl.glInterleavedArrays(Gl.GL_T2F_N3F_V3F, 0, (IntPtr)_interleavedArray);
          Gl.glDrawArrays(Gl.GL_TRIANGLES, 0, _interleavedArrayLength / 8);
        }
      }
      else
      {
        Gl.glBegin(Gl.GL_TRIANGLES);
        foreach (Face face in Faces)
        {
          Gl.glNormal3f(Vertices[face.VertexIds[0]].Normal.x, Vertices[face.VertexIds[0]].Normal.y, Vertices[face.VertexIds[0]].Normal.z);
          Gl.glVertex3f(Vertices[face.VertexIds[0]].Vertex.Position.x, Vertices[face.VertexIds[0]].Vertex.Position.y, Vertices[face.VertexIds[0]].Vertex.Position.z);
          Gl.glNormal3f(Vertices[face.VertexIds[1]].Normal.x, Vertices[face.VertexIds[1]].Normal.y, Vertices[face.VertexIds[1]].Normal.z);
          Gl.glVertex3f(Vertices[face.VertexIds[1]].Vertex.Position.x, Vertices[face.VertexIds[1]].Vertex.Position.y, Vertices[face.VertexIds[1]].Vertex.Position.z);
          Gl.glNormal3f(Vertices[face.VertexIds[2]].Normal.x, Vertices[face.VertexIds[2]].Normal.y, Vertices[face.VertexIds[2]].Normal.z);
          Gl.glVertex3f(Vertices[face.VertexIds[2]].Vertex.Position.x, Vertices[face.VertexIds[2]].Vertex.Position.y, Vertices[face.VertexIds[2]].Vertex.Position.z);
        }
        Gl.glEnd();
      }
    }

    private void            DrawTexturedVerticesNormals()
    {
      if (_interleavedArrayActivated)
      {        
        unsafe
        {
          if (_interleavedArray == null)
            BuildInterleavedArray();
          Gl.glInterleavedArrays(Gl.GL_T2F_N3F_V3F, 0, (IntPtr)_interleavedArray);
          Gl.glDrawArrays(Gl.GL_TRIANGLES, 0, _interleavedArrayLength / 8);
        }
      }
      else
      {
        Gl.glBegin(Gl.GL_TRIANGLES);
        foreach (Face face in Faces)
        {
          Gl.glTexCoord2f(TextCoords[face.TextureVertexIds[0]].x, TextCoords[face.TextureVertexIds[0]].y);
          Gl.glNormal3f(Vertices[face.VertexIds[0]].Normal.x, Vertices[face.VertexIds[0]].Normal.y, Vertices[face.VertexIds[0]].Normal.z);
          Gl.glVertex3f(Vertices[face.VertexIds[0]].Vertex.Position.x, Vertices[face.VertexIds[0]].Vertex.Position.y, Vertices[face.VertexIds[0]].Vertex.Position.z);
          Gl.glTexCoord2f(TextCoords[face.TextureVertexIds[1]].x, TextCoords[face.TextureVertexIds[1]].y);
          Gl.glNormal3f(Vertices[face.VertexIds[1]].Normal.x, Vertices[face.VertexIds[1]].Normal.y, Vertices[face.VertexIds[1]].Normal.z);
          Gl.glVertex3f(Vertices[face.VertexIds[1]].Vertex.Position.x, Vertices[face.VertexIds[1]].Vertex.Position.y, Vertices[face.VertexIds[1]].Vertex.Position.z);
          Gl.glTexCoord2f(TextCoords[face.TextureVertexIds[2]].x, TextCoords[face.TextureVertexIds[2]].y);
          Gl.glNormal3f(Vertices[face.VertexIds[2]].Normal.x, Vertices[face.VertexIds[2]].Normal.y, Vertices[face.VertexIds[2]].Normal.z);
          Gl.glVertex3f(Vertices[face.VertexIds[2]].Vertex.Position.x, Vertices[face.VertexIds[2]].Vertex.Position.y, Vertices[face.VertexIds[2]].Vertex.Position.z);
        }
        Gl.glEnd();
      }
    }

    #endregion Basic Drawing

    #region Draw Types

    private void            DrawSmooth()
    {
      // Change OpenGL State
      Gl.glEnable(Gl.GL_LIGHTING);
      Gl.glShadeModel(Gl.GL_SMOOTH);

      // Draw
      DrawVertices();
    }

    private void            DrawSmoothHighlight()
    {
      // Change OpenGL State
      Gl.glEnable(Gl.GL_LIGHTING);
      Gl.glShadeModel(Gl.GL_SMOOTH);

      // Draw
      DrawVerticesNormals();
    }

    private void            DrawWireFrame()
    {
      // Change OpenGL State
      Gl.glDisable(Gl.GL_LIGHTING);
      Gl.glPolygonMode(Gl.GL_FRONT_AND_BACK, Gl.GL_LINE);
      Gl.glEnable(Gl.GL_POLYGON_OFFSET_LINE);

      // Draw
      DrawVertices();

      Gl.glDisable(Gl.GL_POLYGON_OFFSET_LINE);
    }

    private void            DrawWireFrameHighlight()
    {
      // Change OpenGL State
      Gl.glEnable(Gl.GL_LIGHTING);
      Gl.glPolygonMode(Gl.GL_FRONT_AND_BACK, Gl.GL_LINE);
      Gl.glEnable(Gl.GL_POLYGON_OFFSET_LINE);

      // Draw
      DrawVerticesNormals();

      Gl.glDisable(Gl.GL_POLYGON_OFFSET_LINE);
    }

    private void            DrawFacet()
    {
      // Change OpenGL State
      Gl.glDisable(Gl.GL_LIGHTING);
      Gl.glShadeModel(Gl.GL_FLAT);

      // Draw
      DrawVerticesNormals();
    }

    private void            DrawFacetHighlight()
    {
      // Change OpenGL State
      Gl.glEnable(Gl.GL_LIGHTING);
      Gl.glShadeModel(Gl.GL_FLAT);

      // Draw
      DrawVerticesNormals();
    }

    private void            DrawCallList()
    {
      Gl.glDisable(Gl.GL_LIGHTING);
      Gl.glShadeModel(Gl.GL_SMOOTH);
      DrawVerticesNormals();
    }

    private void            DrawTextured()
    {
      Gl.glDisable(Gl.GL_LIGHTING);
      Gl.glEnable(Gl.GL_TEXTURE_2D);
      DrawTexturedVerticesNormals();
    }

    #endregion Draw Types

    #region Extents

    public override void    ExtentsCompute()
    {
      foreach (MetaVertex v in Vertices)
        if (v != null)
        {
          _extentMin.Set(v.Vertex.Position);
          _extentMax.Set(v.Vertex.Position);
          break;
        }
      foreach (MetaVertex v in Vertices)
      {
        if (v.Vertex.Position.x < _extentMin.x)
          _extentMin.x = v.Vertex.Position.x;
        if (v.Vertex.Position.y < _extentMin.y)
          _extentMin.y = v.Vertex.Position.y;
        if (v.Vertex.Position.z < _extentMin.z)
          _extentMin.z = v.Vertex.Position.z;
        if (v.Vertex.Position.x > _extentMax.x)
          _extentMax.x = v.Vertex.Position.x;
        if (v.Vertex.Position.y > _extentMax.y)
          _extentMax.y = v.Vertex.Position.y;
        if (v.Vertex.Position.z > _extentMax.z)
          _extentMax.z = v.Vertex.Position.z;
      }
      _center = new Vector3D(_extentMin.x + (_extentMax.x - _extentMin.x) / 2, 
                             _extentMin.y + (_extentMax.y - _extentMin.y) / 2,
                             _extentMin.z + (_extentMax.z - _extentMin.z) / 2) * GetScale();
    }

    #endregion Extents

    #region NormalCalculation

    public void								CalculateNormalPerVertex()
    {
      foreach (MetaVertex vertex in Vertices)
        CalculateVertexNormal(vertex);
    }

    public void								CalculateNormalPerFace()
    {
      foreach (Face face in Faces)
        CalculateFaceNormal(face);
    }

    public void							CalculateFaceNormal(Face face)
    {
      Vertex vertex = new Vertex();
      Vector3D u, v;
      if (face.VertexIds[0] == -1 || face.VertexIds[1] == -1 || face.VertexIds[2] == -1)
      {
        face.Normal.Set(0.0f, 0.0f, 0.0f);
        return;
      }

      u = vertex.GetVector(Vertices[face.VertexIds[0]].Vertex, Vertices[face.VertexIds[2]].Vertex);
      v = vertex.GetVector(Vertices[face.VertexIds[0]].Vertex, Vertices[face.VertexIds[1]].Vertex);
      v.Inner(u);
      v.Normalize();
      face.Normal = v;
    }

    public void							CalculateVertexNormal(MetaVertex vertex)
    {
      Vector3D vector = new Vector3D(0.0f, 0.0f, 0.0f);
      foreach (Face face in vertex.NeighborFaces)
      {
        if (face == null)
          continue;
        vector = vector + face.Normal;
      }
      vector.Normalize();
      vertex.Normal = vector;
    }

    public void           CalculateAllNormals()
    {
      CalculateNormalPerFace();
      CalculateNormalPerVertex();
    }

    #endregion

    #region GetNeighboring
    private void							SetFaceNeighboringVertices()
    {
      foreach (Face face in Faces)
      {
        for (int j = 0; j < 3; j++)
        {
          if (face.VertexIds[j] == -1)
            continue;
          //Console.WriteLine("J: " + j + "VertexIndex:" + face.VertexIds[j].ToString());
          Vertices[face.VertexIds[j]].AddNeighbor(face);
        }
      }
    }

    private void							SetVertexNeighboring()
    {
      int i =0;
      foreach (MetaVertex vertex in Vertices)
      {
        i++;
        int NbFaceNeighbor = vertex.NbFaceNeighbor();
        if (NbFaceNeighbor == 0)
        {
          Vertices.Remove(Vertices.Find(vertex));
          continue;
        }
        for (int j = 0; j < NbFaceNeighbor; j++)
        {
          for (int k = 0; k < 3; k++)
          {
            if (vertex.GetFaceNeighbor(j).VertexIds[k] == -1)
              continue;
            vertex.AddNeighbor(Vertices[vertex.GetFaceNeighbor(j).VertexIds[k]]);
          }
        }
      }
    }

    private void							SetFaceNeighboring()
    {
      foreach(Face face in Faces)
      {
        for (int j = 0; j < 3; j++)
        {
          if (face.VertexIds[j] == -1)
            continue;
          MetaVertex vertex = Vertices[face.VertexIds[j]];
          if (vertex == null)
            continue;
          if (face.VertexIds[(j + 1) % 3] == -1)
            continue;
          MetaVertex nextVertex = Vertices[face.VertexIds[(j + 1) % 3]];
          if (nextVertex == null)
            continue;
          int NbFaceNeighbor = vertex.NbFaceNeighbor();
          for (int k = 0; k < NbFaceNeighbor; k++)
          {
            Face neighbor = vertex.GetFaceNeighbor(k);
            if (neighbor != face)
              if (face.FaceNeighborsIds[j] == -1)
                if (neighbor.HasVertex(face.VertexIds[j]))
                  if (neighbor.HasVertex(face.VertexIds[(j + 1) % 3]))
                    face.FaceNeighborsIds[j] = neighbor.index;
          }
        }
      }
    }
		
    public void								GetNeighbors()
    {
      if (Vertices.Count < 3 || Faces.Count <= 0)
      {
        Trace.WriteLine("Invalid Array sizes\n");
        return;
      }
			
      foreach(Face face in Faces)
        for (int k = 0; k < 6; k++)
        {
          face.FaceNeighborsIds[k] = -1;
        }

      foreach(MetaVertex metaVertex in Vertices)
      {
        metaVertex.RemoveAllFaceNeighbors();
        metaVertex.RemoveAllVertexNeighbors();
      }
			
      SetFaceNeighboringVertices();
      SetVertexNeighboring();
      SetFaceNeighboring();
    }
    #endregion GetNeighboring

    #region Interleaved Array

    public void             ResetInterleavedArray()
    {
      unsafe {_interleavedArray = null;}
    }

    public void             BuildInterleavedArray()
    {
      unsafe
      {
        if (_interleavedArray != null)
        {
          Memory.Free(_interleavedArray);
        }
        _interleavedArrayLength = Faces.Count * 3 * (3 + 3 + 2);
        _interleavedArray = (float *)Memory.Alloc(sizeof(float) * _interleavedArrayLength);
        //_interleavedArray = new float[Faces.Count * 3 * (3 + 3 + 2)];
        UpdateInterleavedArray();
      }
    }

    private int             UpdateInterleavedArrayFace(Face face, int faceInterleavedArrayIndex)
    {
      int                   i = 0;

      unsafe
      {
        for (int index = 0; index < 3; index++)
        {
          if (face.VertexIds[index] == -1)
            continue;
          if (TextCoords.Count != 0)
          {
            _interleavedArray[faceInterleavedArrayIndex++] = TextCoords[face.TextureVertexIds[index]].x; i++;
            _interleavedArray[faceInterleavedArrayIndex++] = TextCoords[face.TextureVertexIds[index]].y; i++;
          }
          else
          {
            faceInterleavedArrayIndex += 2;
            i += 2;
          }
          _interleavedArray[faceInterleavedArrayIndex++] = Vertices[face.VertexIds[index]].Normal.x; i++;
          _interleavedArray[faceInterleavedArrayIndex++] = Vertices[face.VertexIds[index]].Normal.y; i++;
          _interleavedArray[faceInterleavedArrayIndex++] = Vertices[face.VertexIds[index]].Normal.z; i++;
          //            _interleavedArray[i++] = face.Normal.x;
          //            _interleavedArray[i++] = face.Normal.y;
          //            _interleavedArray[i++] = face.Normal.z;
          _interleavedArray[faceInterleavedArrayIndex++] = Vertices[face.VertexIds[index]].Vertex.Position.x; i++;
          _interleavedArray[faceInterleavedArrayIndex++] = Vertices[face.VertexIds[index]].Vertex.Position.y; i++;
          _interleavedArray[faceInterleavedArrayIndex++] = Vertices[face.VertexIds[index]].Vertex.Position.z; i++;
        }
      }
      return (i);
    }

    public int              UpdateInterleavedArrayFace(Face face)
    {
      return (UpdateInterleavedArrayFace(face, face.index * ((2 + 3 + 3) * 3)));
    }

    public void             UpdateInterleavedArray()
    {
      int                   i = 0;

      foreach (Face face in Faces)
      {
        i += UpdateInterleavedArrayFace(face, i);
      }
    }

    public void             TranslateVertex(MetaVertex v, Vector3D translation)
    {
      // Move the vertex
      v.Vertex.Position.Add(translation);

      // Update the vertex in interleaved array
      foreach (Face face in v.NeighborFaces)
      {
        CalculateFaceNormal(face);
        UpdateInterleavedArrayFace(face);
      }
    }
    public void             TranslateVertex(int vertexId, Vector3D translation)
    {
      TranslateVertex(Vertices[vertexId], translation);
    }


    public void             SetVertexPosition(MetaVertex v, Vector3D position)
    {
      // Move the vertex
      v.Vertex.Position.Set(position);

      // Update the vertex in interleaved array
      foreach (Face face in v.NeighborFaces)
      {
        CalculateFaceNormal(face);
        UpdateInterleavedArrayFace(face);
      }
    }
    public void             SetVertexPosition(int vertexId, Vector3D position)
    {
      SetVertexPosition(Vertices[vertexId], position);
    }

    public void             TranslateFace(Face face, Vector3D translation, bool vertex1, bool vertex2, bool vertex3)
    {
      // Move the vertex
      if (vertex1)
        Vertices[face.VertexIds[0]].Vertex.Position.Add(translation);
      if (vertex2)
        Vertices[face.VertexIds[1]].Vertex.Position.Add(translation);
      if (vertex3)
        Vertices[face.VertexIds[2]].Vertex.Position.Add(translation);

      CalculateFaceNormal(face);
      UpdateInterleavedArrayFace(face);

      for (int i = 0; i < 3; i++)
      {
        foreach (Face f in Vertices[face.VertexIds[i]].NeighborFaces)
        {
          if (f != face)
          {
            // FIXME: Calculs are made several times on a face
            CalculateFaceNormal(f);
            UpdateInterleavedArrayFace(f);
          }
        }
      }
    }

    public void             TranslateFace(Face face, Vector3D translation)
    {
      TranslateFace(face, translation, true, true, true);
    }
    public void             TranslateFace(int faceId, Vector3D translation)
    {
      TranslateFace(Faces[faceId], translation);
    }

    #endregion Interleaved Array

    #region ICloneable Members

    public override object  Clone()
    {
      Mesh mesh           = new Mesh();
      mesh.Set(this);
      mesh.Name           = (string)_name.Clone();
      mesh.Vertices       = (ArrayMetaVertex)Vertices.Clone();
      mesh.Faces          = (ArrayFace)Faces.Clone();
      mesh.TextCoords     = (ArrayVector2D)TextCoords.Clone();
      mesh._drawType      = _drawType;
      mesh.MaterialId     = MaterialId;
      mesh.Material       = Material;
      mesh.NodeId         = NodeId;
      mesh.ParentNodeId   = ParentNodeId;
      return (mesh);
    }

//    public override object  Clone()
//    {
//      return this.MemberwiseClone();
//    }

    #endregion

  }
}
