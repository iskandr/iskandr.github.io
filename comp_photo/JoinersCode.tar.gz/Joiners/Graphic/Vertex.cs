//----------------------------------------------------------------------------
//  Project     : EdenArts.Graphic
//  Author      : Michel Courtine
//  Date        : 01/02/2005
//  File        : Vertex.cs
//  Description : Vertex class
//----------------------------------------------------------------------------
//  EdenArts.Graphic is a 3D graphic engine library.
//  The project is running under QPL licence.
//    (QPL Licence specifications: http://www.trolltech.com/licenses/qpl.html)
//  Zion is part of Eden Arts Team Work
//  Members are:
//      Nadim Awad        (awad_n@epitech.net)
//      Michel Courtine   (courti_m@epitech.net)
//      Matthieu Dehaussy (dehaus_m@epitech.net)
//      Julien Ferrero    (ferrer_j@epitech.net)
//      Nicolas Goubaux   (goubau_n@epitech.net)
//      Valerie Tching    (tching_v@epitech.net)
//  You can have further information on Zion website:
//         http://zion.labtech.epitech.net
//----------------------------------------------------------------------------

using System;
using System.Diagnostics;
using Joiners.Math;

namespace Joiners.Graphic
{
  /// <summary>
  /// Sub-Element of a face describing the position of one of its points.
  /// </summary>
  public class      Vertex : ICloneable
  {
//    public Vector3D Normal    = new Vector3D();
    public Vector3D Position  = new Vector3D();
    public Vector2D MapCoords = new Vector2D();
 
    public override string      ToString()
    {
      return ("Position: "  + Position.ToString()
//            + "\nNormal: " + Normal.ToString()
            + "\nMapCoords: " + MapCoords.ToString());
    }

		public	float Get(int coord)
		{
			if (coord == 0)
				return (Position.x);
			if (coord == 1)
				return (Position.y);
			if (coord == 2)
				return (Position.z);
			return (0);
		}

		public void	Set(int coord, float val)
		{
			if (coord == 0)
				Position.x = val;
			if (coord == 1)
				Position.y = val;
			if (coord == 2)
				Position.z = val;
		}

    public void Set(Vertex vertex)
    {
      Position  = vertex.Position;
      MapCoords = vertex.MapCoords;
    }
		
		public Vector3D GetVector(Vertex vertex1, Vertex vertex2)
		{
			Vector3D vector = new Vector3D(vertex2.Position.x - vertex1.Position.x,
																		 vertex2.Position.y - vertex1.Position.y,
																		 vertex2.Position.z - vertex1.Position.z);
			return vector;
		}

		public float GetDistance(Vertex vertex)
		{
			//d(X1, X0)^2 = (x1-x0)^2 + (y1-y0)^2 + (z1-z0)^2
			return((float)System.Math.Sqrt(System.Math.Pow((double)(vertex.Position.x - this.Position.x), 2) + 
				System.Math.Pow((double)(vertex.Position.y - this.Position.y), 2) +
				System.Math.Pow((double)(vertex.Position.z - this.Position.z), 2)));
			
		}

    public object   Clone()
    {
      Vertex newVertex = new Vertex();
      newVertex.Position = Position;
      newVertex.MapCoords = MapCoords;
      return newVertex;
    }
  }
}
