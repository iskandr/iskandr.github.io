//----------------------------------------------------------------------------
//  Project     : EdenArts.Graphic
//  Author      : Valerie Tching
//  Date        : 01/02/2005
//  File        : Transformable.cs
//  Description : Transformable class
//                Base class for 3D geometry
//                Inherited classes are: Mesh, Light, Group
//----------------------------------------------------------------------------
//  EdenArts.Graphic is a 3D graphic engine library.
//  The project is running under QPL licence.
//    (QPL Licence specifications: http://www.trolltech.com/licenses/qpl.html)
//  Zion is part of Eden Arts Team Work
//  Members are:
//      Nadim Awad        (awad_n@epitech.net)
//      Michel Courtine   (courti_m@epitech.net)
//      Matthieu Dehaussy (dehaus_m@epitech.net)
//      Julien Ferrero    (ferrer_j@epitech.net)
//      Nicolas Goubaux   (goubau_n@epitech.net)
//      Valerie Tching    (tching_v@epitech.net)
//  You can have further information on Zion website:
//         http://zion.labtech.epitech.net
//----------------------------------------------------------------------------

using System;
using Joiners.Math;
using Tao.OpenGl;

namespace Joiners.Graphic
{
	/// <summary>
	/// Summary description for Transformation.
	/// </summary>
	public class  Transformable : ITransformable
	{
    #region Members

    private   Matrix4D      _matrix     = new Matrix4D();
    private   Vector3D      _position   = new Vector3D();
    private   Quaternion    _quaternion = new Quaternion();
    private   Vector3D      _scale      = new Vector3D();

    #endregion // Members

    #region Properties

    public Matrix4D         Matrix
    {
      get { return _matrix;  }
      set { _matrix = value; }
    }

//    public Quaternion       Quaternion
//    {
//      get { return _quaternion;  }
//      set { _quaternion = value; UpdateInnerMatrix3D(); }
//    }

    #endregion // Properties

    #region Constructors

		public                Transformable()
		{
      ResetGeometry();
    }

    public                Transformable(Transformable transformable)
    {
      SetGeometry(transformable);
    }

    #endregion Constructors

    #region Matrix

    private void            UpdateMatrix()
    {
      UpdateTranslationMatrix();
      UpdateInnerMatrix3D();
    }
  
    private void            UpdateTranslationMatrix()
    {
      _matrix.x             = _position.x;
      _matrix.y             = _position.y;
      _matrix.z             = _position.z;
    }

    private void            UpdateInnerMatrix3D()
    {
      float []  axis        = { 0.0f, 0.0f, 0.0f, 0.0f };

      _quaternion.ToAxis(axis);
      _matrix.FromAxis(axis[0], axis[1], axis[2], axis[3]);

      Matrix4D  scaleMatrix = new Matrix4D();
      scaleMatrix.SetDiagonal(_scale.x, _scale.y, _scale.z, 1.0f);
      _matrix.Multiply(scaleMatrix);
    }

    #endregion // Matrix

    public void             ResetGeometry()
    {
      SetPosition(Vector3D.Empty);
      SetQuaternion(Quaternion.Identity);
      SetScale(1.0f, 1.0f, 1.0f);
    }

    public void             SetGeometry(Transformable transformable)
    {
      SetPosition(transformable.GetPosition());
      SetQuaternion(transformable.GetQuaternion());
      SetScale(transformable.GetScale());
    }

    #region ITransformable Members

    #region Translation

    public Vector3D         GetPosition()
    {
      return _position;
    }

    public void             SetPosition(float x, float y, float z)
    {
      _position.Set(x, y, z);
      UpdateTranslationMatrix();
    }

    public void             SetPosition(Vector3D position)
    {
      SetPosition(position.x, position.y, position.z);
    }

    public void             SetPositionX(float x) { _position.x = x; UpdateTranslationMatrix(); }
    public void             SetPositionY(float y) { _position.y = y; UpdateTranslationMatrix(); }
    public void             SetPositionZ(float z) { _position.z = z; UpdateTranslationMatrix(); }

    public void             Translate(float x, float y, float z)
    {
      _position.x          += x;
      _position.y          += y;
      _position.z          += z;

      UpdateTranslationMatrix();
    }

    public void             Translate(Vector3D translation)
    {
      Translate(translation.x, translation.y, translation.z);
    }

    public void             TranslateX(float x) { _position.x += x; UpdateTranslationMatrix(); }
    public void             TranslateY(float y) { _position.y += y; UpdateTranslationMatrix(); }
    public void             TranslateZ(float z) { _position.z += z; UpdateTranslationMatrix(); }


    #endregion Translation

    #region Rotation

    public Quaternion       GetQuaternion()
    {
      return new Quaternion(_quaternion);
    }

    public void             SetQuaternion(float x, float y, float z, float w)
    {
      _quaternion.Set(x, y, z, w);
      UpdateInnerMatrix3D();
    }

    public void             SetQuaternion(Quaternion q)
    {
      _quaternion.Set(q);
      UpdateInnerMatrix3D();
    }

    public void             SetRotation(float rx, float ry, float rz)
    {
      _quaternion.FromEuler(rx, ry, rz);
      UpdateInnerMatrix3D();
    }

    public void             Rotate(float rx, float ry, float rz)
    {
      Quaternion            q = new Quaternion();
      q.FromEuler(rx, ry, rz);
      _quaternion.Multiply(q);
      UpdateInnerMatrix3D();
    }

    public void             Rotate(Vector3D rotation)
    {
      Rotate(rotation.x, rotation.y, rotation.z);
    }

    public void             RotateX(float rx) 
    {
      Quaternion            q = new Quaternion();
      q.FromEuler(rx, 0, 0);
      _quaternion.Multiply(q);
      UpdateInnerMatrix3D();
    }
    public void             RotateY(float ry) 
    {
      Quaternion            q = new Quaternion();
      q.FromEuler(0, ry, 0);
      _quaternion.Multiply(q);
      UpdateInnerMatrix3D();
    }
    public void             RotateZ(float rz) 
    {
      Quaternion            q = new Quaternion();
      q.FromEuler(0, 0, rz);
      _quaternion.Multiply(q);
      UpdateInnerMatrix3D();
    }

    public void             Rotate(Quaternion q)
    {
      _quaternion.Multiply(q);
      UpdateInnerMatrix3D();
    }

    #endregion Rotation

    #region Scale

    public Vector3D         GetScale()
    {
      return _scale;
    }

    public void             SetScale(float x, float y, float z)
    {
      _scale.Set(x, y, z);
      UpdateInnerMatrix3D();
    }

    public void             SetScale(Vector3D position)
    {
      SetScale(position.x, position.y, position.z);
    }

    public void             Scale(float x, float y, float z)
    {
      _scale.Multiply(new Vector3D(x, y, z));
      UpdateInnerMatrix3D();
    }

    public void             Scale(Vector3D scale)
    {
      Scale(scale.x, scale.y, scale.z);
    }

    #endregion Scale

    public virtual void    Place()
    {
//      float []              axis = { 0.0f, 0.0f, 0.0f, 0.0f };
//      _quaternion.ToAxis(axis);
//      Gl.glTranslatef(_position.x, _position.y, _position.z);
//      axis[0] = EdenArts.Math.Math.RadToDeg(axis[0]);
//      Gl.glRotatef(axis[0], axis[1], axis[2], axis[3]);
//      Gl.glScalef(_scale.x, _scale.y, _scale.z);

      Matrix4D  m = new Matrix4D(_matrix);
      m.Transpose();
      Gl.glMultMatrixf(m.Values);

    }

    #endregion

  }
}
