//----------------------------------------------------------------------------
//  Project     : EdenArts.Graphic
//  Author      : Michel Courtine
//  Date        : 01/02/2005
//  File        : Texture.cs
//  Description : Texture class
//----------------------------------------------------------------------------
//  EdenArts.Graphic is a 3D graphic engine library.
//  The project is running under QPL licence.
//    (QPL Licence specifications: http://www.trolltech.com/licenses/qpl.html)
//  Zion is part of Eden Arts Team Work
//  Members are:
//      Nadim Awad        (awad_n@epitech.net)
//      Michel Courtine   (courti_m@epitech.net)
//      Matthieu Dehaussy (dehaus_m@epitech.net)
//      Julien Ferrero    (ferrer_j@epitech.net)
//      Nicolas Goubaux   (goubau_n@epitech.net)
//      Valerie Tching    (tching_v@epitech.net)
//  You can have further information on Zion website:
//         http://zion.labtech.epitech.net
//----------------------------------------------------------------------------

using System;
using System.Drawing;
using System.Drawing.Imaging;
using Tao.OpenGl;
using Tao.FreeGlut;

namespace Joiners.Graphic
{
	/// <summary>
	/// Binding between a filename and its loaded texture openGL Id.
	/// </summary>
	public class          Texture
	{
    #region Members

    private string      _filename;
    private int         _width;
    private int         _height;
    private int         _openGLId;
    private Bitmap      _image = null;

    #endregion Members

    #region Properties

     public string       Filename
    {
      get { return _filename; }
      set {_filename = value; }
    }
  
    public int          Width
    {
      get { return _width; }
      set {_width = value; }
    }
  
    public int          Height
    {
      get { return _height; }
      set {_height = value; }
    }
  
    public int          ID
    {
      get { return _openGLId; }
    }

    public Bitmap       Image
    {
      get { return _image; }
    }

    #endregion Properties

    #region Constructors

        
    public              Texture(string filename)
    {
      if (Load(filename))
        _filename = filename;
//      _vertexDisplayListId = Gl.glGenLists(1);
//
//      Gl.glBindTexture(Gl.GL_TEXTURE_2D, textureIds[0]);
//      Gl.glNewList(_vertexDisplayListId, Gl.GL_COMPILE);
//      Gl.glBegin(Gl.GL_QUADS);
//      Gl.glTexCoord2f(0.0f, 0.0f); Gl.glVertex3f(-1.0f, 0.0f,-1.0f);
//      Gl.glTexCoord2f(1.0f, 0.0f); Gl.glVertex3f( 1.0f, 0.0f,-1.0f);
//      Gl.glTexCoord2f(1.0f, 1.0f); Gl.glVertex3f( 1.0f, 0.0f, 1.0f);
//      Gl.glTexCoord2f(0.0f, 1.0f); Gl.glVertex3f(-1.0f, 0.0f, 1.0f);
//      Gl.glEnd();
//      Gl.glEndList();
    }
        

    public Texture(Bitmap bmp, string filename)
    {
        if (Load(bmp))
            _filename = filename;
    }

    #endregion Constructors

    #region Methods

    private void UnLoadTexture()
    {
        if (_image != null)
        {
            //_image.Dispose(); 
            int[] textures = new int[1];
            textures[0] = _openGLId;
            Gl.glDeleteTextures(1, textures);
        }
    }

    public bool Load(Bitmap image)
    {
        UnLoadTexture();
        _image = image;
        GetTexture();
        return true;
    }

    public bool         Load(string filename)
    {
      UnLoadTexture();
      try
      {  _image = new Bitmap(filename); }
      catch (Exception)
      {  return (false);  }
      GetTexture();
     
      return (true);
    }

    private void GetTexture()
    {
        Bitmap tmpTexture;
        int width = _image.Width;
        int height = _image.Height;

        if (_image.Width > 1024 || _image.Height > 1024)
        {
            double ratio = 0;
            if (_image.Width >= _image.Height)
            {
                ratio = 1024.0 / (double)_image.Width;
                width = 1024;
                height = (int)((double)_image.Height * ratio);
            }
            else
            {
                ratio = 1024.0 / (double)_image.Height;
                height = 1024;
                width = (int)((double)_image.Width * ratio);
            }
        }

        tmpTexture = new Bitmap(width, height, _image.PixelFormat);
       
        //Lets work with a smaller version of the image
        using (Graphics g = Graphics.FromImage(tmpTexture))
            g.DrawImage(_image, 0, 0, width, height);

        _width = tmpTexture.Width;
        _height = tmpTexture.Height;
        int[] textureIds = new int[1];
        Gl.glGenTextures(1, textureIds);
        tmpTexture.RotateFlip(RotateFlipType.RotateNoneFlipY);
        BitmapData bitmapData = tmpTexture.LockBits(new Rectangle(0, 0, _width, _height), ImageLockMode.ReadOnly, tmpTexture.PixelFormat);
        Console.WriteLine("PixelFormat is : " + tmpTexture.PixelFormat.ToString());

        // OpenGL needs to be aware whether textures are 32bpp or 24bpp
        int glPixelFormat; 

        switch (tmpTexture.PixelFormat)
        {
            case PixelFormat.Format32bppArgb:
                glPixelFormat = Gl.GL_BGRA;
                break;
            default:
                glPixelFormat = Gl.GL_BGR;
                break; 
        }

        //Gl.glPushAttrib(Gl.GL_TEXTURE_BIT | Gl.GL_CURRENT_BIT | Gl.GL_ENABLE_BIT);
        //Gl.glPixelStorei(Gl.GL_UNPACK_ALIGNMENT, 1);
        
        _openGLId = textureIds[0];
        Gl.glBindTexture(Gl.GL_TEXTURE_2D, _openGLId);
        Gl.glTexEnvf(Gl.GL_TEXTURE_ENV, Gl.GL_TEXTURE_ENV_MODE, Gl.GL_REPLACE);
        Gl.glTexParameterf(Gl.GL_TEXTURE_2D, Gl.GL_TEXTURE_MAG_FILTER, Gl.GL_LINEAR);
        //Gl.glTexParameterf(Gl.GL_TEXTURE_2D, Gl.GL_TEXTURE_MIN_FILTER, Gl.GL_LINEAR_MIPMAP_NEAREST);
        Gl.glTexParameterf(Gl.GL_TEXTURE_2D, Gl.GL_TEXTURE_MIN_FILTER, Gl.GL_LINEAR);
        //Gl.glTexParameterf(Gl.GL_TEXTURE_2D, Gl.GL_TEXTURE_WRAP_T, Gl.GL_CLAMP);
        
        Gl.glTexImage2D(Gl.GL_TEXTURE_2D, 0, Gl.GL_RGB, _width, _height, 0, glPixelFormat, Gl.GL_UNSIGNED_BYTE, bitmapData.Scan0);
        //Glu.gluBuild2DMipmaps(Gl.GL_TEXTURE_2D, 3, _width, _height, Gl.GL_BGR, Gl.GL_UNSIGNED_BYTE, bitmapData.Scan0);
        tmpTexture.UnlockBits(bitmapData);
        tmpTexture.Dispose();
        //Gl.glPopAttrib();

        //_image = tmpTexture; 
    }

    #endregion Methods
  }
}
