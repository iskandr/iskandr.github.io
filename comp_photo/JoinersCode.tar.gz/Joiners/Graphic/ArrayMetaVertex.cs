//----------------------------------------------------------------------------
//  Project     : EdenArts.Graphic
//  Author      : Michel Courtine
//  Date        : 01/02/2005
//  File        : ArrayMetaVertex.cs
//  Description : ArrayMetaVertex class
//----------------------------------------------------------------------------
//  EdenArts.Graphic is a 3D graphic engine library.
//  The project is running under QPL licence.
//    (QPL Licence specifications: http://www.trolltech.com/licenses/qpl.html)
//  Zion is part of Eden Arts Team Work
//  Members are:
//      Nadim Awad        (awad_n@epitech.net)
//      Michel Courtine   (courti_m@epitech.net)
//      Matthieu Dehaussy (dehaus_m@epitech.net)
//      Julien Ferrero    (ferrer_j@epitech.net)
//      Nicolas Goubaux   (goubau_n@epitech.net)
//      Valerie Tching    (tching_v@epitech.net)
//  You can have further information on Zion website:
//         http://zion.labtech.epitech.net
//----------------------------------------------------------------------------

using System;
using System.Collections;
using System.Diagnostics;
using Joiners.Graphic;
using Joiners.Math;

namespace Joiners.Graphic
{
  /// <summary>
  /// Array MetaVertex Enumerator
  /// This class allows Array walking with foreach keyword
  /// </summary>
  public class ArrayMetaVertexEnumerator : IEnumerator
  {

    #region Members

    private ArrayMetaVertex _data;
    IEnumerator       _dataEnumerator;
    private int       _last;
    private int       _indexCurrent;

    #endregion Members

    #region Constructors

    public  ArrayMetaVertexEnumerator(ArrayMetaVertex data)
    {
      _data = data;
      _last = data.Last;
      Reset();
    }

    #endregion Constructors

    #region IEnumerator Members

    public void Reset()
    {
      _dataEnumerator = _data.Items.GetEnumerator();
      _dataEnumerator.Reset();
      _indexCurrent = -1;
    }

    public object Current
    {
      get
      {
        // TODO: Current Index must be check but for performance question, this is not done
        return _dataEnumerator.Current;
      }
    }

    public bool MoveNext()
    {
      _indexCurrent++;
      if (_indexCurrent >= _last)
        return (false);
      _dataEnumerator.MoveNext();
      if (_dataEnumerator.Current != null)
        return (true);
      while (_indexCurrent < _last && _dataEnumerator.MoveNext() && _dataEnumerator.Current == null)
        _indexCurrent++;
      return (_indexCurrent < _last);
    }

    #endregion

    public bool MoveRealNext()
    {
      _indexCurrent++;
      if (_indexCurrent >= _last)
        return (false);
      _dataEnumerator.MoveNext();
      return (true);
    }

  }

  /// <summary>
  /// Dynamic buffered array of MetaVertex
  /// </summary>
  public class ArrayMetaVertex : ICloneable
  {

    #region Members

    private MetaVertex []   _items;
    private ArrayList _freeItems = new ArrayList();
    private int       _size;
    private int       _bufferSize;
    private int       _last;
    private int				_count;

    #endregion Members

    #region Properties

    /// <summary>
    /// Items Property
    /// </summary>
    public MetaVertex [] Items
    {
      get { return (_items); }
    }

    /// <summary>
    /// Returns the last added elements' index + 1
    /// </summary>
    public int        Last
    {
      get { return _last; }
    }

    /// <summary>
    /// Returns the number of elements
    /// </summary>
    public int				Count
    {
      get { return _count; }
    }

    /// <summary>
    /// Operator [] to access to the i-th element
    /// </summary>
    public MetaVertex	      this[int index]
    {
      get { return(_items[index]); }
      set { _items[index] = value; }
    }

    #endregion Properties

    #region Constructors

    public            ArrayMetaVertex()
      : this (0, 256)
    {
    }

    public            ArrayMetaVertex(int size)
      : this (size, 256)
    {
    }

    public            ArrayMetaVertex(int size, int bufferSize)
    {
      _size = size;
      _bufferSize = bufferSize;
      _items = new MetaVertex[_size];
    }

    #endregion Constructors

    #region Events

    public event EventHandler ArrayChanged;

    #endregion Events
      
    #region Element manipulations

    /// <summary>
    /// Find a specified face
    /// </summary>
    /// <param name="face"></param>
    /// <returns>returns -1 if item not found, else returns item index</returns>
    public int 				Find(MetaVertex metaVertex)
    {
      for (int i = 0; i < _size; i++)
        if (_items[i] == metaVertex)
          return i;
      return -1;
    }

    public bool       Contains(MetaVertex metaVertex)
    {
      for (int i = 0; i < _size; i++)
        if (_items[i] == metaVertex)
          return true;
      return false;
    }

    public int        Add(MetaVertex metaVertex)
    {
      _count++;
      // Check if there is an element in free items
      if (_freeItems.Count > 0)
      {
        // Get first free index
        int index = (int)_freeItems[0];
        _items[index] = metaVertex;
        _freeItems.RemoveAt(0);
        if (ArrayChanged != null)
          ArrayChanged(this, new EventArgs());
        return index;
      }
      // If data array is too small, grow it
      if (_last >= _size)
        Resize(_size + _bufferSize);
      // Add the element in the data array
      _items[_last++] = metaVertex;
      if (ArrayChanged != null)
        ArrayChanged(this, new EventArgs());
      return (_last - 1);
    }

    public void       AddRange(ArrayMetaVertex metaVertexArray)
    {
      int             nbNewElts = metaVertexArray.Count;
      int             metaVertexArrayIndex = 0;
      // Check if there is an element in free items
      _count += nbNewElts;
      if (_freeItems.Count > 0)
      {
        for (metaVertexArrayIndex = 0; metaVertexArrayIndex < nbNewElts && _freeItems.Count > 0; metaVertexArrayIndex++)
        {
          int index = (int)_freeItems[0];
          _items[index] = metaVertexArray[metaVertexArrayIndex];
          _freeItems.RemoveAt(0);
        }
        if (metaVertexArrayIndex == nbNewElts && ArrayChanged != null)
        {
          ArrayChanged(this, new EventArgs());
          return ;
        }
      }
      // If data array is too small, grow it
      if (_last + (nbNewElts - metaVertexArrayIndex) >= _size)
        Resize(_size + (((nbNewElts - metaVertexArrayIndex) / _bufferSize) + 1) * _bufferSize);
      // Add the elements in the data array
      while (metaVertexArrayIndex < nbNewElts)
      {
        _items[_last++] = metaVertexArray[metaVertexArrayIndex++];
      }
      if (ArrayChanged != null)
        ArrayChanged(this, new EventArgs());
    }

    public void       Remove(int index)
    {
      if (_count == 0)
        return;
      _items[index] = null;
      _count--;
      if (index == _last - 1)
        _last--;
      else
        _freeItems.Add(index);
      if (ArrayChanged != null)
        ArrayChanged(this, new EventArgs());
    }

    // NOTE: This is correct only for the references that has an index member
    public void				Remove(MetaVertex metaVertex)
    {
      if (_count == 0)
        return;
      _count--;
      //      _items[metaVertex.index] = null;
      //      if (metaVertex.index == _last - 1)
      //        _last--;
      //      else
      //        _freeItems.Add(metaVertex.index);
      if (ArrayChanged != null)
        ArrayChanged(this, new EventArgs());
    }

    #endregion Element manipulations

    #region Array manipulations

    public int        Resize(int size)
    {
      _size = size;
      MetaVertex [] array = new MetaVertex[_size];
      _items.CopyTo(array, 0);
      _items = array;
      return (_size);
    }

    //    public ArrayMetaVertex  Clone()
    //    {
    //      ArrayMetaVertex array = new ArrayMetaVertex(_size, _bufferSize);
    //      array._freeItems = (ArrayList)_freeItems.Clone();
    //      array._last = _last;
    //      array._count = _count;
    //      return (array);
    //    }

    public object     Clone()
    {
      ArrayMetaVertex newItems = new ArrayMetaVertex();
      
      newItems._items = new MetaVertex[_size];
      newItems._freeItems = (ArrayList)_freeItems.Clone();
      newItems._size = _size;
      newItems._bufferSize = _bufferSize;
      newItems._last = _last;
      newItems._count = _count;

      for (int i = 0; i < _size; i++)
      {
        if (_items[i] == null)
          continue;
        newItems._items[i] = new MetaVertex();
        newItems._items[i].NormalId = _items[i].NormalId;
        newItems._items[i].VertexId = _items[i].VertexId;
        newItems._items[i].Normal = _items[i].Normal;
        newItems._items[i].Vertex = (Vertex)_items[i].Vertex.Clone();
        newItems._items[i].NeighborFaces = _items[i].NeighborFaces;
        newItems._items[i].NeighborVertices = _items[i].NeighborVertices;
      }

      if (ArrayChanged != null)
        newItems.ArrayChanged = (EventHandler)ArrayChanged.Clone();

      return newItems;
    }

    public void				Clear()
    {
      // TODO: Test if this works, Ask shaman
      //      foreach (MetaVertex metaVertex in _items)
      //        metaVertex = null;
      for (int i = 0; i < _last; i++)
        _items[i] = null;
      _last = 0;
      _count = 0;
      _freeItems.Clear();
      if (ArrayChanged != null)
        ArrayChanged(this, new EventArgs());
    }

    #endregion Array manipulations

    public IEnumerator GetEnumerator()
    {
      return (new ArrayMetaVertexEnumerator(this));
    }

    public void       TraceArray()
    {
      Trace.WriteLine("Array Size: " + _size);
      Trace.WriteLine("Buffer Size: " + _bufferSize);
      Trace.WriteLine("Free Items Count: " + _freeItems.Count);
      foreach (MetaVertex metaVertex in _items)
      {
        if (metaVertex == null)
          Trace.WriteLine("Empty Slot !!!");
        else
          Trace.WriteLine(metaVertex.ToString());
      }
    }
  }
}
