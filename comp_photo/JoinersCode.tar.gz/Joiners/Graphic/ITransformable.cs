//----------------------------------------------------------------------------
//  Project     : EdenArts.Graphic
//  Author      : Valerie Tching
//  Date        : 01/02/2005
//  File        : ITransformable.cs
//  Description : ITransformable interface
//----------------------------------------------------------------------------
//  EdenArts.Graphic is a 3D graphic engine library.
//  The project is running under QPL licence.
//    (QPL Licence specifications: http://www.trolltech.com/licenses/qpl.html)
//  Zion is part of Eden Arts Team Work
//  Members are:
//      Nadim Awad        (awad_n@epitech.net)
//      Michel Courtine   (courti_m@epitech.net)
//      Matthieu Dehaussy (dehaus_m@epitech.net)
//      Julien Ferrero    (ferrer_j@epitech.net)
//      Nicolas Goubaux   (goubau_n@epitech.net)
//      Valerie Tching    (tching_v@epitech.net)
//  You can have further information on Zion website:
//         http://zion.labtech.epitech.net
//----------------------------------------------------------------------------

using System;

namespace Joiners.Graphic
{
  /// <summary>
  /// ITransformable interface
  /// Define all the basic 3D transformations methods
  /// </summary>
  public interface ITransformable
  {

    void    Translate(float x, float y, float z);
    void    Rotate(float rx, float ry, float rz);
    void    Scale(float x, float y, float z);
    void    Place();

  }
}
