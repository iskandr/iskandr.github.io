//----------------------------------------------------------------------------
//  Project     : EdenArts.Graphic
//  Author      : Michel Courtine
//  Date        : 01/02/2005
//  File        : Scene.cs
//  Description : Scene class
//----------------------------------------------------------------------------
//  EdenArts.Graphic is a 3D graphic engine library.
//  The project is running under QPL licence.
//    (QPL Licence specifications: http://www.trolltech.com/licenses/qpl.html)
//  Zion is part of Eden Arts Team Work
//  Members are:
//      Nadim Awad        (awad_n@epitech.net)
//      Michel Courtine   (courti_m@epitech.net)
//      Matthieu Dehaussy (dehaus_m@epitech.net)
//      Julien Ferrero    (ferrer_j@epitech.net)
//      Nicolas Goubaux   (goubau_n@epitech.net)
//      Valerie Tching    (tching_v@epitech.net)
//  You can have further information on Zion website:
//         http://zion.labtech.epitech.net
//----------------------------------------------------------------------------

using System;
using System.ComponentModel;
using System.Collections;
using Tao.OpenGl;
///using EdenArts.Input;
using Joiners.Math;

namespace Joiners.Graphic
{
	/// <summary>
	/// Class used to describe the entire scene (meshes, materials, cameras, lights ...).
	/// </summary>
	public class            Scene
	{
    #region Members

    private string        _name;

    // Meshes
    private ArrayList     _meshes  = new ArrayList();
    private DrawType      _drawType = DrawType.SmoothHighlight;

    // Entities (single object or group of objects)
    public ArrayList      Entities = new ArrayList();
    public int            _entityIdMax = 0;
    private Entity        _dummyEntity = new Mesh();
    private int           _currentEntityId   = -1;

    // Cameras
    public ArrayList      Cameras = new ArrayList();
    private int           _currentCameraId = 0;

    // Lights
    public ArrayList      Lights  = new ArrayList();
    public OpenglLights   LightsID = new OpenglLights();
    private int           _nbLightUsed = -1;
    
    // Materials
    public Material[]     Materials = new Material[24];

    #endregion Members

    #region Constructors

    public                Scene()
    {

      _name = "Undefined";

      // Front Camera
      Camera camera = new Camera();
      camera.Name = "Front";
      //      CurrentMeshChanged += new EventHandler(camera.OnCurrentMeshChanged);
      Cameras.Add(camera);

      //Scene's materials library initialization
      InitializeMaterialsList();
    }

    #endregion Constructors

    #region Properties

    public string         Name
    {
      get { return (_name); }
      set { _name = value;  }
    }

    public ArrayList      Meshes
    {
      get { return (_meshes);}
    }

    public Entity         CurrentEntity
    {
      get { return (_currentEntityId != -1 ? (Entity)Entities[_currentEntityId] : _dummyEntity); }
      set 
      {
        _currentEntityId = 0;
        foreach (Entity entity in Entities)
        {
          if (entity == value)
            break ;
          _currentEntityId++;
        }
        if (_currentEntityId == Entities.Count)
          _currentEntityId = -1;
        OnCurrentEntityChanged();
      }
    }

    public Camera         CurrentCamera
    {
      get { return ((Camera)Cameras[_currentCameraId]); }
    }

    public int            SwitchLight
    {
      set
      {
        _nbLightUsed = value;
        if (_nbLightUsed > 7)
        {
          _nbLightUsed = 0;
        }
      }
      get{ return(_nbLightUsed); }
    }

    public DrawType       DrawType
    {
      get { return _drawType; }
      set
      {
        _drawType = ((value == DrawType.CallList) ? DrawType.None + 1 : value);
        foreach (Mesh mesh in _meshes)
          mesh.DrawType = _drawType;
      }
    }
    #endregion Properties

    #region Initialization && Uninitialization

    public bool         Initialize()
    {
      _currentCameraId  = 0;
      _currentEntityId  = -1;

      ((Camera)Cameras[0]).TargetDistance = 10.0f;
      ((Camera)Cameras[0]).RotateAroundAndLookAt(0.0f, 90.0f, 0.0f);

      OnCurrentEntityChanged();

      return (true);
    }

    public void         Uninitialize()
    {
      EntitiesClear();
      Lights    = new ArrayList();
      InitializeMaterialsList();
    }

    #endregion Initializations

    #region Entities

    #region Events

    public event CollectionChangeEventHandler EntitiesChanged;

    protected void        OnEntitiesChanged(CollectionChangeEventArgs e)
    {
      if (EntitiesChanged != null)
        EntitiesChanged(this, e);
    }

    public event EventHandler                 CurrentEntityChanged;

    protected void        OnCurrentEntityChanged()
    {
      if (CurrentEntityChanged != null)
        CurrentEntityChanged(null, new EventArgs());
    }

    #endregion Events

    public int            EntitiesAdd(Entity entity)
    {
      int                 index;

      entity.Id = _entityIdMax++;
      index = Entities.Add(entity);
      OnEntitiesChanged(new CollectionChangeEventArgs(CollectionChangeAction.Add, entity));
      return (index);
    }

    public void           EntitiesRemove(Entity entity)
    {
      Entity              entityToRemove = null;
      foreach (Entity ent in Entities)
        if (entity == ent)
          entityToRemove = entity;
      if (entityToRemove != null)
      {
        Entities.Remove(entityToRemove);
        OnEntitiesChanged(new CollectionChangeEventArgs(CollectionChangeAction.Remove, entityToRemove));
      }
    }

    public void           EntitiesClear()
    {
      _entityIdMax = 0;
      Entities.Clear();
      OnEntitiesChanged(new CollectionChangeEventArgs(CollectionChangeAction.Refresh, null));
      _meshes.Clear();
      Lights.Clear();
    }

    public Entity         GetEntityById(int id)
    {
      foreach (Entity entity in Entities)
        if (entity.Id == id)
          return (entity);
      return (null);
    }

    #endregion Entities

    #region Lights

    #region Event

    #endregion Event

    public int           LightsAdd(Light light)
    {
      int index = Lights.Add(light);
      EntitiesAdd(light);
      return(index);
    }

    public int           LightsRemove(Light light)
    {
      int index;
      int lightID = light.LightID;

      light.Desactivate();

      int count = GraphicEngine.Instance.Scene.LightsID.SetALightID(lightID);
      
      index = LightsID.CountDesActivated;

      Lights.Remove(light);

      foreach (Light onelight in Lights)
      {
        if (index == 0)
          break;
        if (onelight.LightID == -1)
        {
          onelight.LightID = GraphicEngine.Instance.Scene.LightsID.GetALightID();
          onelight.Initialize();
          onelight.Activate();
          count++;
          index--;
        }
      }
      EntitiesRemove(light);
      return (count);
    }

    #endregion Lights

    #region Camera

    public void           SwitchCamera()
    {
      _currentCameraId = (_currentCameraId + 1) % Cameras.Count;
    }

    public void           SwitchCameraTarget()
    {
      if (Entities.Count == 0)
        return ;
      _currentEntityId = (_currentEntityId + 1) % Entities.Count;
      CurrentCamera.Target = CurrentEntity.GetPosition();
      OnCurrentEntityChanged();
    }

    #endregion Camera

    public void                       SwitchDrawType()
    {
      DrawType currentDrawType = ((Mesh)_meshes[0]).DrawType;
      if (currentDrawType == DrawType.FacetHighlight)
        currentDrawType = DrawType.None;
      else
        currentDrawType++;
      foreach (Mesh mesh in _meshes)
        mesh.DrawType = currentDrawType;
    }

    public void                       Render()
    {
      CurrentCamera.FrameUpdate();

      CurrentCamera.Place();
      
      foreach (Light light in GraphicEngine.Instance.Scene.Lights)
        light.Activate();

      foreach (Entity entity in Entities)
      {
        Gl.glPushMatrix();
        entity.Place();
        entity.Draw();
        Gl.glPopMatrix();
      }
    }

    public void                       InitializeMaterialsList()
    {
      for (int index = 0; index < 24; index++)
      {
        Materials[index] = new Material();
      }
    }

    public string                     GetUniqueMeshName(string name)
    {
      foreach(Mesh mesh in _meshes)
      {
        if (mesh.Name.ToLower() == name.ToLower())
        {
          string newName;
          int meshNumber = 0;
          do
          {
            if (meshNumber < 10)
              newName = name + "0" + meshNumber;
            else
              newName = name + meshNumber;
            meshNumber++;
          }
          while(GetUniqueMeshName(newName) != newName);
          return (newName);
        }
      }
      return (name);
    }
  }
}
