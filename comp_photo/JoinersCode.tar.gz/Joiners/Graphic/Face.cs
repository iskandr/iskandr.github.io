//----------------------------------------------------------------------------
//  Project     : EdenArts.Graphic
//  Author      : Michel Courtine
//  Date        : 01/02/2005
//  File        : Face.cs
//  Description : Face class
//----------------------------------------------------------------------------
//  EdenArts.Graphic is a 3D graphic engine library.
//  The project is running under QPL licence.
//    (QPL Licence specifications: http://www.trolltech.com/licenses/qpl.html)
//  Zion is part of Eden Arts Team Work
//  Members are:
//      Nadim Awad        (awad_n@epitech.net)
//      Michel Courtine   (courti_m@epitech.net)
//      Matthieu Dehaussy (dehaus_m@epitech.net)
//      Julien Ferrero    (ferrer_j@epitech.net)
//      Nicolas Goubaux   (goubau_n@epitech.net)
//      Valerie Tching    (tching_v@epitech.net)
//  You can have further information on Zion website:
//         http://zion.labtech.epitech.net
//----------------------------------------------------------------------------

using System;
using Joiners.Math;

namespace Joiners.Graphic
{
	/// <summary>
  /// Sub-Element of a mesh describing the 3 vertices of the face, its normals, Texture Coordinates and Material ID.
  /// </summary>
	public class          Face : ICloneable
	{
		public int  []      VertexIds         = new int[6]{-1, -1, -1, -1, -1, -1};
    public int  []      TextureVertexIds  = new int[3];
    public Vector3D     Normal            = new Vector3D();
//    public int          MaterialId;
	
		public int	[]			FaceNeighborsIds		= new int[6]{-1, -1, -1, -1, -1, -1};
		public int					index;
    public int          _subdivisionFlag = 0;

    public int GetFlag() { return _subdivisionFlag; }
    public void SetFlag(int flag) { _subdivisionFlag = flag; }

		#	region Constructors
		public					Face()
		{
		}

		public 					Face(int VertexId1, int VertexId2, int VertexId3)
		{
			for (int i = 0; i < 3; i++)
				FaceNeighborsIds[i] = -1;
			for(int i = 0; i < 6; i++)
				VertexIds[i] = -1;
			VertexIds[0] = VertexId1;
			VertexIds[1] = VertexId2;
			VertexIds[2] = VertexId3;
			Normal.Set(0.0f, 0.0f, 0.0f);
		}
		# endregion // Constructors

		public void					RemoveAllFaceNeighbors()
		{
			for (int i = 0; i < 6; i++)
				FaceNeighborsIds[i] = -1;
		}

		public void					SetVertices(int vertex0, int vertex1, int vertex2)
		{
			this.VertexIds[0]= vertex0;
			this.VertexIds[1]= vertex1;
			this.VertexIds[2]= vertex2;
		}

		public bool					HasVertex(int index)
		{
			for (int i = 0; i < 3; i++)
				if (VertexIds[i] == index)
					return true;
			return false;
		}

		public int NbVertex()
		{
			int	NbVertices = 0;
			for (int i = 0; i < 6; i++)
				if (VertexIds[i] != -1)
					NbVertices++;
			return NbVertices;
		}

    public int NbFaceNeighbor()
    {
      int NbFace = 0;
      if (FaceNeighborsIds[0] != -1)
        NbFace += 1;
      if (FaceNeighborsIds[1] != -1)
        NbFace += 1;
      if (FaceNeighborsIds[2] != -1)
        NbFace += 1;
      return NbFace;
    }

    public object Clone()
    {
      Face clone = new Face(VertexIds[0], VertexIds[1], VertexIds[2]);
      TextureVertexIds.CopyTo(clone.TextureVertexIds, 0);
      clone.Normal = Normal;
      FaceNeighborsIds.CopyTo(clone.FaceNeighborsIds, 0);
      clone.index = index;
      clone._subdivisionFlag = _subdivisionFlag;
      return (clone);
    }
	}
}
