//----------------------------------------------------------------------------
//  Project     : EdenArts.Graphic
//  Author      : Michel Courtine
//  Date        : 01/02/2005
//  File        : Color.cs
//  Description : Color class
//----------------------------------------------------------------------------
//  EdenArts.Graphic is a 3D graphic engine library.
//  The project is running under QPL licence.
//    (QPL Licence specifications: http://www.trolltech.com/licenses/qpl.html)
//  Zion is part of Eden Arts Team Work
//  Members are:
//      Nadim Awad        (awad_n@epitech.net)
//      Michel Courtine   (courti_m@epitech.net)
//      Matthieu Dehaussy (dehaus_m@epitech.net)
//      Julien Ferrero    (ferrer_j@epitech.net)
//      Nicolas Goubaux   (goubau_n@epitech.net)
//      Valerie Tching    (tching_v@epitech.net)
//  You can have further information on Zion website:
//         http://zion.labtech.epitech.net
//----------------------------------------------------------------------------

using System;

namespace Joiners.Graphic
{
  /// <summary>
  /// Array of 4 floats defining Red, Green, Blue and Alpha values.
  /// </summary>
  public struct                   Color
  {
    #region Predefined colors

    public static readonly  Color Black   = new Color(0.0f, 0.0f, 0.0f);
    public static readonly  Color White   = new Color(1.0f, 1.0f, 1.0f);    
    public static readonly  Color Red     = new Color(1.0f, 0.0f, 0.0f);
    public static readonly  Color Green   = new Color(0.0f, 1.0f, 0.0f);    
    public static readonly  Color Blue    = new Color(0.0f, 0.0f, 1.0f);
    public static readonly  Color Yellow  = new Color(1.0f, 1.0f, 0.0f);    

    #endregion // Predefined colors

    #region Public attributs

    public float                  r;
    public float                  g;
    public float                  b;
    public float                  a;

    #endregion // Public attributs

    #region Properties

    public float[]                Values
    {
      get { return new float[] { r, g, b, a }; }
    }

    #endregion  // Properties

    #region Constructors

    public                        Color(uint color)
      : this(((color & 0xFF0000) >> 16) / 255.0f, ((color & 0xFF00) >> 8) / 255.0f, (color & 0xFF) / 255.0f, 1.0f)
    {

    }

    public                        Color(float r, float g, float b)
      : this(r, g, b, 1.0f)
    {
    }

    public                        Color(float r, float g, float b, float a)
    {
      this.r = r;
      this.g = g;
      this.b = b;
      this.a = a;
    }
    
    #endregion // Constructors

    #region Public methods

    public void                   Set(Color color)
    {
      r = color.r; g = color.g; b = color.b; a = color.a;
    }

    public  void                  SetRGB(float r, float g, float b)
    {
      SetRGBA(r, g, b, 1.0f);
    }

    public  void                  SetRGBA(float r, float g, float b, float a)
    {
      this.r = r;
      this.g = g;
      this.b = b;
      this.a = a;
    } 

    #endregion // Public methods

    #region Static public methods

    static public Color           FromRGB(int r, int g, int b)
    {
      return new Color((float)r / 255f, (float)g / 255f, (float)b / 255f);
    }

    static public Color           FromRGBA(int r, int g, int b, int a)
    {
      return new Color((float)r / 255f, (float)g / 255f, (float)b / 255f, (float)a / 255f);
    }

    #endregion // Static public methods
  }
}
