//----------------------------------------------------------------------------
//  Project     : EdenArts.Graphic
//  Author      : Michel Courtine
//  Date        : 01/02/2005
//  File        : ArrayVector3D.cs
//  Description : ArrayVector3D class
//----------------------------------------------------------------------------
//  EdenArts.Graphic is a 3D graphic engine library.
//  The project is running under QPL licence.
//    (QPL Licence specifications: http://www.trolltech.com/licenses/qpl.html)
//  Zion is part of Eden Arts Team Work
//  Members are:
//      Nadim Awad        (awad_n@epitech.net)
//      Michel Courtine   (courti_m@epitech.net)
//      Matthieu Dehaussy (dehaus_m@epitech.net)
//      Julien Ferrero    (ferrer_j@epitech.net)
//      Nicolas Goubaux   (goubau_n@epitech.net)
//      Valerie Tching    (tching_v@epitech.net)
//  You can have further information on Zion website:
//         http://zion.labtech.epitech.net
//----------------------------------------------------------------------------

using System;
using System.Collections;
using System.Diagnostics;
using Joiners.Graphic;
using Joiners.Math;

namespace Joiners.Graphic
{
  /// <summary>
  /// Array Vector3D Enumerator
  /// This class allows Array walking with foreach keyword
  /// </summary>
  public class ArrayVector3DEnumerator : IEnumerator
  {

    #region Members

    private ArrayVector3D _data;
    IEnumerator       _dataEnumerator;
    private int       _last;
    private int       _indexCurrent;

    #endregion Members

    #region Constructors

    public  ArrayVector3DEnumerator(ArrayVector3D data)
    {
      _data = data;
      _last = data.Last;
      Reset();
    }

    #endregion Constructors

    #region IEnumerator Members

    public void Reset()
    {
      _dataEnumerator = _data.Items.GetEnumerator();
      _dataEnumerator.Reset();
      _indexCurrent = -1;
    }

    public object Current
    {
      get
      {
        // TODO: Current Index must be check but for performance question, this is not done
        return _dataEnumerator.Current;
      }
    }

    public bool MoveNext()
    {
      _indexCurrent++;
      if (_indexCurrent >= _last)
        return (false);
      _dataEnumerator.MoveNext();
      if (_dataEnumerator.Current != null)
        return (true);
      while (_indexCurrent < _last && _dataEnumerator.MoveNext() && _dataEnumerator.Current == null)
        _indexCurrent++;
      return (_indexCurrent < _last);
    }

    #endregion

  }

  /// <summary>
  /// Dynamic buffered array of Vector3D
  /// </summary>
  public class ArrayVector3D : ICloneable
  {

    #region Members

    private Vector3D []   _items;
    private ArrayList _freeItems = new ArrayList();
    private int       _size;
    private int       _bufferSize;
    private int       _last;
    private int				_count;

    #endregion Members

    #region Properties

    /// <summary>
    /// Items Property
    /// </summary>
    public Vector3D [] Items
    {
      get { return (_items); }
    }

    /// <summary>
    /// Returns the last added elements' index + 1
    /// </summary>
    public int        Last
    {
      get { return _last; }
    }

    /// <summary>
    /// Returns the number of elements
    /// </summary>
    public int				Count
    {
      get { return _count; }
    }

    public int        Size
    {
      get { return _size; }
    }

    /// <summary>
    /// Operator [] to access to the i-th element
    /// </summary>
    public Vector3D	      this[int index]
    {
      get { return(_items[index]); }
      set { _items[index] = value; }
    }

    #endregion Properties

    #region Constructors

    public            ArrayVector3D()
      : this (0, 256)
    {
    }

    public            ArrayVector3D(int size)
      : this (size, 256)
    {
    }

    public            ArrayVector3D(int size, int bufferSize)
    {
      _size = size;
      _bufferSize = bufferSize;
      _items = new Vector3D[_size];
    }

    #endregion Constructors

    #region Element manipulations

    /// <summary>
    /// Find a specified face
    /// </summary>
    /// <param name="face"></param>
    /// <returns>returns -1 if item not found, else returns item index</returns>
    public int 				Find(Vector3D vector3D)
    {
      for (int i = 0; i < _size; i++)
        if (_items[i].Equals(vector3D))
          return i;
      return -1;
    }

    public int        Add(Vector3D vector3D)
    {
      _count++;
      // Check if there is an element in free items
      if (_freeItems.Count > 0)
      {
        // Get first free index
        int index = (int)_freeItems[0];
        _items[index] = vector3D;
        _freeItems.RemoveAt(0);
        return index;
      }
      // If data array is too small, grow it
      if (_last >= _size)
        Resize(_size + _bufferSize);
      // Add the element in the data array
      _items[_last++] = vector3D;
      return (_last - 1);
    }

    public void       Remove(int index)
    {
      if (_count == 0)
        return;
//      _items[index] = null;
      _count--;
      if (index == _last - 1)
        _last--;
      else
        _freeItems.Add(index);
    }

    // NOTE: This is correct only for the references that has an index member
    public void				Remove(Vector3D vector3D)
    {
      if (_count == 0)
        return;
      _count--;
      //      _items[vector3D.index] = null;
      //      if (vector3D.index == _last - 1)
      //        _last--;
      //      else
      //        _freeItems.Add(vector3D.index);
    }

    #endregion Element manipulations

    #region Array manipulations

    public int        Resize(int size)
    {
      _size = size;
      Vector3D [] array = new Vector3D[_size];
      _items.CopyTo(array, 0);
      _items = array;
      return (_size);
    }

    //    public ArrayVector3D  Clone()
    //    {
    //      ArrayVector3D array = new ArrayVector3D(_size, _bufferSize);
    //      array._freeItems = (ArrayList)_freeItems.Clone();
    //      array._last = _last;
    //      array._count = _count;
    //      return (array);
    //    }

    public object     Clone()
    {
      ArrayVector3D newItems = new ArrayVector3D();
      
      newItems._items = new Vector3D[_size];
      newItems._freeItems = (ArrayList)_freeItems.Clone();
      newItems._size = _size;
      newItems._bufferSize = _bufferSize;
      newItems._last = _last;
      newItems._count = _count;

      /* NOTE: Add this for ArrayFace
      for (int i = 0; i < _size; i++)
      {
        newFaces.Items[i] = new Face(Items[i].VertexIds[0], Items[i].VertexIds[1], Items[i].VertexIds[2]);
        Items[i].VertexNormalIds.CopyTo(newFaces.Items[i].VertexNormalIds, 0);
        Items[i].TextureVertexIds.CopyTo(newFaces.Items[i].TextureVertexIds, 0);
        newFaces.Items[i].Normal.SetXYZ(Items[i].Normal.x, Items[i].Normal.y, Items[i].Normal.z);
        Items[i].FaceNeighborsIds.CopyTo(newFaces.Items[i].FaceNeighborsIds, 0);
        newFaces.Items[i].index = Items[i].index;
      }
      */

      return newItems;
    }

    public void				Clear()
    {
      // TODO: Test if this works, Ask shaman
      //      foreach (Vector3D vector3D in _items)
      //        vector3D = null;
//      for (int i = 0; i < _last; i++)
//        _items[i] = null;
      _last = 0;
      _count = 0;
      _freeItems.Clear();
    }

    #endregion Array manipulations

    public IEnumerator GetEnumerator()
    {
      return (new ArrayVector3DEnumerator(this));
    }

    public void       TraceArray()
    {
      Trace.WriteLine("Array Size: " + _size);
      Trace.WriteLine("Buffer Size: " + _bufferSize);
      Trace.WriteLine("Free Items Count: " + _freeItems.Count);
      foreach (Vector3D vector3D in _items)
      {
        Trace.WriteLine(vector3D.ToString());
      }
    }
  }
}
