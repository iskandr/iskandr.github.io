//----------------------------------------------------------------------------
//  Project     : EdenArts.Graphic
//  Author      : Valerie Tching
//  Date        : 01/02/2005
//  File        : Camera.cs
//  Description : Camera class
//----------------------------------------------------------------------------
//  EdenArts.Graphic is a 3D graphic engine library.
//  The project is running under QPL licence.
//    (QPL Licence specifications: http://www.trolltech.com/licenses/qpl.html)
//  Zion is part of Eden Arts Team Work
//  Members are:
//      Nadim Awad        (awad_n@epitech.net)
//      Michel Courtine   (courti_m@epitech.net)
//      Matthieu Dehaussy (dehaus_m@epitech.net)
//      Julien Ferrero    (ferrer_j@epitech.net)
//      Nicolas Goubaux   (goubau_n@epitech.net)
//      Valerie Tching    (tching_v@epitech.net)
//  You can have further information on Zion website:
//         http://zion.labtech.epitech.net
//----------------------------------------------------------------------------

using System;
using System.Diagnostics;
using Joiners.Math;
using Tao.OpenGl;

namespace Joiners.Graphic
{

  #region Camera Move Event

  /// <summary>
  /// Camera Move Event Args
  /// </summary>
  public class        CameraMoveEventArgs : EventArgs
  {
    private readonly Camera.CameraAction _action;
    private readonly Vector3D     _move = new Vector3D();

    public            CameraMoveEventArgs(Camera.CameraAction action, Vector3D move)
    {
      _action = action;
      _move.Set(move);
    }

    public Camera.CameraAction  Action { get { return (_action); } }
    public Vector3D             Move   { get { return (_move);   } }

  }

  /// <summary>
  /// CameraMoveEventHandler Delegate declaration
  /// </summary>
  public delegate void  CameraMoveEventHandler(object sender, CameraMoveEventArgs e);

  #endregion Camera Move Event

  /// <summary>
  /// Class used to decribe a camera: its position, orientation and clipping.
  /// </summary>
  public class          Camera : ITransformable
  {

    #region Enums

    public enum         CameraAction
    {
      None,
      Translation,
      Rotation,
      RotationAround,
      Zoom,
    }

    #endregion Enums

    #region Members

    private string      _name;
    private Matrix4D    _matrix             = new Matrix4D();
    private Vector3D    _position           = new Vector3D();
    private Quaternion  _quaternion         = new Quaternion();
    private float       _nearClipping;
    private float       _farClipping;
    private Vector3D    _target             = new Vector3D(0.0f, 0.0f, 0.0f);
    private float       _targetDistance     = 100.0f;
    private Vector3D    _targetRotation     = new Vector3D(0.0f, 0.0f, 0.0f);
    private bool        _smooth             = false;
    private CameraAction _action            = CameraAction.None;
    private bool        _frameUpdateNeeded  = false;
    private Vector3D    _acceleration;

    #endregion Members

    #region Properties

    public string       Name
    {
      get { return _name; }
      set { _name = value; }
    }

    public Quaternion   Quaternion
    {
      set { _quaternion = value;  }
      get { return (_quaternion); }
    }

    public Matrix4D     Matrix
    {
      get { return (_matrix); }
    }

    public Vector3D     Target
    {
      get { return _target; }
      set {
        _target = value; 
        Vector3D rotation = new Vector3D();
        LookAt(_target, ref rotation);
        _quaternion.FromEuler(-rotation.y, 0, rotation.x);
        _targetRotation.x = rotation.x; _targetRotation.y = rotation.y; _targetRotation.z = 0;
        Vector3D v = new Vector3D(_target.x - _position.x, _target.y - _position.y,_target.z - _position.z);
        _targetDistance = v.Length;
        UpdateMatrix();
        OnCameraMoved(new CameraMoveEventArgs(CameraAction.None, new Vector3D()));
      }
    }

    public float        TargetDistance
    {
      get { return (_targetDistance); }
      set { 
        _targetDistance = value;
        RotateAround(_target, _targetDistance, _targetRotation.x, _targetRotation.y); 
      }
    }

    public Vector3D     TargetRotation
    {
      get { return (_targetRotation); }
      set { _targetRotation = value; }
    }

    public bool         Smooth
    {
      get { return (_smooth); }
      set { _smooth = value; }
    }

    #endregion Properties

    #region Constructors

    public              Camera()
    {
    }

    public              Camera(float x, float y, float z)
    {
      _position.Set(x, y, z);
      _nearClipping = 0.0f;
      _farClipping = 1000.0f;
      UpdateMatrix();
    }

    public              Camera(float x, float y, float z, float nearClipping, float farClipping)
                        : this(x, y, z)
    {
      _nearClipping = nearClipping;
      _farClipping = farClipping;
    }

    public              Camera(float x, float y, float z, float roll, float pitch, float yaw, float nearClipping, float farClipping)
                        : this(x, y, z, nearClipping, farClipping)
    {
      _quaternion.FromEuler(roll, pitch, yaw);
      UpdateMatrix();
    }

    #endregion Constructors

    #region Events

    /// <summary>
    /// Events
    ///  - CameraMoved
    /// </summary>
    public event CameraMoveEventHandler CameraMoved;
    public event EventHandler           CameraSmoothMoveEnd;

    protected void      OnCameraMoved(CameraMoveEventArgs e)
    {
      if (CameraMoved != null)
        CameraMoved(this, e);
    }

    protected void      OnCameraSmoothMoveEnd(EventArgs e)
    {
      if (CameraSmoothMoveEnd != null)
        CameraSmoothMoveEnd(this, e);
    }

    public void         OnCurrentMeshChanged(object o, EventArgs e)
    {
//      Quaternion        q = new Quaternion(_quaternion);
//      Target = GraphicEngine.Instance.Scene.CurrentMesh.GetPosition();
//      _quaternion = q;
    }

    #endregion Events

    #region Transformations

    #region Matrix

    private void        UpdateMatrix()
    {
      float [] axis = { 0.0f, 0.0f, 0.0f, 0.0f };
      _quaternion.ToAxis(axis);

      _matrix.Set(Matrix4D.Identity);
      _matrix.FromAxis(axis[0], -axis[1], -axis[2], -axis[3]);
      Matrix4D translationMatrix = new Matrix4D();
      translationMatrix.SetTranslationMatrix(-_position.x, -_position.y, -_position.z);
      _matrix.Multiply(translationMatrix);
    }

    #endregion Matrix

    #region Translation

    public Vector3D     GetPosition()
    {
      return (_position);
    }

    public void         SetPosition(float x, float y, float z)
    {
      _position.x = x; _position.y = y; _position.z = z;
      UpdateMatrix();
      OnCameraMoved(new CameraMoveEventArgs(CameraAction.None, new Vector3D()));
    }

    public void         SetPosition(Vector3D v)
    {
      SetPosition(v.x, v.y, v.z);
    }

    public void         Translate(float x, float y, float z)
    {
      Quaternion        q = new Quaternion(_quaternion);
      Vector3D          vectorTranslationWorldSpace = q.RotateVector(new Vector3D(x, y, z));
      _position.x  += vectorTranslationWorldSpace.x;
      _position.y  += vectorTranslationWorldSpace.y;
      _position.z += vectorTranslationWorldSpace.z;
      _target.x += vectorTranslationWorldSpace.x; _target.y += vectorTranslationWorldSpace.y; _target.z += vectorTranslationWorldSpace.z;
      UpdateMatrix();
      OnCameraMoved(new CameraMoveEventArgs(CameraAction.Translation, vectorTranslationWorldSpace));
    }

    public void         Translate(Vector3D v)
    {
      Translate(v.x, v.y, v.z);
    }

    public void         TranslateSmooth(float x, float y, float z)
    {
      _smooth = true;
      Translate(x, y, z);
      //if (_smooth)
      {
        if (_action != CameraAction.Translation)
          _acceleration.Set(0, 0, 0);
        Accelerate(x, y, z);
        _action = CameraAction.Translation;
      }
    }
    public void         TranslateSmooth(Vector3D v)
    {
      TranslateSmooth(v.x, v.y, v.z);
    }

    #endregion Translation

    #region Rotation

    public void         Rotate(float rx, float ry, float rz)
    {
      Quaternion        q = new Quaternion();
      Quaternion        qOld = new Quaternion(_quaternion);
      q.FromEuler(rx, ry, rz);
      _quaternion = q * _quaternion;
      q = _quaternion / qOld;
      _target = q.RotateVector(_target - _position) + _position;
      UpdateMatrix();
      OnCameraMoved(new CameraMoveEventArgs(CameraAction.Rotation, new Vector3D(rx, ry, rz)));
    }

    public void         Rotate(Quaternion q)
    {
      Quaternion        qOld = new Quaternion(_quaternion);
      _quaternion = q * _quaternion;
      q = _quaternion / qOld;
      _target = q.RotateVector(_target - _position) + _position;
      UpdateMatrix();
      OnCameraMoved(new CameraMoveEventArgs(CameraAction.Rotation, new Vector3D()));
    }

    public void         RotateSmooth(float rx, float ry, float rz)
    {
      _smooth = true;
      Rotate(rx, ry, rz);
      //if (_smooth)
      {
        if (_action != CameraAction.Rotation)
          _acceleration.Set(0, 0, 0);
        Accelerate(rx, ry, rz);
        _action = CameraAction.Rotation;
      }
    }

    public void         RotateAround(Vector3D centerRotation, float radius, float longitude, float latitude)
    {
      Quaternion        q = new Quaternion(_quaternion);
      Vector3D          newPosition = q.RotateVector(new Vector3D(0, -radius, 0));
      Vector3D          translation = newPosition + centerRotation - _position;
      _position.Set(newPosition + centerRotation);
      UpdateMatrix();
      OnCameraMoved(new CameraMoveEventArgs(CameraAction.RotationAround, translation));
    }

    public void         RotateAroundAndLookAt(Vector3D centerRotation, float radius, float longitude, float latitude, float spin)
    {
      _targetRotation.x = longitude; _targetRotation.y = latitude;  _targetRotation.z = spin;
      _quaternion.FromEuler(-latitude, 0.0f, longitude);
      Rotate(0.0f, -spin, 0.0f);
      RotateAround(centerRotation, radius, longitude, latitude);
      UpdateMatrix();
    }

    public void         RotateAroundAndLookAt(float longitude, float latitude, float spin)
    {
      RotateAroundAndLookAt(_target, _targetDistance, longitude, latitude, spin);
    }

    public void         RotateAroundAndLookAtRelative(float longitude, float latitude, float spin)
    {
      _targetDistance = new Vector3D(_position.x - _target.x, _position.y - _target.y, _position.z - _target.z).Length;
      _targetRotation.x += longitude; _targetRotation.y += latitude;  _targetRotation.z += spin;
      RotateAroundAndLookAt(_targetRotation.x, _targetRotation.y, _targetRotation.z);
    }

    public void         RotateAroundAndLookAtSmooth(float longitude, float latitude, float spin)
    {
      _smooth = true;
      _targetDistance = new Vector3D(_position.x - _target.x, _position.y - _target.y, _position.z - _target.z).Length;
      _targetRotation.x += longitude; _targetRotation.y += latitude;  _targetRotation.z += spin;
      RotateAroundAndLookAt(_targetRotation.x, _targetRotation.y, _targetRotation.z);
      //if (_smooth)
      {
        if (_action != CameraAction.RotationAround)
          _acceleration.Set(0, 0, 0);
        Accelerate(longitude, latitude, spin);
        _action = CameraAction.RotationAround;
      }
    }

    public void         LookAt(Vector3D point, ref Vector3D rotation)
    {
      Vector3D          localVector = new Vector3D(_position.x - point.x, _position.y - point.y, _position.z - point.z);
      float             distance = localVector.Length;
      float             distanceXYPlan = (float)System.Math.Sqrt(localVector.x * localVector.x + localVector.y * localVector.y);
      float             latitude = 0.0f;
      float             longitude = 0.0f;

      if (distance > 0.0f)
        latitude = Joiners.Math.Math.RadToDeg(Joiners.Math.Math.Asin(localVector.z / distance));
      if (distanceXYPlan > 0.0f)
      {
        longitude = (float)System.Math.Acos(-localVector.y / distanceXYPlan);
        if (localVector.x < 0)
          longitude = -longitude;
        longitude = Joiners.Math.Math.RadToDeg(longitude);
      }
      rotation.Set(longitude, latitude, 0);
      OnCameraMoved(new CameraMoveEventArgs(CameraAction.None, new Vector3D()));
    }

    #endregion Rotation

    #region Scale

    public void         Scale(float x, float y, float z)
    {
    }

    #endregion Scale

    #region Zoom

    public void         Zoom(float zoomStep)
    {
      if (TargetDistance + zoomStep > 0.0f)
        TargetDistance = TargetDistance + zoomStep;
    }

    public void         ZoomSmooth(float zoomStep)
    {
      _smooth = true;
      Zoom(zoomStep);
      //if (_smooth)
      {
        if (_action != CameraAction.Zoom)
          _acceleration.Set(0.0f, 0.0f, 0.0f);
        Accelerate(zoomStep, 0.0f, 0.0f);
        _action = CameraAction.Zoom;
      }
    }

    #endregion Zoom

    public void         Place()
    {
      Matrix4D  m = new Matrix4D(_matrix);
      m.Transpose();
      Gl.glMultMatrixf(m.Values);

//      axis[0] = EdenArts.Math.Math.RadToDeg(axis[0]);
//      Gl.glRotatef(axis[0], -axis[1], -axis[2], -axis[3]);
//      Gl.glTranslatef(-_position.x, -_position.y, -_position.z);

    }

    #endregion Transformations

    #region System Coordinates

    public Vector3D             CameraToWorldTranslation(Vector3D vector)
    {
      return (Quaternion.RotateVector(vector));
    }

    public Vector3D             CameraToWorldCoordinates(Vector3D vector)
    {
      return (Quaternion.RotateVector(vector) + _position);
    }

    public Vector3D             WorldToCameraCoordinates(Vector3D vector)
    {
      Quaternion                q = !Quaternion;
      return (q.RotateVector(vector - _position));
    }

    #endregion System Coordinates

    public void         Accelerate(float x, float y, float z)
    {
      _acceleration.x += x;
      _acceleration.y += y;
      _acceleration.z += z;
      _frameUpdateNeeded = true;
    }

    #region Timer

    public void         FrameUpdate()
    {
      if (_frameUpdateNeeded == false)
        return ;
      float percentage = 0.93f;
      _acceleration.x *= percentage;
      _acceleration.y *= percentage;
      _acceleration.z *= percentage;
      switch (_action)
      {
        case CameraAction.Translation:
          Translate(_acceleration.x, _acceleration.y, _acceleration.z);
          break ;
        case CameraAction.Rotation:
          Rotate(_acceleration.x, _acceleration.y, _acceleration.z);
          break ;
        case CameraAction.RotationAround:
          _targetRotation.x += _acceleration.x; _targetRotation.y += _acceleration.y;  _targetRotation.z += _acceleration.z;
          RotateAroundAndLookAt(_target, _targetDistance, _targetRotation.x, _targetRotation.y, _targetRotation.z);
          break ;
        case CameraAction.Zoom:
          Zoom(_acceleration.x);
          break ;
      }
      float minimum = 0.02f;
      if (_acceleration.x < minimum && _acceleration.x > -minimum &&
          _acceleration.y < minimum && _acceleration.y > -minimum &&
          _acceleration.z < minimum && _acceleration.z > -minimum)
      {
        _acceleration.x = 0.0f;
        _acceleration.y = 0.0f;
        _acceleration.z = 0.0f;
        _frameUpdateNeeded = false;
        _action = CameraAction.None;
        _smooth = false;
        OnCameraMoved(new CameraMoveEventArgs(CameraAction.None, Vector3D.Empty));
      }
    }

    #endregion Timer

  }
}
