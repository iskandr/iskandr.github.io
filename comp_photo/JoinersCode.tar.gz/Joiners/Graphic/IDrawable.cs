//----------------------------------------------------------------------------
//  Project     : EdenArts.Graphic
//  Author      : Valerie Tching
//  Date        : 01/02/2005
//  File        : IDrawable.cs
//  Description : IDrawable interface
//----------------------------------------------------------------------------
//  EdenArts.Graphic is a 3D graphic engine library.
//  The project is running under QPL licence.
//    (QPL Licence specifications: http://www.trolltech.com/licenses/qpl.html)
//  Zion is part of Eden Arts Team Work
//  Members are:
//      Nadim Awad        (awad_n@epitech.net)
//      Michel Courtine   (courti_m@epitech.net)
//      Matthieu Dehaussy (dehaus_m@epitech.net)
//      Julien Ferrero    (ferrer_j@epitech.net)
//      Nicolas Goubaux   (goubau_n@epitech.net)
//      Valerie Tching    (tching_v@epitech.net)
//  You can have further information on Zion website:
//         http://zion.labtech.epitech.net
//----------------------------------------------------------------------------

using System;

namespace Joiners.Graphic
{
  /// <summary>
  /// Summary description for IDrawable.
  /// </summary>
  public interface  IDrawable
  {
    void            Draw();
  }
}
