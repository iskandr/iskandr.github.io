﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

using Joiners.Engine;
using AForge.Imaging;
using AForge.Imaging.Filters;

namespace Joiners
{
  public partial class ImageViewer : Form
  {
    #region Members

    private JoinerImage _image = null;
    private Bitmap _bmp = null;
    private Bitmap _prevImage = null;
    private Tool _currentTool = Tool.NONE;
    private enum Tool { SELECT, CROP, NONE };
    private Point _startSelectMousePos;
    private Rectangle _selection = Rectangle.Empty;
    private double _invxRatio = 0;
    private double _invyRatio = 0;
    #endregion //Members

    #region Properties

    public JoinerImage JoinerImage
    {
      get { return _image; }
      set { _image = value; }
    }

    public Bitmap Result
    {
        get { return _image.Image; }
    }

    #endregion //Properties

    #region Constructor

    public ImageViewer()
    {
      InitializeComponent();
    }

    public ImageViewer(JoinerImage image)
    {
       _image = image;
       InitializeComponent();
    }

    #endregion //Constructor

    #region Events

    #endregion //Events

    #region Methods

    public void LoadImage()
    {
      System.Drawing.Image img = _image.Image;
      int newWidth;
      int newHeight;

      newWidth = img.Width;
      newHeight = img.Height;
      this.Width = newWidth;
      this.Height = newHeight;

      if (img.Width > Screen.PrimaryScreen.WorkingArea.Width - (Screen.PrimaryScreen.WorkingArea.Width / 10))
      {
        pictureBox.Width = Screen.PrimaryScreen.WorkingArea.Width - (Screen.PrimaryScreen.WorkingArea.Width / 10);
        newWidth = pictureBox.Width;
        newHeight = (pictureBox.Width * img.Height) / img.Width;
        pictureBox.Height = newHeight;
      }

      if (newHeight > Screen.PrimaryScreen.WorkingArea.Height - (Screen.PrimaryScreen.WorkingArea.Height / 10))
      {
        pictureBox.Height = Screen.PrimaryScreen.WorkingArea.Height - (Screen.PrimaryScreen.WorkingArea.Height / 10);
        newWidth = (pictureBox.Height * newWidth) / newHeight;
        newHeight = pictureBox.Height;
        pictureBox.Width = newWidth;
      }
      _invxRatio = (double)img.Width / (double)newWidth;
      _invyRatio = (double)img.Height / (double)newHeight;

      this.Text = Path.GetFileName(_image.FileName);

      _bmp = new Bitmap(newWidth, newHeight, img.PixelFormat);
      Graphics g = Graphics.FromImage(_bmp);
      
      g.DrawImage(img, 0, 0, newWidth, newHeight);
        
      this.pictureBox.Width= newWidth;
      this.pictureBox.Height = newHeight;
      pictureBox.Image = _bmp;
      UpdateStatusBar((Bitmap)_bmp);
    }

    private void UpdateStatusBar(Bitmap shownImage)
    {
        double percentage = ((double)(shownImage.Width * shownImage.Height) / (double)(_image.Image.Width * _image.Image.Height)) * 100.0;
        StringBuilder stringB = new StringBuilder();
        stringB.Append(shownImage.Width + "x" + shownImage.Height + "(" + (int)percentage + "%)");
        statusLabel.Text = stringB.ToString();
    }

    private Rectangle RectangleFromPoints(Point p1, Point p2)
    {
        int x;
        int y;

        x = (p1.X <= p2.X) ? p1.X : p2.X;
        y = (p1.Y <= p2.Y) ? p1.Y : p2.Y;

        return new Rectangle(x, y, System.Math.Abs(p1.X - p2.X), System.Math.Abs(p1.Y - p2.Y));
    }

    #endregion //Methods

    private void cropToolStripMenuItem_Click(object sender, EventArgs e)
    {
        if (_selection != Rectangle.Empty)
        {
            _prevImage = new Bitmap(_image.Image);
            undoToolStripMenuItem.Enabled = true;
            Rectangle cropRectangle = new Rectangle((int)((double)_selection.X * _invxRatio), (int)((double)_selection.Y * _invyRatio),
                (int)((double)_selection.Width * _invxRatio), (int)((double)_selection.Height * _invyRatio));
            Crop cropFilter = new Crop(cropRectangle);
            _image.Image = cropFilter.Apply(_image.Image);
            LoadImage();
            _selection = Rectangle.Empty;
            pictureBox.Invalidate();
        }
    }

    private void pictureBox_MouseDown(object sender, MouseEventArgs e)
    {
        _currentTool = Tool.SELECT;
        this.Cursor = Cursors.Cross;
        _startSelectMousePos = e.Location;
    }

    private void pictureBox_MouseMove(object sender, MouseEventArgs e)
    {
        if (_currentTool == Tool.SELECT)
        {
            Point pt = new Point(e.X, e.Y);
            if (e.X >= _bmp.Width)
                pt.X = _bmp.Width;
            if (e.Y >= _bmp.Height)
                pt.Y = _bmp.Height;
            
            _selection = RectangleFromPoints(_startSelectMousePos, pt);
            this.pictureBox.Invalidate();
        }
    }

    private void pictureBox_MouseUp(object sender, MouseEventArgs e)
    {
        _currentTool = Tool.NONE;
        this.Cursor = Cursors.Arrow;
    }

    private void pictureBox_Paint(object sender, PaintEventArgs e)
    {
        if (_selection != Rectangle.Empty)
        {
            Pen dashPen = new Pen(Color.LightGreen);
            dashPen.DashCap = DashCap.Round;
            dashPen.DashStyle = DashStyle.Dash;
          e.Graphics.DrawRectangle(dashPen, _selection);
        }
    }


    private void blurToolStripMenuItem_Click(object sender, EventArgs e)
    {
        _prevImage = new Bitmap(_image.Image);
        undoToolStripMenuItem.Enabled = true;
        Blur blur = new Blur();
        if (_selection == Rectangle.Empty)
        {

            _image.Image = blur.Apply(_image.Image);
            LoadImage();
            return;
        }
        Rectangle blurRectangle = new Rectangle((int)((double)_selection.X * _invxRatio), (int)((double)_selection.Y * _invyRatio),
                                    (int)((double)_selection.Width * _invxRatio), (int)((double)_selection.Height * _invyRatio));
        blur.ApplyInPlace(_image.Image, blurRectangle);
        LoadImage();
        pictureBox.Invalidate();
    }

    private void gaussianBlurToolStripMenuItem_Click(object sender, EventArgs e)
    {
        _prevImage = new Bitmap(_image.Image);
        undoToolStripMenuItem.Enabled = true;
        GaussianBlurForm gBlurF = new GaussianBlurForm();
        if (gBlurF.ShowDialog() == DialogResult.Cancel)
            return;
        GaussianBlur gBlur = new GaussianBlur(gBlurF.Sigma, gBlurF.KernelSize);
                if (_selection == Rectangle.Empty)
        {
            
            _image.Image = gBlur.Apply(_image.Image);
            LoadImage();
            return;
        }
        Rectangle blurRectangle = new Rectangle((int)((double)_selection.X * _invxRatio), (int)((double)_selection.Y * _invyRatio),
                                    (int)((double)_selection.Width * _invxRatio), (int)((double)_selection.Height * _invyRatio));
        gBlur.ApplyInPlace(_image.Image, blurRectangle);
        LoadImage();
        pictureBox.Invalidate();
    }

    private void histogramEqualizationToolStripMenuItem_Click(object sender, EventArgs e)
    {
        _prevImage = new Bitmap(_image.Image);
        undoToolStripMenuItem.Enabled = true;
        HistogramEqualization hE = new HistogramEqualization();
        if (_selection == Rectangle.Empty)
        {

            _image.Image = hE.Apply(_image.Image);
            LoadImage();
            return;
        }
        Rectangle heRectangle = new Rectangle((int)((double)_selection.X * _invxRatio), (int)((double)_selection.Y * _invyRatio),
                                    (int)((double)_selection.Width * _invxRatio), (int)((double)_selection.Height * _invyRatio));
        hE.ApplyInPlace(_image.Image, heRectangle);
        LoadImage();
        pictureBox.Invalidate();
    }

    private void oilPaintingToolStripMenuItem_Click(object sender, EventArgs e)
    {
        _prevImage = new Bitmap(_image.Image);
        undoToolStripMenuItem.Enabled = true;
        OilPainting oP = new OilPainting();
        if (_selection == Rectangle.Empty)
        {

            _image.Image = oP.Apply(_image.Image);
            LoadImage();
            return;
        }
        Rectangle oPRectangle = new Rectangle((int)((double)_selection.X * _invxRatio), (int)((double)_selection.Y * _invyRatio),
                                    (int)((double)_selection.Width * _invxRatio), (int)((double)_selection.Height * _invyRatio));
        oP.ApplyInPlace(_image.Image, oPRectangle);
        LoadImage();
        pictureBox.Invalidate();
    }

    private void sepiaToolStripMenuItem_Click(object sender, EventArgs e)
    {
        _prevImage = new Bitmap(_image.Image);
        undoToolStripMenuItem.Enabled = true;
        Sepia sepia = new Sepia();
        if (_selection == Rectangle.Empty)
        {

            _image.Image = sepia.Apply(_image.Image);
            LoadImage();
            return;
        }
        Rectangle sepiaRectangle = new Rectangle((int)((double)_selection.X * _invxRatio), (int)((double)_selection.Y * _invyRatio),
                                    (int)((double)_selection.Width * _invxRatio), (int)((double)_selection.Height * _invyRatio));
        sepia.ApplyInPlace(_image.Image, sepiaRectangle);
        LoadImage();
        pictureBox.Invalidate();
    }

    private void sharpenToolStripMenuItem_Click(object sender, EventArgs e)
    {
        _prevImage = new Bitmap(_image.Image);
        undoToolStripMenuItem.Enabled = true;
        Sharpen sharpen = new Sharpen();
        if (_selection == Rectangle.Empty)
        {

            _image.Image = sharpen.Apply(_image.Image);
            LoadImage();
            return;
        }
        Rectangle sharpenRectangle = new Rectangle((int)((double)_selection.X * _invxRatio), (int)((double)_selection.Y * _invyRatio),
                                    (int)((double)_selection.Width * _invxRatio), (int)((double)_selection.Height * _invyRatio));
        sharpen.ApplyInPlace(_image.Image, sharpenRectangle);
        LoadImage();
        pictureBox.Invalidate();
    }

    private void undoToolStripMenuItem_Click(object sender, EventArgs e)
    {
        _image.Image = _prevImage;
        LoadImage();
        undoToolStripMenuItem.Enabled = false;
        pictureBox.Invalidate();
    }
  }
}
