﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Drawing.Imaging;

using Joiners.Engine;
using Tao.OpenGl;
using Tao.Platform.Windows;

namespace Joiners
{
  public partial class FormMain : Form
  {
    #region Members

    ImageViewer _view = null;
    private bool  _doubleClick = false;
    private ArrayList _joinerImages = new ArrayList();


    private JoinerImage _similarityImage = null; 
    private ImageComparison _rgbHistogram =  new RGB_Histogram(); 
    private ImageComparison _differenceComparison = new EuclideanDistance();
    private ImageComparison _chromaHistogram = new ChromaHistogram();
    private ImageComparison _chromaBorder = new ChromaBorder();
    private ImageComparison _saturationBorder = new SaturationBorder();
    private ImageComparison _rgbBorder = new RGB_Border(); 

    private ImageComparison _defaultComparison = null; 
    

    #endregion //Members

    #region Constructor

    public FormMain()
    {
        InitializeComponent();
        this.panelMain.findSimilar += new PanelMain.FindSimilarHandler(handleFindSimilar);

        string[] names = { "Chroma Border", "Saturation Border", "RGB Border", "Chroma Histogram", "RGB Histogram", "Euclidean Distance" };
        ddlSimilarity.Items.AddRange(names);
        ddlSimilarity.SelectedIndex = 0;
        _defaultComparison = _chromaBorder;

    }

    #endregion //Constructor

    #region Events

    private void FormMain_Load(object sender, EventArgs e)
    {
     
    }

    private void openDirectoryToolStripMenuItem_Click(object sender, EventArgs e)
    {
      DialogResult result = folderBrowserDialog.ShowDialog();
      if (result == DialogResult.Cancel)
        return;
      imageList.Images.Clear();
      listViewImages.Items.Clear();
      _joinerImages.Clear();

      progressBarLoad.Visible = true;

      Console.WriteLine("Path is : " + folderBrowserDialog.SelectedPath);

      string[] imageFiles = Directory.GetFiles(folderBrowserDialog.SelectedPath, "*.jpg");

      int i = 0;
      JoinerImage jImg = null; 
      
        foreach (string imageFile in imageFiles)
      {

          try
          {
              Bitmap bmp = new Bitmap(imageFile);

              int thumbWidth = imageList.ImageSize.Width;
              int thumbHeight = imageList.ImageSize.Height;

              jImg = new JoinerImage(bmp, imageFile, thumbWidth, thumbHeight);
        }
         catch (Exception ex)
          {
              MessageBox.Show("Error occurred while loading files: " + ex.Message);
              panelMain.MainThread.Abort();
              Application.Exit(); 
          }
        
        _joinerImages.Add(jImg);
            
        progressBarLoad.Value = ((i + 1) * 100) / imageFiles.Length;
        
        imageList.Images.Add(jImg.PaddedThumbnail);
        
        ListViewItem item = new ListViewItem();
        item.ImageIndex = i;
        item.Tag = imageFile;
        i++;
        listViewImages.Items.Add(item);
        GC.Collect();
      }
      progressBarLoad.Visible = false;
    }

    private void quitToolStripMenuItem_Click(object sender, EventArgs e)
    {
      Application.Exit();
    }

    private void listViewImages_MouseDown(object sender, MouseEventArgs e)
    {
        hideBottomPanel(); 
        if (e.Clicks >= 2)
            _doubleClick = true;
        if (listViewImages.SelectedItems.Count != 0)
        {
            int index = listViewImages.SelectedItems[0].Index; 
            if (DoDragDrop(_joinerImages[index], DragDropEffects.Move) == DragDropEffects.Move)
            {
                _joinerImages.RemoveAt(index);
                listViewImages.Items.RemoveAt(index);
            }
        }
    }



    private void listViewImages_MouseUp(object sender, MouseEventArgs e)
    {
      Console.WriteLine("Nb Clicks : " + e.Clicks);
      if (_doubleClick == true)
      {
        _doubleClick = false;
        NewDoubleClick();
        return;
      }
    }

    private void bottomListView_ItemDrag(object sender, ItemDragEventArgs e)
    {
        if (bottomListView.SelectedItems.Count > 0)
        {
            //int index = bottomListView.SelectedItems[0].Index;
            JoinerImage image = ((JoinerListViewItem)(bottomListView.SelectedItems[0])).JoinerImage;
            if (DoDragDrop(image, DragDropEffects.Move) == DragDropEffects.Move)
            {
                _joinerImages.RemoveAt(image.Index);
                listViewImages.Items.RemoveAt(image.Index);
               
                hideBottomPanel(); 
            }
        }
    }


    private void backgroundColorToolStripMenuItem_Click(object sender, EventArgs e)
    {
        if (colorDialog.ShowDialog() != DialogResult.Cancel)
        {
            Gl.glClearColor((float)colorDialog.Color.R / 255.0F, (float)colorDialog.Color.G / 255.0F,
                (float)colorDialog.Color.B / 255.0F, (float)colorDialog.Color.A / 255.0F);
        }
    }

    private void ddlSimilarity_SelectedIndexChanged(object sender, EventArgs e)
    {
        Console.WriteLine(ddlSimilarity.SelectedItem); 
        switch ((string) ddlSimilarity.SelectedItem)
        {
            case "Chroma Border":
                _defaultComparison = _chromaBorder;
                this.findSimilarImages(_similarityImage);
                break;

            case "Saturation Border":
                _defaultComparison = _saturationBorder;
                this.findSimilarImages(_similarityImage);
                break;

            case "RGB Border":
                _defaultComparison = _rgbBorder;
                this.findSimilarImages(_similarityImage);
                break;

            case "Chroma Histogram":
                _defaultComparison = _chromaHistogram;
                this.findSimilarImages(_similarityImage);
                break;

            case "RGB Histogram":
                _defaultComparison = _rgbHistogram;
                this.findSimilarImages(_similarityImage); 
                break;

            case "Euclidean Distance":
                _defaultComparison =  _differenceComparison;
                this.findSimilarImages(_similarityImage); 
                break;

            default:
                hideBottomPanel();
                break;


        }
    }


  
    private void handleFindSimilar(object sender, JoinerImage selected)
    {
        // save the image so we can later reuse it for other similarity measures
        _similarityImage = selected;

        bool foundAny = findSimilarImages(selected); 
        if (foundAny) bottomPanel.BringToFront(); 
    }

    private void saveToolStripMenuItem_Click(object sender, EventArgs e)
    {
        DialogResult result = saveFileDialog.ShowDialog();
        if (result == DialogResult.Cancel)
            return;

        Bitmap b = new Bitmap(panelMain.Width, panelMain.Height, PixelFormat.Format32bppArgb);
        BitmapData bd = b.LockBits(new System.Drawing.Rectangle(0, 0, panelMain.Width, panelMain.Height),
        ImageLockMode.WriteOnly, PixelFormat.Format32bppArgb);
        Gl.glReadPixels(0, 0, panelMain.Width, panelMain.Height, Gl.GL_BGRA_EXT, Gl.GL_UNSIGNED_BYTE, bd.Scan0);
        b.UnlockBits(bd); b.RotateFlip(RotateFlipType.RotateNoneFlipY);
        b.Save(saveFileDialog.FileName, ImageFormat.Bmp);
    }

    #endregion //Events

    #region Methods

      //edits joiner, saves result in joiner.Image and also returns result as a Bitmap
    public Bitmap EditImage(JoinerImage img)
    {
        _view = new ImageViewer(img);
        _view.LoadImage();
        _view.ShowDialog();
        _view.Focus();
        Bitmap result = _view.Result;
        img.Image = result;
        return result; 
    }

    public void NewDoubleClick()
    {
      if (listViewImages.SelectedItems.Count <= 0)
        return;

      string path = (string)listViewImages.SelectedItems[0].Tag;
      JoinerImage img = (JoinerImage)_joinerImages[listViewImages.SelectedItems[0].Index];
      Bitmap result = EditImage(img); 
      imageList.Images.Add(img.PaddedThumbnail);
      listViewImages.SelectedItems[0].ImageIndex = imageList.Images.Count - 1;
    }

    private void hideBottomPanel()
    {
        this.bottomPanel.SendToBack(); 
    }
    private bool findSimilarImages(JoinerImage selected)
    {
        bottomListView.Items.Clear();
        bottomImageList.Images.Clear();

        ReverseComparison<float> reverser = new ReverseComparison<float>();
        SortedList<float, JoinerImage> others = new SortedList<float, JoinerImage>(reverser);

        float sim;

        int i = 0;
        foreach (JoinerImage other in _joinerImages)
        {
            sim = _defaultComparison.compare(selected.Thumbnail, other.Thumbnail);
            if (others.ContainsKey(sim))
                continue;
            others.Add(sim, other);
            other.Index = i;
            ++i;
        }


        for (i = 0; i < System.Math.Min(8, others.Count); ++i)
        {
            this.bottomImageList.Images.Add(others.Values[i].PaddedThumbnail);
            JoinerListViewItem item = new JoinerListViewItem();
            item.ImageIndex = i;
            item.JoinerImage = others.Values[i];
            this.bottomListView.Items.Add(item);
        }

        return (others.Count > 0);
    }


    #endregion //Methods

    private void btnBottomPanelClose_Click(object sender, EventArgs e)
    {
        this.hideBottomPanel(); 
    }

 
  }
}
