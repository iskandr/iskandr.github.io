﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Joiners
{
    public partial class GaussianBlurForm : Form
    {
        public int KernelSize
        {
            get { return Int32.Parse(maskedTextBoxKernelSize.Text); }
        }

        public double Sigma
        {
            get { return Double.Parse(maskedTextBoxSigma.Text); }
        }

        public GaussianBlurForm()
        {
            InitializeComponent();
        }
    }
}
