﻿using System;
using System.Windows.Forms;
using System.Drawing;
using System.Drawing.Imaging;
using System.Threading;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Linq;
using System.Text;
using System.Collections;
using Tao.Platform.Windows;
using Tao.OpenGl;

using Joiners.Engine;
using Joiners.Graphic;
using Joiners.Math;

namespace Joiners
{
  class PanelMain : System.Windows.Forms.Panel
  {
    #region Members

    private SimpleOpenGlControl glControl;
    private Thread _mainThread;
    private JoinerSelection _selectedItems = new JoinerSelection();
    private JoinerImage _rightClickSelection = null;
    //private Vector3D _lastMousePos = new Vector3D();
    private Point    _last2DMousePos = new Point();

      //   private Vector3D _currentMousePos = new Vector3D();
    
    #region Transformations

    private enum Tool { MOVE, ROTATE, SCALE, SELECT, NONE };
    private Tool _activeTool = Tool.NONE;

    #endregion //Transformations
    
    private ToolStripMenuItem moveStripMenuItem;
    private ToolStripMenuItem rotateStripMenuItem;
    private ContextMenuStrip contextMenuStrip1;
    private ToolStripMenuItem groupStripMenuItem;
    private ToolStripSeparator toolStripSeparator1;
    private ToolStripMenuItem findSimilarMenuItem;
    private ToolStripSeparator toolStripSeparator2;
    private ToolStripMenuItem degroupStripMenuItem;
    private ToolStripMenuItem scaleStripMenuItem;
    private ToolStripSeparator toolStripSeparator3;
    private ToolStripMenuItem deleteStripMenuItem;
    private ToolStripMenuItem editStripMenuItem;

    private System.ComponentModel.IContainer components;

    #endregion //Members


    #region Properties

    public SimpleOpenGlControl OpenGlControl
    {
      get { return glControl; }
    }

    public JoinersEngine JoinersEngine
    {
      get { return JoinersEngine.Instance; }
    }

    public Thread MainThread
    {
        get { return _mainThread; }
    }

      /*
    public List<JoinerImage> UnseenImages
    {
        get { return unseenImages; }
    }
      */
    #endregion //Properties

    #region Constructor - Dispose

    public PanelMain()
    {
      InitializeComponent();
      glControl.InitializeContexts();
      JoinersEngine.Initialize(glControl.Width, glControl.Height);
      _mainThread = new Thread(new ThreadStart(MainThreadCallback));
      _mainThread.Start();  
    }

    protected override void Dispose(bool disposing)
    {
      JoinersEngine.Quit();
      if (disposing)
      {
        if (components != null)
        {
          glControl.DestroyContexts();
          components.Dispose();
        }
      }
      base.Dispose(disposing);
    }

    #endregion //Constructor - Dispose

    #region InitializeComponent

    private void InitializeComponent()
    {
        this.components = new System.ComponentModel.Container();
        this.glControl = new Tao.Platform.Windows.SimpleOpenGlControl();
        this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
        this.moveStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.rotateStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.scaleStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
        this.groupStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.degroupStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.editStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.deleteStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
        this.findSimilarMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
        this.contextMenuStrip1.SuspendLayout();
        this.SuspendLayout();
        // 
        // glControl
        // 
        this.glControl.AccumBits = ((byte)(0));
        this.glControl.AllowDrop = true;
        this.glControl.AutoCheckErrors = false;
        this.glControl.AutoFinish = false;
        this.glControl.AutoMakeCurrent = true;
        this.glControl.AutoSwapBuffers = true;
        this.glControl.BackColor = System.Drawing.Color.White;
        this.glControl.ColorBits = ((byte)(32));
        this.glControl.ContextMenuStrip = this.contextMenuStrip1;
        this.glControl.Cursor = System.Windows.Forms.Cursors.Default;
        this.glControl.DepthBits = ((byte)(32));
        this.glControl.Dock = System.Windows.Forms.DockStyle.Fill;
        this.glControl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        this.glControl.Location = new System.Drawing.Point(0, 0);
        this.glControl.Name = "glControl";
        this.glControl.Size = new System.Drawing.Size(200, 100);
        this.glControl.StencilBits = ((byte)(0));
        this.glControl.TabIndex = 0;
        this.glControl.MouseWheel += new System.Windows.Forms.MouseEventHandler(this.glControl_MouseWheel);
        this.glControl.Paint += new System.Windows.Forms.PaintEventHandler(this.OnGlPaint);
        this.glControl.PreviewKeyDown += new System.Windows.Forms.PreviewKeyDownEventHandler(this.glControl_PreviewKeyDown);
        this.glControl.MouseMove += new System.Windows.Forms.MouseEventHandler(this.glControl_MouseMove);
        this.glControl.DragDrop += new System.Windows.Forms.DragEventHandler(this.glControl_DragDrop);
        this.glControl.MouseClick += new System.Windows.Forms.MouseEventHandler(this.glControl_MouseClick);
        this.glControl.MouseDown += new System.Windows.Forms.MouseEventHandler(this.glControl_MouseDown);
        this.glControl.MouseUp += new System.Windows.Forms.MouseEventHandler(this.glControl_MouseUp);
        this.glControl.DragEnter += new System.Windows.Forms.DragEventHandler(this.glControl_DragEnter);
        this.glControl.SizeChanged += new System.EventHandler(this.glControl_SizeChanged);
        // 
        // contextMenuStrip1
        // 
        this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.moveStripMenuItem,
            this.rotateStripMenuItem,
            this.scaleStripMenuItem,
            this.toolStripSeparator1,
            this.groupStripMenuItem,
            this.degroupStripMenuItem,
            this.editStripMenuItem,
            this.deleteStripMenuItem,
            this.toolStripSeparator2,
            this.findSimilarMenuItem});
        this.contextMenuStrip1.Name = "contextMenuStrip";
        this.contextMenuStrip1.Size = new System.Drawing.Size(177, 170);
        // 
        // moveStripMenuItem
        // 
        this.moveStripMenuItem.ForeColor = System.Drawing.SystemColors.WindowText;
        this.moveStripMenuItem.Name = "moveStripMenuItem";
        this.moveStripMenuItem.Size = new System.Drawing.Size(176, 22);
        this.moveStripMenuItem.Text = "Move";
        this.moveStripMenuItem.Click += new System.EventHandler(this.moveStripMenuItem_Click);
        // 
        // rotateStripMenuItem
        // 
        this.rotateStripMenuItem.ForeColor = System.Drawing.SystemColors.WindowText;
        this.rotateStripMenuItem.Name = "rotateStripMenuItem";
        this.rotateStripMenuItem.Size = new System.Drawing.Size(176, 22);
        this.rotateStripMenuItem.Text = "Rotate";
        this.rotateStripMenuItem.Click += new System.EventHandler(this.rotateStripMenuItem_Click);
        // 
        // scaleStripMenuItem
        // 
        this.scaleStripMenuItem.ForeColor = System.Drawing.SystemColors.WindowText;
        this.scaleStripMenuItem.Name = "scaleStripMenuItem";
        this.scaleStripMenuItem.Size = new System.Drawing.Size(176, 22);
        this.scaleStripMenuItem.Text = "Scale";
        this.scaleStripMenuItem.Click += new System.EventHandler(this.scaleStripMenuItem_Click);
        // 
        // toolStripSeparator1
        // 
        this.toolStripSeparator1.Name = "toolStripSeparator1";
        this.toolStripSeparator1.Size = new System.Drawing.Size(173, 6);
        // 
        // groupStripMenuItem
        // 
        this.groupStripMenuItem.ForeColor = System.Drawing.SystemColors.WindowText;
        this.groupStripMenuItem.Name = "groupStripMenuItem";
        this.groupStripMenuItem.Size = new System.Drawing.Size(176, 22);
        this.groupStripMenuItem.Text = "Group";
        this.groupStripMenuItem.Click += new System.EventHandler(this.groupStripMenuItem_Click);
        // 
        // degroupStripMenuItem
        // 
        this.degroupStripMenuItem.ForeColor = System.Drawing.SystemColors.WindowText;
        this.degroupStripMenuItem.Name = "degroupStripMenuItem";
        this.degroupStripMenuItem.Size = new System.Drawing.Size(176, 22);
        this.degroupStripMenuItem.Text = "Degroup";
        this.degroupStripMenuItem.Click += new System.EventHandler(this.degroupStripMenuItem_Click);
        // 
        // editStripMenuItem
        // 
        this.editStripMenuItem.ForeColor = System.Drawing.SystemColors.WindowText;
        this.editStripMenuItem.Name = "editStripMenuItem";
        this.editStripMenuItem.Size = new System.Drawing.Size(176, 22);
        this.editStripMenuItem.Text = "Edit";
        this.editStripMenuItem.Click += new System.EventHandler(this.editStripMenuItem_Click);
        // 
        // deleteStripMenuItem
        // 
        this.deleteStripMenuItem.ForeColor = System.Drawing.SystemColors.WindowText;
        this.deleteStripMenuItem.Name = "deleteStripMenuItem";
        this.deleteStripMenuItem.Size = new System.Drawing.Size(176, 22);
        this.deleteStripMenuItem.Text = "Delete";
        this.deleteStripMenuItem.Click += new System.EventHandler(this.deleteStripMenuItem_Click);
        // 
        // toolStripSeparator2
        // 
        this.toolStripSeparator2.Name = "toolStripSeparator2";
        this.toolStripSeparator2.Size = new System.Drawing.Size(173, 6);
        // 
        // findSimilarMenuItem
        // 
        this.findSimilarMenuItem.ForeColor = System.Drawing.SystemColors.WindowText;
        this.findSimilarMenuItem.Name = "findSimilarMenuItem";
        this.findSimilarMenuItem.Size = new System.Drawing.Size(176, 22);
        this.findSimilarMenuItem.Text = "Find Similar Images";
        this.findSimilarMenuItem.Click += new System.EventHandler(this.findSimilarStripMenuItem_Click);
        // 
        // toolStripSeparator3
        // 
        this.toolStripSeparator3.Name = "toolStripSeparator3";
        this.toolStripSeparator3.Size = new System.Drawing.Size(123, 6);
        // 
        // PanelMain
        // 
        this.Controls.Add(this.glControl);
        this.contextMenuStrip1.ResumeLayout(false);
        this.ResumeLayout(false);

    }

    #endregion //InitializeComponent

    #region Methods

    
    private void MainThreadCallback()
    {
      while (JoinersEngine.Instance.End == false)
      {
          glControl.Invalidate();
          Thread.Sleep(10);
      }
    }
     
    private Vector3D ConvertCoordsToScene(float x, float y, float z)
    {
      Vector3D scenePos = GraphicEngine.Instance.UnProject(new Vector3D(x, y, z));
      float height = GraphicEngine.Instance.GetPlaneHeight(GraphicEngine.Instance.Scene.CurrentCamera.GetPosition().z - z);
      float width = GraphicEngine.Instance.GetPlaneWidth(GraphicEngine.Instance.Scene.CurrentCamera.GetPosition().z - z);
      Vector3D result = new Vector3D(GraphicEngine.Instance.Scene.CurrentCamera.GetPosition().x + width * scenePos.x,
         GraphicEngine.Instance.Scene.CurrentCamera.GetPosition().y + height * -scenePos.y,
         0.0f);
      return result;
    }

    private void SelectGroup(JoinerImage image)
    {
      /* Clear previous selection if Shift key is not pressed */
      if ((Control.ModifierKeys & Keys.Shift) != Keys.Shift)
        _selectedItems.ClearSelection();
      /* Add the images in the group to the selection */
      foreach (JoinerImage current in image.Group.Items)
      {
          if (current.Selected == JoinerImage.Selection.NONE)
          {
              _selectedItems.Add(current);
              current.Selected = JoinerImage.Selection.GROUP_SELECT;
          }
          else
          {
              _selectedItems.Remove(current);
              current.Selected = JoinerImage.Selection.NONE;
          }
      }
    }

    private void StartMoveTool()
    {
      _activeTool = Tool.MOVE;
      Point controlCoords = glControl.PointToClient(new Point(Control.MousePosition.X, Control.MousePosition.Y));
      SetLastMousePos(controlCoords.X, controlCoords.Y);
    }

    private void StartRotateTool()
    {
      _activeTool = Tool.ROTATE;
      Vector3D center = _selectedItems.GetCenter();
      Console.WriteLine(center.ToString());
      _last2DMousePos = glControl.PointToClient(new Point(Control.MousePosition.X, Control.MousePosition.Y));
    }

    private void DoMoveZ(Point e)
    {
        Vector3D sceneCoords = new Vector3D();
      if (_selectedItems.SoloSelection == null)
          foreach (JoinerImage current in _selectedItems)
          {
              sceneCoords.Set(ConvertCoordsToScene(e.X, e.Y, current.GetPosition().z));
              current.SetPositionZ(current.GetPosition().z - (sceneCoords.y - current.GetLastMousePosition().y));
              current.SetLastMousePosition(sceneCoords);
          }
      else
      {
          sceneCoords.Set(ConvertCoordsToScene(e.X, e.Y, _selectedItems.SoloSelection.GetPosition().z));
          _selectedItems.SoloSelection.SetPositionZ(_selectedItems.SoloSelection.GetPosition().z - (sceneCoords.y - _selectedItems.SoloSelection.GetLastMousePosition().y));
          _selectedItems.SoloSelection.SetLastMousePosition(sceneCoords);
      }
      
    }

    private void DoMove(Point e)
    {
        Vector3D sceneCoords = new Vector3D();
        if (_selectedItems.SoloSelection == null)
         foreach (JoinerImage current in _selectedItems)
         {
              sceneCoords.Set(ConvertCoordsToScene(e.X, e.Y, current.GetPosition().z));
              current.Move(sceneCoords.x - current.GetLastMousePosition().x,
                          sceneCoords.y - current.GetLastMousePosition().y,
                          0.0f);
             current.SetLastMousePosition(sceneCoords);
         }
     else
     {
          sceneCoords.Set(ConvertCoordsToScene(e.X, e.Y, _selectedItems.SoloSelection.GetPosition().z));
          _selectedItems.SoloSelection.Move(sceneCoords.x - _selectedItems.SoloSelection.GetLastMousePosition().x,
                                           sceneCoords.y - _selectedItems.SoloSelection.GetLastMousePosition().y,
                                           0.0f);
         _selectedItems.SoloSelection.SetLastMousePosition(sceneCoords);
     }
    }


    private void DoOffsetMove(float x, float y)
    {
        if (_selectedItems.SoloSelection == null)
            foreach (JoinerImage current in _selectedItems)
            {
                current.Move(x, y, 0.0f);
                current.SetLastMousePosition(current.GetLastMousePosition().x + x, current.GetLastMousePosition().y + y, current.GetLastMousePosition().z);
            }
        else
        {
            _selectedItems.SoloSelection.Move(x, y, 0.0f);
            _selectedItems.SoloSelection.GetLastMousePosition().Set(_selectedItems.SoloSelection.GetLastMousePosition().x + x,
                _selectedItems.SoloSelection.GetLastMousePosition().y + y, _selectedItems.SoloSelection.GetLastMousePosition().z);
        }
    }

    private void DoRotate(Point e)
    {
        if (_selectedItems.SoloSelection == null)
            foreach (JoinerImage current in _selectedItems)
                current.RotateZ(_last2DMousePos.Y - e.Y);
        else
            _selectedItems.SoloSelection.RotateZ(_last2DMousePos.Y - e.Y);
      _last2DMousePos.X = e.X;
      _last2DMousePos.Y = e.Y;
    }

    private void DoScale(Point e)
    {
      if (_selectedItems.SoloSelection == null)
        foreach (JoinerImage current in _selectedItems)
          current.Scale(1.0f + (float)(_last2DMousePos.Y - e.Y) / 50.0f, 1.0f + (float)(_last2DMousePos.Y - e.Y) / 50.0f, 1.0f);
      else
        _selectedItems.SoloSelection.Scale(1.0f + (float)(_last2DMousePos.Y - e.Y) / 50.0f, 1.0f + (float)(_last2DMousePos.Y - e.Y) / 50.0f, 1.0f);
      _last2DMousePos.X = e.X;
      _last2DMousePos.Y = e.Y;
    }

    private void DoSelect()
    {
      using (Graphics g = Graphics.FromHwnd(glControl.Handle))
      {
        Pen pen = new Pen(System.Drawing.Color.Green);
        Point newPoint = glControl.PointToClient(Control.MousePosition);
        g.DrawRectangle(pen,_last2DMousePos.X, _last2DMousePos.Y, newPoint.X - _last2DMousePos.X, newPoint.Y - _last2DMousePos.Y);
      }
    }

    private void MoveCamera(float z)
    {
      GraphicEngine.Instance.Scene.CurrentCamera.TranslateSmooth(0.0f, z, 0.0f);
      Vector3D camPos = GraphicEngine.Instance.Scene.CurrentCamera.GetPosition();
      if (camPos.z < 0.0)
      {
          camPos.z = 0.0f;
          GraphicEngine.Instance.Scene.CurrentCamera.SetPosition(camPos);
      }
    }

    #endregion //Methods

    # region Events

    public delegate void FindSimilarHandler(object source, JoinerImage original);

    public event FindSimilarHandler findSimilar; 

    #endregion 

    #region Event Handlers
    private void OnGlPaint(object sender, System.Windows.Forms.PaintEventArgs e)
    {
      JoinersEngine.MainLoop();
    }

    private void glControl_SizeChanged(object sender, EventArgs e)
    {
      if (Size.Height == 0)
        return;
      GraphicEngine.Instance.ResizeWindow(glControl.Size.Width, glControl.Size.Height);
      
    }

    private void glControl_DragEnter(object sender, DragEventArgs e)
    {
      if (e.Data.GetDataPresent(typeof(JoinerImage)))
        e.Effect = DragDropEffects.Move;
      else
        e.Effect = DragDropEffects.None;

      Point dropPoint = glControl.PointToClient(new Point(e.X, e.Y));
    }

    private void glControl_DragDrop(object sender, DragEventArgs e)
    {
      JoinerImage newImage = null;
      if (e.Data.GetDataPresent(typeof(JoinerImage)))
        newImage = (JoinerImage)e.Data.GetData(typeof(JoinerImage));
      if (newImage == null)
        return;

      Console.WriteLine("e.X : " + e.X + " e.Y : " + e.Y);
      Point dropPoint = glControl.PointToClient(new Point(e.X,e.Y));
      Console.WriteLine("dropPoint.X : " + dropPoint.X + " dropPoint.Y : " + dropPoint.Y);
      newImage.SetPosition(ConvertCoordsToScene(dropPoint.X, dropPoint.Y, 0.0f));
      newImage.ExtentsCompute();
      Vector3D pos = newImage.GetPosition();
      Console.WriteLine("Image dropped at : X: " + pos.x + " Y: " + pos.y + " Z: " + pos.z);
      //image.UpdateScreenBoundingBox();
      //UnseenImages.Remove(newImage); 
      GraphicEngine.Instance.Scene.EntitiesAdd(newImage);
    }

    private void glControl_MouseWheel(object sender, MouseEventArgs e)
    {
      if (_activeTool != Tool.MOVE)
        MoveCamera((e.Delta / 120) * 0.1f);
      if (_activeTool == Tool.MOVE)
      {
        foreach (JoinerImage current in _selectedItems)
          current.SetPositionZ(current.GetPosition().z - (e.Delta / 120.0f) * 0.1f);
      }
      Console.WriteLine(_activeTool == Tool.MOVE); 
    }

    private void glControl_PreviewKeyDown(object sender, PreviewKeyDownEventArgs e) 
    {
        if ((Control.ModifierKeys & Keys.Control) == Keys.Control)
            return;
        if (e.KeyCode == Keys.A)
            GraphicEngine.Instance.Scene.CurrentCamera.TranslateSmooth(-0.1f, 0.0f, 0.0f);
      if (e.KeyCode == Keys.D)
        GraphicEngine.Instance.Scene.CurrentCamera.TranslateSmooth(0.1f, 0.0f, 0.0f);
      if (e.KeyCode == Keys.W)
      {
          if ((Control.ModifierKeys & Keys.Shift) == Keys.Shift)
            MoveCamera(0.1f);
          else
              GraphicEngine.Instance.Scene.CurrentCamera.TranslateSmooth(0.0f, 0.0f, 0.1f);
      }
      if (e.KeyCode == Keys.S)
      {
          if ((Control.ModifierKeys & Keys.Shift) == Keys.Shift)
              MoveCamera(-0.1f);
          else
              GraphicEngine.Instance.Scene.CurrentCamera.TranslateSmooth(0.0f, 0.0f, -0.1f);
      }
      if (_activeTool != Tool.SELECT && _activeTool != Tool.NONE)
        if (e.KeyCode == Keys.D1 || e.KeyCode == Keys.D2 || e.KeyCode == Keys.D3)
        {
          _activeTool = Tool.SELECT;
          return;
        }
      if (e.KeyCode ==Keys.D1)
          StartMoveTool();
      if (e.KeyCode == Keys.D2)
      {
        _activeTool = Tool.ROTATE;
        _last2DMousePos = glControl.PointToClient(new Point(Control.MousePosition.X, Control.MousePosition.Y));
      }
      if (e.KeyCode == Keys.D3)
      {
        _activeTool = Tool.SCALE;
        _last2DMousePos = glControl.PointToClient(new Point(Control.MousePosition.X, Control.MousePosition.Y));
      }

          switch (e.KeyCode)
          {
              case (Keys.Left):
                  if ((Control.ModifierKeys & Keys.Shift) == Keys.Shift)
                    DoOffsetMove(-0.10f, 0.0f);
                  else
                    DoOffsetMove(-0.01f, 0.0f);
                  break;
              case (Keys.Right):
                  if ((Control.ModifierKeys & Keys.Shift) == Keys.Shift)
                    DoOffsetMove(0.10f, 0.0f);
                  else
                    DoOffsetMove(0.01f, 0.0f);
                  break;
              case (Keys.Up):
                  if ((Control.ModifierKeys & Keys.Shift) == Keys.Shift)
                    DoOffsetMove(0.0f, 0.1f);
                  else
                    DoOffsetMove(0.0f, 0.01f);
                  break;
              case (Keys.Down):
                  if ((Control.ModifierKeys & Keys.Shift) == Keys.Shift)
                    DoOffsetMove(0.0f, -0.10f);
                  else
                    DoOffsetMove(0.0f, -0.01f);
                  break;
          }
      
    }

    private void glControl_MouseClick(object sender, MouseEventArgs e)
    {
    }

    private void glControl_MouseMove(object sender, MouseEventArgs e)
    {
      if (e.Button == MouseButtons.Left)
        _activeTool = Tool.MOVE;
      if (_activeTool == Tool.MOVE)
      {
        if ((Control.ModifierKeys & Keys.Control) == Keys.Control)
          DoMoveZ(e.Location);
        else
          DoMove(e.Location);
      }
      else if (_activeTool == Tool.ROTATE)
      {
        if ((Control.ModifierKeys & Keys.Control) == Keys.Control)
          return; // Do relative center rotation here
        DoRotate(e.Location);
      }
      else if (_activeTool == Tool.SCALE)
        DoScale(e.Location);
      //_activeTool = Tool.NONE;
    }

    private void moveStripMenuItem_Click(object sender, EventArgs e)
    {
      StartMoveTool();
    }

    private void rotateStripMenuItem_Click(object sender, EventArgs e)
    {
      StartRotateTool();
    }

    private void scaleStripMenuItem_Click(object sender, EventArgs e)
    {
      _activeTool = Tool.SCALE;
      _last2DMousePos = glControl.PointToClient(new Point(Control.MousePosition.X, Control.MousePosition.Y));
    }

    private void groupStripMenuItem_Click(object sender, EventArgs e)
    {
      JoinerGroup group = new JoinerGroup();

      foreach (JoinerImage current in _selectedItems)
      {
        current.Group = group;
        group.Add(current);
      }
    }

    private void degroupStripMenuItem_Click(object sender, EventArgs e)
    {
      foreach (JoinerImage current in _selectedItems)
        current.Group = null;
    }

    private void SetLastMousePos(int x, int y)
    {
        foreach (JoinerImage current in _selectedItems)
            current.SetLastMousePosition(ConvertCoordsToScene(x, y, current.GetPosition().z));
    }

    private JoinerImage DoRightClick(MouseEventArgs e)
    {
        _rightClickSelection = null;
        foreach (JoinerImage current in GraphicEngine.Instance.Scene.Entities)
        {
            Vector3D result = ConvertCoordsToScene(e.X, e.Y, current.GetPosition().z);
            if (current.IsPointHovering(result))
            {
                Console.WriteLine("Z obj : " + current.GetPosition().z + " Cam Z : " + GraphicEngine.Instance.Scene.CurrentCamera.GetPosition().z);
                if (current.GetPosition().z + 1.0 >= GraphicEngine.Instance.Scene.CurrentCamera.GetPosition().z)
                    continue;
                if (_rightClickSelection == null)
                    _rightClickSelection = current;
                else
                    if (current.GetPosition().z >= _rightClickSelection.GetPosition().z)
                        _rightClickSelection = current;
                editStripMenuItem.Enabled = true;
            }
        }
        if (_rightClickSelection == null)
            editStripMenuItem.Enabled = false;
        return _rightClickSelection;
    }

    private JoinerImage DoLeftClick(MouseEventArgs e)
    {
        JoinerImage _leftClickSelection = null;
        foreach (JoinerImage current in GraphicEngine.Instance.Scene.Entities)
        {
            Vector3D result = ConvertCoordsToScene(e.X, e.Y, current.GetPosition().z);
            if (current.IsPointHovering(result))
            {
                Console.WriteLine("Z obj : " + current.GetPosition().z + " Cam Z : " + GraphicEngine.Instance.Scene.CurrentCamera.GetPosition().z);
                if (current.GetPosition().z + 1.0 >= GraphicEngine.Instance.Scene.CurrentCamera.GetPosition().z)
                    continue;
                if (_leftClickSelection == null)
                    _leftClickSelection = current;
                else if (current.GetPosition().z >= _leftClickSelection.GetPosition().z)
                    _leftClickSelection = current;
            }
        }
        return _leftClickSelection;
    }

    private void DoSelection(JoinerImage selectedImg)
    {
        /* No image clicked : Clear everything if in Selection Mode*/
        if (selectedImg == null && _activeTool == Tool.SELECT)
        {
            if ((Control.ModifierKeys & Keys.Shift) != Keys.Shift)
                _selectedItems.ClearSelection();
            return;
        }

        if (selectedImg.Group != null) /* The selected image belongs to a group */
        {
            if ((Control.ModifierKeys & Keys.Control) == Keys.Control)
            {
                if (selectedImg.Selected == JoinerImage.Selection.GROUP_SELECT)
                    _selectedItems.SetSoloSelection(selectedImg);
                else if (selectedImg.Selected == JoinerImage.Selection.SOLO_SELECT)
                    _selectedItems.SetSoloSelection(null);
                else
                    SelectGroup(selectedImg);
            }
            else if (selectedImg != _selectedItems.SoloSelection || _selectedItems.SoloSelection == null)
                SelectGroup(selectedImg);
        }
        else /* No Group */
        { /* Deselect image if already selected */
            if (selectedImg.Selected != JoinerImage.Selection.NONE)
            {
                if ((Control.ModifierKeys & Keys.Shift) == Keys.Shift)
                {
                    _selectedItems.Remove(selectedImg);
                    if (_selectedItems.SoloSelection == selectedImg)
                        _selectedItems.SetSoloSelection(null);
                    selectedImg.Selected = JoinerImage.Selection.NONE;
                }
                else /* No Shift Key pressed deselect all previously selected */
                {
                    _selectedItems.ClearSelection();
                    _selectedItems.Add(selectedImg);
                    selectedImg.Selected = JoinerImage.Selection.GROUP_SELECT;
                }
            }
            else /* Select one image */
            {
                /* Shift key pressed add to selection */
                if ((Control.ModifierKeys & Keys.Shift) == Keys.Shift)
                {
                    _selectedItems.Add(selectedImg);
                    selectedImg.Selected = JoinerImage.Selection.GROUP_SELECT;
                }
                else /* No Shift Key pressed deselect all previously selected */
                {
                    _selectedItems.ClearSelection();
                    _selectedItems.Add(selectedImg);
                    selectedImg.Selected = JoinerImage.Selection.GROUP_SELECT;
                }
            }
        }     
    }

    private void glControl_MouseDown(object sender, MouseEventArgs e)
    {
        if (_activeTool != Tool.NONE)
        {
            _activeTool = Tool.SELECT;
            return;
        }
        _activeTool = Tool.SELECT;

      if (e.Button == MouseButtons.Right)
          DoRightClick(e);

      if (e.Button != MouseButtons.Left)
        return;

      JoinerImage _leftClickSelection = DoLeftClick(e);
      DoSelection(_leftClickSelection);
      SetLastMousePos(e.X, e.Y);
    }

    private void glControl_MouseUp(object sender, MouseEventArgs e)
    {
      _activeTool = Tool.NONE;
    }

    private void editStripMenuItem_Click(object sender, EventArgs e)
    {
      ImageViewer view = new ImageViewer(_rightClickSelection);
      view.LoadImage();
      view.ShowDialog();
      view.Focus();
      _rightClickSelection.Image = view.Result;
    }

    private void deleteStripMenuItem_Click(object sender, EventArgs e)
    {
      foreach (JoinerImage current in _selectedItems)
      {
        GraphicEngine.Instance.Scene.Entities.Remove(current);
        int[] textures = new int[1];
        textures[0] = current.TextureID;
        Gl.glDeleteTextures(1, textures);
      }
      _selectedItems.ClearSelection();
    }

    private void findSimilarStripMenuItem_Click(object sender,  EventArgs e)
    {
        if (_rightClickSelection != null)
            findSimilar(this, _rightClickSelection); 
    }
    #endregion //Events
  }
}
