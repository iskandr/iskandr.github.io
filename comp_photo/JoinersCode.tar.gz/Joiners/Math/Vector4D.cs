//----------------------------------------------------------------------------
//  Project     : EdenArts.Math
//  Author      : Valerie Tching
//  Date        : 01/02/2005
//  File        : Vector4D.cs
//  Description : Vector4D class
//----------------------------------------------------------------------------
//  EdenArts.Math is a math library.
//  The project is running under QPL licence.
//    (QPL Licence specifications: http://www.trolltech.com/licenses/qpl.html)
//  Zion is part of Eden Arts Team Work
//  Members are:
//      Nadim Awad        (awad_n@epitech.net)
//      Michel Courtine   (courti_m@epitech.net)
//      Matthieu Dehaussy (dehaus_m@epitech.net)
//      Julien Ferrero    (ferrer_j@epitech.net)
//      Nicolas Goubaux   (goubau_n@epitech.net)
//      Valerie Tching    (tching_v@epitech.net)
//  You can have further information on Zion website:
//         http://zion.labtech.epitech.net
//----------------------------------------------------------------------------

using System;

namespace Joiners.Math
{
  /// <summary>
  /// Array of 4 floats.
  /// </summary>
  public class      Vector4D
  {
    public float [] Values = new float[4];

    #region Constructors

    public          Vector4D()
    {
    }

    public          Vector4D(float x, float y, float z, float w)
    {
      this.Values[0] = x;
      this.Values[1] = y;
      this.Values[2] = z;
      this.Values[3] = w;
    }

    public          Vector4D(Vector4D vector4D)
    {
      this.Values[0] = vector4D.Values[0];
      this.Values[1] = vector4D.Values[1];
      this.Values[2] = vector4D.Values[2];
      this.Values[3] = vector4D.Values[3];
    }

    #endregion Constructors

    #region Initialization && Uninitialization

    public void     Set(float x, float y, float z, float w)
    {
      this.Values[(int)AxisEnum.X] = x;
      this.Values[(int)AxisEnum.Y] = y;
      this.Values[(int)AxisEnum.Z] = z;
      this.Values[(int)AxisEnum.W] = w;
    }

    public void     Set(Vector4D vector4D)
    {
      this.Values[0] = vector4D.Values[0];
      this.Values[1] = vector4D.Values[1];
      this.Values[2] = vector4D.Values[2];
      this.Values[3] = vector4D.Values[3];
    }

    public void     Set(Vector3D vector3D)
    {
      this.Values[0] = vector3D.x;
      this.Values[1] = vector3D.y;
      this.Values[2] = vector3D.z;
    }

    public void     Set(Vector3D vector3D, float w)
    {
      this.Values[0] = vector3D.x;
      this.Values[1] = vector3D.y;
      this.Values[2] = vector3D.z;
      this.Values[3] = w;
    }

    #endregion Initialization && Uninitialization

    public override string ToString()
    {
      return "x: " + Values[(int)AxisEnum.X] + 
        " y: " + Values[(int)AxisEnum.Y] + 
        " z: " + Values[(int)AxisEnum.Z] + 
        " w: " + Values[(int)AxisEnum.W];
    }
  }
}
