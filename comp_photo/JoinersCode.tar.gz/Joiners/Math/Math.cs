//----------------------------------------------------------------------------
//  Project     : EdenArts.Math
//  Author      : Valerie Tching
//  Date        : 01/02/2005
//  File        : Math.cs
//  Description : Math class
//----------------------------------------------------------------------------
//  EdenArts.Math is a math library.
//  The project is running under QPL licence.
//    (QPL Licence specifications: http://www.trolltech.com/licenses/qpl.html)
//  Zion is part of Eden Arts Team Work
//  Members are:
//      Nadim Awad        (awad_n@epitech.net)
//      Michel Courtine   (courti_m@epitech.net)
//      Matthieu Dehaussy (dehaus_m@epitech.net)
//      Julien Ferrero    (ferrer_j@epitech.net)
//      Nicolas Goubaux   (goubau_n@epitech.net)
//      Valerie Tching    (tching_v@epitech.net)
//  You can have further information on Zion website:
//         http://zion.labtech.epitech.net
//----------------------------------------------------------------------------

using System;
using System.Collections;

namespace Joiners.Math
{

  public enum AxisEnum
  {
    X,
    Y,
    Z,
    W,
  }
  /// <summary>
  /// Global mathematic class caontaining functions 
  /// such as DegToRad() or RadToDeg() or a float Math.PI
  /// </summary>
  public sealed class Math
  {

    #region Constants

    public static readonly float PI = (float)System.Math.PI;
    public static readonly float FLOAT_PRECISION_TOLERANCE = 0.001f;
    public static readonly float PIMULT2 = 2 * PI; 
    
    #endregion Constants

    #region Constructors

    private Math()
    {
    }

    #endregion Constructors

    public static float DegToRad(float deg) { return ((deg * PI) / 180.0f); }
    public static float RadToDeg(float rad) { return ((rad * 180.0f) / PI); }

    #region Trigonometric Functions

    public static float Acos(float f) { if (IsEqual(f, 1.0f)) f = 1.0f; if (IsEqual(f, -1.0f)) f = -1.0f; return ((float)System.Math.Acos(f)); }
    public static float Asin(float f) { if (IsEqual(f, 1.0f)) f = 1.0f; if (IsEqual(f, -1.0f)) f = -1.0f; return ((float)System.Math.Asin(f)); }
    public static float Atan(float f) { if (IsEqual(f, 1.0f)) f = 1.0f; if (IsEqual(f, -1.0f)) f = -1.0f; return ((float)System.Math.Atan(f)); }
    public static float Tan(float f) { if (IsEqual(f, 1.0f)) f = 1.0f; if (IsEqual(f, -1.0f)) f = -1.0f; return ((float)System.Math.Tan(f)); }

    #endregion Trigonometric Functions

    public static bool  IsEqual(float f, float reference) { return (System.Math.Abs(reference - f) < FLOAT_PRECISION_TOLERANCE ? true : false); }
    public static bool  IsZero(float f) { return (System.Math.Abs(f - 0.0f) < FLOAT_PRECISION_TOLERANCE ? true : false); }
    public static bool  IsUnit(float f) { return (System.Math.Abs(f - 1.0f) < FLOAT_PRECISION_TOLERANCE ? true : false); }

    #region Convex Hull

    #region Convex Hull with ArrayList
    
    /// <summary>
    /// Compute the convex hull from a list of points using the Graham's Scan algorithm
    /// http://www.cs.princeton.edu/~ah/alg_anim/version1/GrahamScan.html
    /// </summary>
    /// <param name="points">List of Vector2D points</param>
    /// <returns>The list of the convex hull of the points</returns></returns>
    public static ArrayList   ComputeConvexHull(ArrayList points)
    {
      ArrayList               convexHull = new ArrayList();
      ArrayList               pointsTemp = new ArrayList();
      Vector2D                pivot = (Vector2D)points[0];
      int                     pivotIndex = 0;
      int                     i;

      // Get Pivot (Highest y point)
      i = 0;
      foreach (Vector2D v in points)
      {
        if (v.y > pivot.y)
        {
          pivot = v;
          pivotIndex = i;
        }
        i++;
      }
      // Add pivot to the list of convex hull points
      convexHull.Add(pivot);

      // Compute all angle values of the list of points from the pivot
      // and build a list of points sorted by increasing angle value
      ArrayList               angles = new ArrayList();
      i = 0;
      foreach (Vector2D v in points)
      {
        if (i != pivotIndex)
        {
          float angle = Vector2D.GetAngle(new Vector2D(1, 0), v - pivot);
          int   insertIndex = 0;
          foreach (float a in angles)
          {
            if (angle < a)
              break ;
            insertIndex++;
          }
          angles.Insert(insertIndex, angle);
          pointsTemp.Insert(insertIndex, v);
        }
        i++;
      }

      while (pointsTemp.Count > 0)
      {
        convexHull.Add(pointsTemp[0]);
        pointsTemp.RemoveAt(0);
        if (convexHull.Count >= 3)
        {
          Vector2D  v1 = (Vector2D)convexHull[convexHull.Count - 3];
          Vector2D  v2 = (Vector2D)convexHull[convexHull.Count - 2];
          Vector2D  v3 = (Vector2D)convexHull[convexHull.Count - 1];

          float orientation = GetOrientation(v1, v2, v3);
          if (orientation < 0)
          {
            pointsTemp.Insert(0, v3);
            convexHull.RemoveAt(convexHull.Count - 1);
            convexHull.RemoveAt(convexHull.Count - 1);
          }
        }
      }

      return (convexHull);
    }

    #endregion Convex Hull with ArrayList

    #region Convex Hull with Array

    public static Vector2D [] ComputeConvexHull(Vector2D [] points)
    {
      ArrayList               convexHull = new ArrayList();
      ArrayList               pointsTemp = new ArrayList();
      Vector2D                pivot = points[0];
      int                     pivotIndex = 0;
      int                     i;

      // Get Pivot (Highest y point)
      i = 0;
      foreach (Vector2D v in points)
      {
        if (v.y > pivot.y)
        {
          pivot = v;
          pivotIndex = i;
        }
        i++;
      }
      // Add pivot to the list of convex hull points
      convexHull.Add(pivot);

      // Compute all angle values of the list of points from the pivot
      // and build a list of points sorted by increasing angle value
      ArrayList               angles = new ArrayList();
      i = 0;
      foreach (Vector2D v in points)
      {
        if (i != pivotIndex)
        {
          float angle = Vector2D.GetAngle(new Vector2D(1, 0), v - pivot);
          int   insertIndex = 0;
          foreach (float a in angles)
          {
            if (angle < a)
              break ;
            insertIndex++;
          }
          angles.Insert(insertIndex, angle);
          pointsTemp.Insert(insertIndex, v);
        }
        i++;
      }

      while (pointsTemp.Count > 0)
      {
        convexHull.Add(pointsTemp[0]);
        pointsTemp.RemoveAt(0);
        if (convexHull.Count >= 3)
        {
          Vector2D  v1 = (Vector2D)convexHull[convexHull.Count - 3];
          Vector2D  v2 = (Vector2D)convexHull[convexHull.Count - 2];
          Vector2D  v3 = (Vector2D)convexHull[convexHull.Count - 1];

          float orientation = GetOrientation(v1, v2, v3);
          if (orientation < 0)
          {
            pointsTemp.Insert(0, v3);
            convexHull.RemoveAt(convexHull.Count - 1);
            convexHull.RemoveAt(convexHull.Count - 1);
          }
        }
      }

      Vector2D [] convexHullVector2D = new Vector2D[convexHull.Count];
      i = 0 ;
      foreach (Vector2D v in convexHull)
        convexHullVector2D[i++] = v;

      return (convexHullVector2D);
    }

    #endregion Convex Hull with Array

    #endregion Convex Hull

    #region Orientation

    public static float   GetOrientation(Vector2D vector2D1, Vector2D vector2D2, Vector2D vector2D3)
    {
      return (vector2D2.x * vector2D3.y + vector2D1.x * vector2D2.y + vector2D1.y * vector2D3.x -
              vector2D2.x * vector2D1.y - vector2D3.x * vector2D2.y - vector2D3.y * vector2D1.x);
    }

    //D = (b1 - a1)(c2 - a2) - (b2 - a2)(c1 - a1)
    public static float   GetOrientation(Vector3D vector3D1, Vector3D vector3D2)
    {
      return ((vector3D1.y - vector3D1.x) * (vector3D2.z - vector3D2.x) - 
        (vector3D2.y - vector3D2.x) * (vector3D1.z - vector3D1.x));
    }

    #endregion Orientation

  }
}
