//----------------------------------------------------------------------------
//  Project     : EdenArts.Math
//  Author      : Valerie Tching
//  Date        : 01/02/2005
//  File        : Vector3D.cs
//  Description : Vector3D class
//----------------------------------------------------------------------------
//  EdenArts.Math is a math library.
//  The project is running under QPL licence.
//    (QPL Licence specifications: http://www.trolltech.com/licenses/qpl.html)
//  Zion is part of Eden Arts Team Work
//  Members are:
//      Nadim Awad        (awad_n@epitech.net)
//      Michel Courtine   (courti_m@epitech.net)
//      Matthieu Dehaussy (dehaus_m@epitech.net)
//      Julien Ferrero    (ferrer_j@epitech.net)
//      Nicolas Goubaux   (goubau_n@epitech.net)
//      Valerie Tching    (tching_v@epitech.net)
//  You can have further information on Zion website:
//         http://zion.labtech.epitech.net
//----------------------------------------------------------------------------

using System;

namespace Joiners.Math
{
  /// <summary>
  /// Array of 3 floats.
  /// </summary>
  public struct             Vector3D
  {

    #region Members

    public float                      x;
    public float                      y;
    public float                      z;
    public static readonly Vector3D   Empty = new Vector3D(0, 0, 0);

    #endregion Members

    #region Properties

    public float            this[int index]
    {
      get { return (index == 0 ? x : (index == 1 ? y : (index == 2 ? z : 0))); }
      set { switch (index) { case 0: x = value; break; case 1: y = value; break; case 2: z = value; break ; } }
    }

    public float            Length
    {
      get { return ((float)System.Math.Sqrt(x * x + y * y + z * z)); }
    }

    #endregion Properties

    #region Constructors

    public                  Vector3D(float x, float y, float z)
    {
      this.x = x;
      this.y = y;
      this.z = z;
    }
    
    public				          Vector3D(Vector3D vector)
		{
			this.x = vector.x;
			this.y = vector.y;
			this.z = vector.z;
		}

    #endregion Constructors

    #region Initializations && Unitializations

    public void             Set(float x, float y, float z)
    {
      this.x = x;
      this.y = y;
      this.z = z;
    }

    public void             SetX(float x)
    {
      this.x = x;
    }

    public void             SetY(float y)
    {
      this.y = y;
    }

    public void             SetZ(float z)
    {
      this.z = z;
    }
    
    public void             Set(Vector3D vector3D)
    {
      this.x = vector3D.x;
      this.y = vector3D.y;
      this.z = vector3D.z;
    }

    #endregion Initializations && Unitializations

    #region Operator Overloads

    #region Equality

    public static bool      operator == (Vector3D vector3D1, Vector3D vector3D2)
    {
      return (vector3D1.x == vector3D2.x && vector3D1.y == vector3D2.y && vector3D1.z == vector3D2.z);
    }
      
    public static bool      operator != (Vector3D vector3D1, Vector3D vector3D2)
    {
      return (vector3D1.x != vector3D2.x || vector3D1.y != vector3D2.y || vector3D1.z != vector3D2.z);
    }

    #endregion Equality

    #region Addition

    public void             Add(float x, float y, float z)
    {
      this.x += x;
      this.y += y;
      this.z += z;
    }

    public void             Add(Vector3D vector3D)
    {
      this.x += vector3D.x;
      this.y += vector3D.y;
      this.z += vector3D.z;
    }

    public static Vector3D  operator + (Vector3D v1, Vector3D v2)
    {
      return new Vector3D(v1.x + v2.x, v1.y + v2.y, v1.z + v2.z);
    }

    #endregion Addition

    #region Substraction

    public void             Substract(Vector3D vector3D)
    {
      this.x -= vector3D.x;
      this.y -= vector3D.y;
      this.z -= vector3D.z;
    }

    public static Vector3D  operator - (Vector3D v1, Vector3D v2)
    {
      return new Vector3D(v1.x - v2.x, v1.y - v2.y, v1.z - v2.z);
    }

    #endregion Substraction

    #region Scalar Multiplication

    public void             Multiply(float scalar)
    {
      this.x *= scalar;
      this.y *= scalar;
      this.z *= scalar;
    }

    public static Vector3D  operator * (Vector3D vector, float scalar)
    {
      return new Vector3D(vector.x * scalar, vector.y * scalar, vector.z * scalar);
    }

    #endregion Scalar Multiplication

    #region Multiplication

    public void             Multiply(Vector3D v)
    {
      this.x *= v.x;
      this.y *= v.y;
      this.z *= v.z;
    }

    public static Vector3D  operator * (Vector3D vector, Vector3D v)
    {
      return new Vector3D(vector.x * v.x, vector.y * v.y, vector.z * v.z);
    }

    #endregion Multiplication

    #region Scalar Division

    public void             Divide(float scalar)
    {
      if (scalar != 0.0f)
      {
        this.x /= scalar;
        this.y /= scalar;
        this.z /= scalar;
      }
    }

    public static Vector3D  operator / (Vector3D vector, float scalar)
    {
      Vector3D              v = new Vector3D(vector);
      v.Divide(scalar);
      return v;
    }

    #endregion Scalar Division

    #region Division

    public void             Divide(Vector3D v)
    {
      if (v.x != 0.0f)
        this.x /= v.x;
      if (v.y != 0.0f)
        this.y /= v.y;
      if (v.z != 0.0f)
        this.z /= v.z;
    }

    public static Vector3D  operator / (Vector3D vector, Vector3D v)
    {
      Vector3D              newV = new Vector3D(vector);
      newV.Divide(v);
      return newV;
    }

    #endregion Division

    #region Negation

    public void             Negate()
    {
      this.x = -this.x;
      this.y = -this.y;
      this.z = -this.z;
    }

    public static Vector3D  operator - (Vector3D vector3D)
    {
      return (new Vector3D(-vector3D.x, -vector3D.y, -vector3D.z));
    }

    #endregion Negation

    #region Matrix Multiplication

    /// <summary>
    /// multiply a vector by a matrix
    /// </summary>
    static public Vector3D	operator * (Vector3D v, Matrix4D m)
    {
      float [] values = m.Values;
      return new Vector3D(values[0] * v.x + values[1] * v.y + values[2] * v.z + values[3],
        values[4] * v.x + values[5] * v.y + values[6] * v.z + values[7],
        values[8] * v.x + values[9] * v.y + values[10] * v.z + values[11]);
    }	

    /// <summary>
    /// multiply a vector by a matrix
    /// </summary>
    static public Vector3D	operator * (Matrix4D m, Vector3D v)
    {
      float [] values = m.Values;
      return new Vector3D(values[0] * v.x + values[1] * v.y + values[2] * v.z + values[3],
                          values[4] * v.x + values[5] * v.y + values[6] * v.z + values[7],
                          values[8] * v.x + values[9] * v.y + values[10] * v.z + values[11]);
    }	

    #endregion Matrix Multiplication

    #endregion Operator Overloads

    public float            MaxCoordValue()
    {
      if (System.Math.Abs(x) > System.Math.Abs(y) &&
          System.Math.Abs(x) > System.Math.Abs(z))
        return (x);
      if (System.Math.Abs(y) > System.Math.Abs(x) &&
          System.Math.Abs(y) > System.Math.Abs(z))
        return (y);
      if (System.Math.Abs(z) > System.Math.Abs(x) &&
          System.Math.Abs(z) > System.Math.Abs(y))
        return (z);
      return (0);
    }

    /// <summary>
    /// Cross Product
    /// </summary>
    /// <param name="vector"></param>
    public static Vector3D  Inner(Vector3D vector3D1, Vector3D vector3D2)
    {
      Vector3D              inner = new Vector3D();

      inner.x = (vector3D1.y * vector3D2.z) - (vector3D1.z * vector3D2.y);
      inner.y = (vector3D1.z * vector3D2.x) - (vector3D1.x * vector3D2.z);
      inner.z = (vector3D1.x * vector3D2.y) - (vector3D1.y * vector3D2.x);
      return inner;
    }

    public void		          Inner(Vector3D vector)
    {
      float newX, newY, newZ;

      newX = (float)((double)this.y * (double)vector.z - (double)this.z * (double)vector.y);
      newY = (float)((double)this.z * (double)vector.x - (double)this.x * (double)vector.z);
      newZ = (float)((double)this.x * (double)vector.y - (double)this.y * (double)vector.x);
      this.x = newX;
      this.y = newY;
      this.z = newZ;
    }

    public static float     Outer(Vector3D vector3D1, Vector3D vector3D2)
    {
      return (vector3D1.x * vector3D2.x + vector3D1.y * vector3D2.y + vector3D1.z * vector3D2.z);
    }

    public float            Outer(Vector3D vector3D)
    {
      return (this.x * vector3D.x + this.y * vector3D.y + this.z * vector3D.z);
    }

    public float   GetAngle(Vector3D vector3D1, Vector3D vector3D2)
    {
      float               angle = (float)System.Math.Acos(Outer(vector3D1, vector3D2) / (vector3D1.Length * vector3D2.Length));
      if (Math.GetOrientation(vector3D1, vector3D2) > 0)
        angle = 2 * Math.PI - angle;
      return (angle);
    }

    public void		          Normalize() 
    {
      float                 length = this.Length;
      if (length == 0.0f)
        return;
      float inv = 1 / length;
      this.x *= inv;
      this.y *= inv;
      this.z *= inv;
    }

	  public static bool AllLessOrEqual(Vector3D a, Vector3D b) 
	  {
		  return a.x <= b.x && a.y <= b.y && a.z <= b.z;
	  }

	  public static bool OneLess(Vector3D a, Vector3D b) 
	  {
		  return a.x < b.x || a.y < b.y || a.z < b.z;
	  }

    #region Object Overloads

    public override int     GetHashCode() 
    { 
      return x.GetHashCode() ^ (y.GetHashCode() ^ (~z.GetHashCode())); 
    } 

    public override bool    Equals(object obj) 
    {
      if (obj is Vector3D)
        return (this == (Vector3D)obj);
      return false;
    }

    public override string  ToString()
    {
      return ("x: " + x + " y: " + y + " z: " + z);
    }

    public string  ToString(string separator)
    {
      return (x + separator + y + separator + z);
    }

    #endregion Object Overloads

  }
}
