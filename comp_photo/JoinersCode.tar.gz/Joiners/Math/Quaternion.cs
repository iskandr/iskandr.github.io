//----------------------------------------------------------------------------
//  Project     : EdenArts.Math
//  Author      : Valerie Tching
//  Date        : 01/02/2005
//  File        : Quaternion.cs
//  Description : Quaternion class
//----------------------------------------------------------------------------
//  EdenArts.Math is a math library.
//  The project is running under QPL licence.
//    (QPL Licence specifications: http://www.trolltech.com/licenses/qpl.html)
//  Zion is part of Eden Arts Team Work
//  Members are:
//      Nadim Awad        (awad_n@epitech.net)
//      Michel Courtine   (courti_m@epitech.net)
//      Matthieu Dehaussy (dehaus_m@epitech.net)
//      Julien Ferrero    (ferrer_j@epitech.net)
//      Nicolas Goubaux   (goubau_n@epitech.net)
//      Valerie Tching    (tching_v@epitech.net)
//  You can have further information on Zion website:
//         http://zion.labtech.epitech.net
//----------------------------------------------------------------------------

using System;

namespace Joiners.Math
{
  /// <summary>
  /// Array of 4 floats used for 3D rotation operations.
  /// </summary>
  public class                Quaternion
  {

    #region Constants

    public static readonly  Quaternion  Identity = new Quaternion(0.0f, 0.0f, 0.0f, 1.0f);

    #endregion Constants

    #region Members

    public float              x;
    public float              y;
    public float              z;
    public float              w;

    #endregion Members

    #region Constructors

    public                    Quaternion()
    {
      Set(Identity);
    }

    public                    Quaternion(Quaternion q)
    {
      Set(q);
    }

    public                    Quaternion(float x, float y, float z, float w)
    {
      Set(x, y, z, w);
    }

    #endregion Constructors

    #region Initialization && Uninitialization

    public void               Set(Quaternion q)
    {
      x = q.x; y = q.y; z = q.z; w = q.w;
    }

    public void               Set(float x, float y, float z, float w)
    {
      this.x = x;
      this.y = y;
      this.z = z;
      this.w = w;
    }

    #endregion Initialization && Uninitialization

    public float              GetMagnitude()
    {
      return ((float)System.Math.Sqrt(x * x + y * y + z * z + w * w));
    }

    public void               Normalize()
    {
      float norm = GetMagnitude();
      x /= norm;
      y /= norm;
      z /= norm;
      w /= norm;
    }

    #region Conversions with other representations

    #region Euler

    public void               FromEuler(float rx, float ry, float rz)
    {
      rx = Math.DegToRad(rx); ry = Math.DegToRad(ry); rz = Math.DegToRad(rz);

      double                  siny      = System.Math.Sin(ry * 0.5);
      double                  cosy      = System.Math.Cos(ry * 0.5);
      double                  sinz      = System.Math.Sin(rz * 0.5);
      double                  cosz      = System.Math.Cos(rz * 0.5);
      double                  sinx      = System.Math.Sin(rx * 0.5);
      double                  cosx      = System.Math.Cos(rx * 0.5);
      double                  cosyCosz  = cosy * cosz;
      double                  sinySinz  = siny * sinz;

      x = (float)(sinx * cosyCosz     - cosx * sinySinz);
      y = (float)(cosx * siny * cosz  + sinx * cosy * sinz);
      z = (float)(cosx * cosy * sinz  - sinx * siny * cosz);
      w = (float)(cosx * cosyCosz     + sinx * sinySinz);
      //      Normalize();
    }

    public void               ToEuler(out float rx, out float ry, out float rz)
    {
      Matrix4D                matrix = this.ToMatrix(); matrix.Transpose();
      matrix.ToEuler(out rx, out ry, out rz);
      //bank/attitude/heading
      //      rz = EdenArts.Math.Math.RadToDeg((float)System.Math.Atan2(2.0 * (x * y + z * w), (x * x - y * y - z * z + w * w)));
      //      rx = EdenArts.Math.Math.RadToDeg((float)System.Math.Atan2(2.0 * (y * z + x * w), (-(x * x) - (y * y) + z * z + w * w)));
      //      ry = EdenArts.Math.Math.RadToDeg(EdenArts.Math.Math.Asin(-2.0f * (x * z - y * w)));
    }

    public Vector3D           ToEuler()
    {
      //      return (new Vector3D(
      //              Math.RadToDeg((float)System.Math.Atan2(2.0 * (x * y + z * w), (x * x - y * y - z * z + w * w))),
      //              Math.RadToDeg((float)System.Math.Atan2(2.0 * (y * z + x * w), (-(x * x) - (y * y) + z * z + w * w))),
      //              Math.RadToDeg(EdenArts.Math.Math.Asin(-2.0f * (x * z - y * w)))
      //        ));

      float sqw = w * w;
      float sqx = x * x;
      float sqy = y * y;
      float sqz = z * z;
      return (new Vector3D(
        Math.RadToDeg((float)System.Math.Atan2(2.0f * (y * z + x * w), (-sqx - sqy + sqz + sqw))),
        Math.RadToDeg((float)System.Math.Asin(-2.0f * (x * z - y * w))),
        Math.RadToDeg((float)System.Math.Atan2(2.0f * (x * y + z * w), (sqx - sqy - sqz + sqw)))
        ));
    }

    #endregion Euler

    #region Matrix

    public Matrix4D           ToMatrix()
    {
      Matrix4D matrix = new Matrix4D();
      matrix.Set(Matrix4D.Identity);
      matrix.Values[0]   = 1 - (2 * (y * y + z * z));
      matrix.Values[1]   =     (2 * (x * y - z * w));
      matrix.Values[2]   =     (2 * (x * z + y * w));
      matrix.Values[4]   =     (2 * (x * y + z * w));
      matrix.Values[5]   = 1 - (2 * (x * x + z * z));
      matrix.Values[6]   =     (2 * (y * z - x * w));
      matrix.Values[8]   =     (2 * (x * z - y * w));
      matrix.Values[9]   =     (2 * (y * z + x * w));
      matrix.Values[10]  = 1 - (2 * (x * x + y * y));
      return (matrix);
    }

    public void               FromMatrix(Matrix4D matrix)
    {
      float                   trace = matrix.Values[0] + matrix.Values[5] + matrix.Values[10] + 1.0f;
      if (trace > 0.0000001f)
      {
        float                 S = (float)System.Math.Sqrt(trace) * 2.0f;
        this.x = (matrix.Values[9] - matrix.Values[6]) / S;
        this.y = (matrix.Values[2] - matrix.Values[8]) / S;
        this.z = (matrix.Values[4] - matrix.Values[1]) / S;
        this.w = 0.25f * S;
      }
      else
      {
        if (matrix.Values[0] > matrix.Values[5] && matrix.Values[0] > matrix.Values[10])
        {
          float               S = (float)System.Math.Sqrt(1.0 + matrix.Values[0] - matrix.Values[5] - matrix.Values[10]) * 2.0f;
          this.x = 0.25f * S;
          this.y = (matrix.Values[4] + matrix.Values[1]) / S;
          this.z = (matrix.Values[2] + matrix.Values[8]) / S;
          this.w = (matrix.Values[9] - matrix.Values[6]) / S;
        }
        else if (matrix.Values[5] > matrix.Values[10])
        {
          float               S = (float)System.Math.Sqrt(1.0 + matrix.Values[5] - matrix.Values[0] - matrix.Values[10]) * 2.0f;
          this.x = (matrix.Values[4] + matrix.Values[1]) / S;
          this.y = 0.25f * S;
          this.z = (matrix.Values[9] - matrix.Values[6]) / S;
          this.w = (matrix.Values[2] + matrix.Values[8]) / S;
        }
        else
        {
          float               S = (float)System.Math.Sqrt(1.0 + matrix.Values[10] - matrix.Values[0] - matrix.Values[5]) * 2.0f;
          this.x = (matrix.Values[2] + matrix.Values[8]) / S;
          this.y = (matrix.Values[9] - matrix.Values[6]) / S;
          this.z = 0.25f * S;
          this.w = (matrix.Values[4] + matrix.Values[1]) / S;
        }
      }
    }

    #endregion Matrix

    #region Axis

    public void               FromAxis(float x, float y, float z, float angle)
    {
      if (x == 0.0f && y == 0.0f && z == 0.0f)
      {
        x = 0.0f; y = 0.0f; z = 0.0f; w = 1.0f;
        return ;
      }
      float angle2 = angle / 2.0f;
      w = (float)System.Math.Cos(angle2);
      float scale = (float)System.Math.Sin(angle2);
      this.x = x * scale;
      this.y = y * scale;
      this.z = z * scale;
      Normalize();
    }

    public void               ToAxis(float [] axis)
    {
      float                   scale = (float)System.Math.Sqrt(1 - w * w/*x * x + y * y + z * z*/);

      axis[0] = (float)(2 * System.Math.Acos(w));
      if (scale == 0.0f)
      {
        axis[0] = 0.0f;
        axis[1] = 1.0f;
      }
      else
      {
        axis[1] = x / scale;
        axis[2] = y / scale;
        axis[3] = z / scale;
        float norm = (float)System.Math.Sqrt(axis[1]*axis[1]+axis[2]*axis[2]+axis[3]*axis[3]);
        axis[1] /= norm;
        axis[2] /= norm;
        axis[3] /= norm;
      }
/*
      Normalize();
      float cos_a = w;
      axis[0] = (float)System.Math.Acos(cos_a) * 2;
      float sin_a = (float)System.Math.Sqrt(1.0f - cos_a * cos_a);
      if (System.Math.Abs(sin_a) < 0.0005f)
        sin_a = 1.0f;
      axis[1] = x / sin_a;
      axis[2] = y / sin_a;
      axis[3] = z / sin_a;
*/
    }

    #endregion Axis

    #endregion Conversions with other representations

    public Vector3D           RotateVector(Vector3D vector3D)
    {
//      Quaternion              qInverse = new Quaternion(this); qInverse.Inverse();
//      Quaternion              qTranslationObjectSpace = new Quaternion(vector3D.x, vector3D.y, vector3D.z, 0);
//      Quaternion              qVector = this * qTranslationObjectSpace;
//      qVector = qVector * qInverse;
//      return (new Vector3D(qVector.x, qVector.y, qVector.z));
      Vector3D                v = new Vector3D();
      Matrix4D                matrix = this.ToMatrix(); //matrix.Transpose();
      v.Set(matrix.Values[0] * vector3D.x + matrix.Values[1] * vector3D.y + matrix.Values[2] * vector3D.z, 
            matrix.Values[4] * vector3D.x + matrix.Values[5] * vector3D.y + matrix.Values[6] * vector3D.z, 
            matrix.Values[8] * vector3D.x + matrix.Values[9] * vector3D.y + matrix.Values[10] * vector3D.z);
      return (v);
    }

    #region Operations

    public void   Conjugate()
    {
      this.x = -this.x;
      this.y = -this.y;
      this.z = -this.z;
    }

    public static Quaternion operator! (Quaternion q)
    {
      Quaternion qConjugate = new Quaternion(q); 
      qConjugate.Conjugate();
      return (qConjugate);
    }

    public void   Inverse()
    {
      float       magnitude = GetMagnitude();
      magnitude = magnitude * magnitude;
      this.w = this.w / magnitude;
      this.x = -this.x / magnitude;
      this.y = -this.y / magnitude;
      this.z = -this.z / magnitude;
    }

    #region Comparisons

    public static bool  operator == (Quaternion q1, Quaternion q2)
    {
      if ((object)q1 == null || (object)q2 == null)
      {
        if ((object)q1 == null || (object)q2 == null)
          return true;
        return false;
      }
    
      return (System.Math.Abs(q1.x - q2.x) < 0.0001f && 
              System.Math.Abs(q1.y - q2.y) < 0.0001f &&
              System.Math.Abs(q1.z - q2.z) < 0.0001f &&
              System.Math.Abs(q1.w - q2.w) < 0.0001f);
    }

    public static bool  operator != (Quaternion q1, Quaternion q2)
    { 
      return !(q1 == q2);
    }

    #endregion Comparisons

    #region Multiplication

    public void               Multiply(Quaternion q)
    {
      Set(this * q);
    }

    public static Quaternion  operator*(Quaternion q1, Quaternion q2)
    {
      Quaternion              q = new Quaternion();

      q.x = q1.x * q2.w + q1.w * q2.x + q1.z * q2.y - q1.y * q2.z;
      q.y = q1.y * q2.w + q1.w * q2.y + q1.x * q2.z - q1.z * q2.x;
      q.z = q1.z * q2.w + q1.w * q2.z + q1.y * q2.x - q1.x * q2.y;
      q.w = q1.w * q2.w - q1.x * q2.x - q1.y * q2.y - q1.z * q2.z;
      q.Normalize();
      return (q);
    }

    #endregion Multiplication

    #region Division

    public void             Divide(Quaternion q)
    {
      Set (this / q);
    }

    public static Quaternion  operator/(Quaternion q1, Quaternion q2)
    {
      return (!q2 * q1);
    }

    #endregion Division

    #endregion Operations

    #region object overrides

    public override bool      Equals(object o)
    {
      if (o is Quaternion)
        return (this == (Quaternion)o);
      return (false);
    }

    public override int     GetHashCode() 
    { 
      return x.GetHashCode() ^ (y.GetHashCode() ^ (~z.GetHashCode())); 
    } 

    #endregion object overrides

  }
}
