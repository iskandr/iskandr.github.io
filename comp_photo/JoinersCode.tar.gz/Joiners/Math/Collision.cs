//----------------------------------------------------------------------------
//  Project     : EdenArts.Physic
//  Author      : Valerie Tching
//  Date        : 01/02/2005
//  File        : Collision.cs
//  Description : Collision class
//----------------------------------------------------------------------------
//  EdenArts.Physic is a physic library.
//  The project is running under QPL licence.
//    (QPL Licence specifications: http://www.trolltech.com/licenses/qpl.html)
//  Zion is part of Eden Arts Team Work
//  Members are:
//      Nadim Awad        (awad_n@epitech.net)
//      Michel Courtine   (courti_m@epitech.net)
//      Matthieu Dehaussy (dehaus_m@epitech.net)
//      Julien Ferrero    (ferrer_j@epitech.net)
//      Nicolas Goubaux   (goubau_n@epitech.net)
//      Valerie Tching    (tching_v@epitech.net)
//  You can have further information on Zion website:
//         http://zion.labtech.epitech.net
//----------------------------------------------------------------------------

using System;
using System.Diagnostics;
using System.Collections;
using Joiners.Math;
using Joiners.Graphic;

namespace Joiners.Math
{

  /// <summary>
  /// This class contains all the mains methods for collision detection
  /// </summary>
  public class                Collision
  {

    #region 2D Collision

    public static bool        PointInRect(Vector2D point, Vector2D rectBottomLeftCorner, Vector2D rectTopRightCorner)
    {
      return (rectBottomLeftCorner.x <= point.x && point.x < rectTopRightCorner.x &&
        rectBottomLeftCorner.y <= point.y && point.y < rectTopRightCorner.y);
    }

    //    // Method use: Sum of angles formed with point and point pair-by-pair, must be 2 * PI
    //    public static bool        PointInPolygon(Vector2D point, Vector2D [] polygon)
    //    {
    //      float                   angleSum = 0;
    //      float                   tolerance = 0.001f;
    //      int                     i, j;
    //      j = polygon.Length - 1;
    //      for (i = 0; i < polygon.Length && (angleSum < Math.Math.PIMULT2 || System.Math.Abs(angleSum - Math.Math.PIMULT2) < tolerance); j = i, i++)
    //        angleSum += Vector2D.GetAngle(polygon[j] - point, polygon[i] - point);
    //      if (i < polygon.Length)
    //        return (false);
    //      return (System.Math.Abs(angleSum - Math.Math.PIMULT2) < tolerance);
    //    }

    // http://astronomy.swin.edu.au/~pbourke/geometry/insidepoly/
    public static bool        PointInPolygon(Vector2D point, Vector2D [] polygon)
    {
      bool                    inPolygon = false;
      int                     i, j;
      j = polygon.Length - 1;
      for (i = 0; i < polygon.Length; j = i, i++)
      {
        if (((polygon[j].y <= point.y && point.y < polygon[i].y) || 
          (polygon[i].y <= point.y && point.y < polygon[j].y)) &&
          (point.x < (polygon[j].x - polygon[i].x) * (point.y - polygon[i].y) / (polygon[j].y - polygon[i].y) + polygon[i].x))
          inPolygon = !inPolygon;
      }
      return (inPolygon);
    }

    public static bool        PolygonInPolygon(Vector2D [] polygonLittle, Vector2D [] polygonBig)
    {
      foreach (Vector2D v in polygonLittle)
      {
        if (PointInPolygon(v, polygonBig) == false)
          return (false);
      }
      return (true);
    }

    public static bool        PolygonIntersectPolygon(Vector2D [] polygon1, Vector2D [] polygon2)
    {
      foreach (Vector2D v in polygon1)
        if (PointInPolygon(v, polygon2))
          return (true);
      return (false);
    }

    #endregion 2D Collision

  }
}