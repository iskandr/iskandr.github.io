//----------------------------------------------------------------------------
//  Project     : EdenArts.Math
//  Author      : Valerie Tching
//  Date        : 01/02/2005
//  File        : Vector2D.cs
//  Description : Vector2D class
//----------------------------------------------------------------------------
//  EdenArts.Math is a math library.
//  The project is running under QPL licence.
//    (QPL Licence specifications: http://www.trolltech.com/licenses/qpl.html)
//  Zion is part of Eden Arts Team Work
//  Members are:
//      Nadim Awad        (awad_n@epitech.net)
//      Michel Courtine   (courti_m@epitech.net)
//      Matthieu Dehaussy (dehaus_m@epitech.net)
//      Julien Ferrero    (ferrer_j@epitech.net)
//      Nicolas Goubaux   (goubau_n@epitech.net)
//      Valerie Tching    (tching_v@epitech.net)
//  You can have further information on Zion website:
//         http://zion.labtech.epitech.net
//----------------------------------------------------------------------------

using System;

namespace Joiners.Math
{
  /// <summary>
  /// Array of 2 floats.
  /// </summary>
  public struct             Vector2D
  {
    #region Members

    public float            x;
    public float            y;

    #endregion Members

    #region Properties

    public float            this[int index]
    {
      get { return (index == 0 ? x : (index == 1 ? y : 0)); }
      set { if (index == 0) x = value; else if (index == 1) y = value; }
    }

    public float            Length
    {
      get { return ((float)System.Math.Sqrt(x * x + y * y)); }
    }

    public static Vector2D Zero 
    {	
      get 
      {
        return new Vector2D();
      }
    }
    #endregion Properties

    #region Constructors

    public                  Vector2D(float x, float y)
    {
      this.x = x;
      this.y = y;
    }

    public                  Vector2D(Vector2D vector2D)
    {
      this.x = vector2D.x;
      this.y = vector2D.y;
    }

    #endregion Constructors

    #region Initializations && Uninitializations

    public void             Set(float x, float y)
    {
      this.x = x;
      this.y = y;
    }

    public void             Set(Vector2D vector2D)
    {
      this.x = vector2D.x;
      this.y = vector2D.y;
    }

    #endregion Initializations && Uninitializations

    #region Operations

    #region Equality

    public static bool      operator == (Vector2D vector2D1, Vector2D vector2D2)
    {
      return (vector2D1.x == vector2D2.x && vector2D1.y == vector2D2.y);
    }
      
    public static bool      operator != (Vector2D vector2D1, Vector2D vector2D2)
    {
      return (vector2D1.x != vector2D2.x || vector2D1.y != vector2D2.y);
    }

    #endregion Equality

    #region Addition

    public void             Add(Vector2D vector2D)
    {
      this.x += vector2D.x;
      this.y += vector2D.y;
    }

    public static Vector2D  operator+(Vector2D vector2D1, Vector2D vector2D2)
    {
      return (new Vector2D(vector2D1.x + vector2D2.x, vector2D1.y + vector2D2.y));
    }

    #endregion Addition

    #region Substraction

    public void             Substract(Vector2D vector2D)
    {
      this.x -= vector2D.x;
      this.y -= vector2D.y;
    }

    public static Vector2D  operator-(Vector2D vector2D1, Vector2D vector2D2)
    {
      return (new Vector2D(vector2D1.x - vector2D2.x, vector2D1.y - vector2D2.y));
    }

    #endregion Substraction

    #region Scalar Multiplication

    public void             Multiply(float scalar)
    {
      this.x *= scalar;
      this.y *= scalar;
    }

    public static Vector2D  operator*(Vector2D vector2D, float scalar)
    {
      return (new Vector2D(vector2D.x * scalar, vector2D.y * scalar));
    }

    #endregion Scalar Multiplication

    #region Scalar Division

    public void             Divide(float scalar)
    {
      this.x /= scalar;
      this.y /= scalar;
    }

    public static Vector2D  operator/(Vector2D vector2D, float scalar)
    {
      return (new Vector2D(vector2D.x / scalar, vector2D.y / scalar));
    }

    #endregion Scalar Division

    #region Negation

    public void             Negate()
    {
      this.x = -this.x;
      this.y = -this.y;
    }

    public static Vector2D  operator-(Vector2D vector2D)
    {
      return (new Vector2D(-vector2D.x, -vector2D.y));
    }

    #endregion Negation

    #region Dot Product

    public static float   DotProduct(Vector2D vector2D1, Vector2D vector2D2)
    {
      return (vector2D1.x * vector2D2.x + vector2D1.y * vector2D2.y);
    }

    #endregion Dot Product
	  
    public static Vector2D Normal(Vector2D a) 
     {
        return a / a.Length;
     }

	  public static float   GetAngle(Vector2D vector2D1, Vector2D vector2D2)
    {
      float               angle = (float)System.Math.Acos(DotProduct(vector2D1, vector2D2) / (vector2D1.Length * vector2D2.Length));
      if (Math.GetOrientation(vector2D1, new Vector2D(0, 0), vector2D2) > 0)
        angle = 2 * Math.PI - angle;
      return (angle);
    }

   

    #endregion Operations

    #region Overrides

    public override bool    Equals(object obj)
    {
      if (obj is Vector2D)
        return (this.x == ((Vector2D)obj).x && this.y == ((Vector2D)obj).y);

      return false;
    }

    public override int     GetHashCode()
    {
      return base.GetHashCode ();
    }

    public override string  ToString()
    {
      return string.Format("x: {0} y: {1}", x, y);
    }

    #endregion // Overrides
  }
}
