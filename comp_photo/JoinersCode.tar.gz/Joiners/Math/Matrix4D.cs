//----------------------------------------------------------------------------
//  Project     : EdenArts.Math
//  Author      : Valerie Tching
//  Date        : 01/02/2005
//  File        : Matrix4D.cs
//  Description : Matrix4D class
//----------------------------------------------------------------------------
//  EdenArts.Math is a math library.
//  The project is running under QPL licence.
//    (QPL Licence specifications: http://www.trolltech.com/licenses/qpl.html)
//  Zion is part of Eden Arts Team Work
//  Members are:
//      Nadim Awad        (awad_n@epitech.net)
//      Michel Courtine   (courti_m@epitech.net)
//      Matthieu Dehaussy (dehaus_m@epitech.net)
//      Julien Ferrero    (ferrer_j@epitech.net)
//      Nicolas Goubaux   (goubau_n@epitech.net)
//      Valerie Tching    (tching_v@epitech.net)
//  You can have further information on Zion website:
//         http://zion.labtech.epitech.net
//----------------------------------------------------------------------------

using System;

namespace Joiners.Math
{
  /// <summary>
  /// Array of 16 floats used to describe a position in a 3D space. 
  /// the float array Values can be directly used with OpenGL calls.
  /// </summary>
  public class        Matrix4D
  {
    #region Constants

    public readonly static Matrix4D Identity = new Matrix4D(1.0f, 0.0f, 0.0f, 0.0f, 
                                                            0.0f, 1.0f, 0.0f, 0.0f,
                                                            0.0f, 0.0f, 1.0f, 0.0f,
                                                            0.0f, 0.0f, 0.0f, 1.0f);

    public readonly static Matrix4D Zero     = new Matrix4D(0.0f, 0.0f, 0.0f, 0.0f, 
                                                            0.0f, 0.0f, 0.0f, 0.0f,
                                                            0.0f, 0.0f, 0.0f, 0.0f,
                                                            0.0f, 0.0f, 0.0f, 0.0f);

    #endregion Constants

    #region Members

    public float []   Values = new float[16];

    #endregion Members

    #region Constructors

    public            Matrix4D()
    {
      Set(Identity);
    }

    public            Matrix4D(float m00, float m01, float m02, float m03, 
                               float m10, float m11, float m12, float m13, 
                               float m20, float m21, float m22, float m23,
                               float m30, float m31, float m32, float m33)
    {
      Set(m00, m01, m02, m03, 
          m10, m11, m12, m13, 
          m20, m21, m22, m23,
          m30, m31, m32, m33);
    }

    public          Matrix4D(Matrix4D matrix)
    {
      Set(matrix);
    }

    public Matrix4D(float[] values)
    {
      Values = values;
    }

    public Matrix4D(double[] values)
    {
      if (values.Length < 16)
        return;
      for(int i = 0; i < values.Length; i++)
      {
        Values[i] = (float)values[i];
      }
    }

    #endregion Constructors

    #region Properties

    public float      x
    {
      set { Values[3] = value;  }
      get { return (Values[3]); }
    }

    public float      y
    {
      set { Values[7] = value;  }
      get { return (Values[7]); }
    }

    public float      z
    {
      set { Values[11] = value;  }
      get { return (Values[11]); }
    }

    #endregion Properties

    #region Initialization && Uninitialization

    public void       Set(float m00, float m01, float m02, float m03, 
                          float m10, float m11, float m12, float m13, 
                          float m20, float m21, float m22, float m23,
                          float m30, float m31, float m32, float m33)
    {
      Values[0]  = m00; Values[1]  = m01; Values[2]  = m02; Values[3]  = m03;
      Values[4]  = m10; Values[5]  = m11; Values[6]  = m12; Values[7]  = m13;
      Values[8]  = m20; Values[9]  = m21; Values[10] = m22; Values[11] = m23;
      Values[12] = m30; Values[13] = m31; Values[14] = m32; Values[15] = m33;
    }

    public void       SetMatrix3D(Matrix4D matrix)
    {
      Values[0] = matrix.Values[0];
      Values[1] = matrix.Values[1];
      Values[2] = matrix.Values[2];
      Values[4] = matrix.Values[4];
      Values[5] = matrix.Values[5];
      Values[6] = matrix.Values[6];
      Values[8] = matrix.Values[8];
      Values[9] = matrix.Values[9];
      Values[10] = matrix.Values[10];
    }

    public void       Set(Matrix4D matrix)
    {
      for (int i = 0; i < 16; i++)
        Values[i] = matrix.Values[i];
    }

    public void       Set(string values)
    {
      Set(values, " ");
    }

    public void       Set(string [] values, int index)
    {
      if (values.Length < (16 + index))
        return;

      for (int i = 0; i < 16; i++)
        Values[i] = float.Parse(values[i + index]);
    }

    public void       Set(string values, string separator)
    {
      string []       splitted = values.Split(separator.ToCharArray());

      Set(splitted, 0);
    }

    public void       SetDiagonal(float m00, float m11, float m22, float m33)
    {
      Values[0] = m00;
      Values[5] = m11;
      Values[10] = m22;
      Values[15] = m33;
    }

    public void       SetTranslationMatrix(float m03, float m13, float m23)
    {
      Values[3] = m03;
      Values[7] = m13;
      Values[11] = m23;
    }

    public void       SetTranslationMatrix(Vector3D v)
    {
      Values[3] = v.x;
      Values[7] = v.y;
      Values[11] = v.z;
    }

    public void SetRotationMatrixX(double angle)
    {
      this.Set(Identity);
      Values[5] = (float)System.Math.Cos(angle);
      Values[6] = (float)-System.Math.Sin(angle);
      Values[9] = (float)System.Math.Sin(angle);
      Values[10] = (float)System.Math.Cos(angle);
    }

    public void SetRotationMatrixY(double angle)
    {
      this.Set(Identity);
      Values[0] = (float)System.Math.Cos(angle);
      Values[2] = (float)System.Math.Sin(angle);
      Values[8] = (float)-System.Math.Sin(angle);
      Values[10] = (float)System.Math.Cos(angle);
    }

    public void SetRotationMatrixZ(double angle)
    {
      this.Set(Identity);
      Values[0] = (float)System.Math.Cos(angle);
      Values[1] = (float)-System.Math.Sin(angle);
      Values[4] = (float)System.Math.Sin(angle);
      Values[5] = (float)System.Math.Cos(angle);
    }


    public Matrix4D   Copy()
    {
      Matrix4D newMatrix = new Matrix4D();
      newMatrix.Set(this);
      return (newMatrix);
    }

    #endregion Initialization && Uninitialization

    #region Position
    /// <summary>
    /// Get a Vector3D out of the matrix
    /// </summary>
    /// <param name="x"></param>
    /// <param name="y"></param>
    /// <param name="z"></param>
    public Vector3D   GetPosition()
    {
      return (new Vector3D(Values[3], Values[7], Values[11]));
    }

    public void SetPosition(Vector3D position)
    {
      Values[3] = position.x;
      Values[7] = position.y;
      Values[11] = position.z;
    }

    /// <summary>
    /// Translate matrix by given(x,y,z)
    /// To describe a valid position a new matrix should be
    /// first set to Identity by a call to SetToIdentity();
    /// </summary>
    /// <param name="x"></param>
    /// <param name="y"></param>
    /// <param name="z"></param>
    public	void	    Translate(float x, float y, float z) 
    {
      Values[12] = Values[0] * x + Values[4] * y + Values[8]  * z + Values[12];
      Values[13] = Values[1] * x + Values[5] * y + Values[9]  * z + Values[13];
      Values[14] = Values[2] * x + Values[6] * y + Values[10] * z + Values[14];
    }

    public void Translate(Vector3D vector)
    {
      Values[12] = Values[0] * vector.x + Values[4] * vector.y + Values[8] * vector.z + Values[12];
      Values[13] = Values[1] * vector.x + Values[5] * vector.y + Values[9] * vector.z + Values[13];
      Values[14] = Values[2] * vector.x + Values[6] * vector.y + Values[10] * vector.z + Values[14];
    }

    #endregion Position

    #region Rotation

    #region Conversion with Euler representation

    public void       ToEuler(out float rx, out float ry, out float rz)
    {
      ry = (float)System.Math.Asin(Values[2]);        /* Calculate Y-axis angle */
      float D = ry;
      float         C =  (float)System.Math.Cos(ry);
      if (System.Math.Abs(C) > 0.005f )             /* Gimball lock? */
      {
        float temprx      =  Values[10] / C;           /* No, so get X-axis angle */
        float tempry      = -Values[6]  / C;
        rx = (float)System.Math.Atan2(tempry, temprx);
        temprx      =  Values[0] / C;            /* Get Z-axis angle */
        tempry      = -Values[1] / C;
        rz  = (float)System.Math.Atan2(tempry, temprx);
      }
      else                                 /* Gimball lock has occurred */
      {
        rx  = 0;                      /* Set X-axis angle to zero */
        float temprx      =  Values[5];                 /* And calculate Z-axis angle */
        float tempry      =  Values[4];
        rz  = (float)System.Math.Atan2(tempry, temprx);
      }

      rx = Math.RadToDeg(rx);
      ry = Math.RadToDeg(ry);
      rz = Math.RadToDeg(rz);

      /* return only positive angles in [0,360] */
      if (rx < 0) rx += 360;
      if (ry < 0) ry += 360;
      if (rz < 0) rz += 360;

    }

    public void       FromEuler(float rx, float ry, float rz)
    {
      rx = Math.DegToRad(rx); ry = Math.DegToRad(ry); rz = Math.DegToRad(rz);
      this.Set(Identity);
      Values[0]  = (float)(System.Math.Cos(ry) * System.Math.Cos(rz));
      Values[1]  = (float)(-System.Math.Cos(ry) * System.Math.Sin(rz));
      Values[2]  = (float)(System.Math.Sin(ry));
      Values[4]  = (float)(System.Math.Sin(rx) * System.Math.Sin(ry) * System.Math.Cos(rz) + System.Math.Cos(rx) * System.Math.Sin(rz));
      Values[5]  = (float)(-System.Math.Sin(rx) * System.Math.Sin(ry) * System.Math.Sin(rz) + System.Math.Cos(rx) * System.Math.Cos(rz));
      Values[6]  = (float)(-System.Math.Sin(rx) * System.Math.Cos(ry));
      Values[8]  = (float)(-System.Math.Cos(rx) * System.Math.Sin(ry) * System.Math.Cos(rz) + System.Math.Sin(rx) * System.Math.Sin(rz));
      Values[9]  = (float)(System.Math.Cos(rx) * System.Math.Sin(ry) * System.Math.Sin(rz) + System.Math.Sin(rx) * System.Math.Cos(rz));
      Values[10] = (float)(System.Math.Cos(rx) * System.Math.Cos(ry));
    }

    public void       FromAxis(float angle, float u, float v, float w)
    {
      float           rcos = (float)(System.Math.Cos(angle));
      float           rsin = (float)(System.Math.Sin(angle));

      Values[0] =      rcos + u * u * (1 - rcos);
      Values[1] = -w * rsin + u*v*(1-rcos);
      Values[2] =  v * rsin + u*w*(1-rcos);
      Values[4] =  w * rsin + v * u * (1 - rcos);
      Values[5] =      rcos + v*v*(1-rcos);
      Values[6] = -u * rsin + v*w*(1-rcos);
      Values[8] = -v * rsin + w*u*(1-rcos);
      Values[9] =  u * rsin + w*v*(1-rcos);
      Values[10] =      rcos + w*w*(1-rcos);
    }

    #endregion Conversion with Euler representation

    #endregion Rotation

    public void       Transpose()
    {
      float           temp;
      temp = Values[1];  Values[1]  = Values[4];  Values[4]  = temp;
      temp = Values[2];  Values[2]  = Values[8];  Values[8]  = temp;
      temp = Values[3];  Values[3]  = Values[12]; Values[12] = temp;
      temp = Values[6];  Values[6]  = Values[9];  Values[9]  = temp;
      temp = Values[7];  Values[7]  = Values[13]; Values[13] = temp;
      temp = Values[11]; Values[11] = Values[14]; Values[14] = temp;
    }

    public void       FromOpenGL()
    {
      Transpose();
    }

    #region ToString
    public override string            ToString()
    {
      return ToString(" ");
    }

    public string                     ToString(string separator)
    {
      string                          res = string.Empty;

      for (int i = 0; i < 16; i++)
        res += (res.Length > 0 ? separator : string.Empty) + Values[i].ToString();

      return res;
    }
    #endregion // ToString

    #region Operator Overloads

    public void   Multiply(Matrix4D matrix)
    {
      Set(this * matrix);
    }

    static public Matrix4D	operator * (Matrix4D m1, Matrix4D m2)
    {
      Matrix4D result = new Matrix4D();
      result.Set(Zero);

      int i = 0;
      int startvalue = 0;
      int resPosition = 0;
      for(; startvalue != 16; )
      {
        i = startvalue;
        for (int j = 0; j != 4; j++)
        {
          for (int k = 0; k != 16 ; k += 4)
          {
            result.Values[resPosition] += m1.Values[i] * m2.Values[j + k];
            i++;
          }
          i = startvalue;
          resPosition++;
        }
        startvalue += 4;
      }
      return (result);
    }	

    #endregion Operator Overloads
  }
}
