﻿namespace Joiners
{
  partial class ImageViewer
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
        this.pictureBox = new System.Windows.Forms.PictureBox();
        this.statusStrip = new System.Windows.Forms.StatusStrip();
        this.statusLabel = new System.Windows.Forms.ToolStripStatusLabel();
        this.menuStrip = new System.Windows.Forms.MenuStrip();
        this.toolsStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.cropToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.filtersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.blurToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.gaussianBlurToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.sharpenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.histogramEqualizationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.oilPaintingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.sepiaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.undoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
        ((System.ComponentModel.ISupportInitialize)(this.pictureBox)).BeginInit();
        this.statusStrip.SuspendLayout();
        this.menuStrip.SuspendLayout();
        this.SuspendLayout();
        // 
        // pictureBox
        // 
        this.pictureBox.Location = new System.Drawing.Point(0, 24);
        this.pictureBox.Name = "pictureBox";
        this.pictureBox.Size = new System.Drawing.Size(385, 413);
        this.pictureBox.TabIndex = 0;
        this.pictureBox.TabStop = false;
        this.pictureBox.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pictureBox_MouseMove);
        this.pictureBox.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox_MouseDown);
        this.pictureBox.Paint += new System.Windows.Forms.PaintEventHandler(this.pictureBox_Paint);
        this.pictureBox.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pictureBox_MouseUp);
        // 
        // statusStrip
        // 
        this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.statusLabel});
        this.statusStrip.Location = new System.Drawing.Point(0, 440);
        this.statusStrip.Name = "statusStrip";
        this.statusStrip.Size = new System.Drawing.Size(385, 22);
        this.statusStrip.TabIndex = 1;
        // 
        // statusLabel
        // 
        this.statusLabel.Name = "statusLabel";
        this.statusLabel.Size = new System.Drawing.Size(0, 17);
        // 
        // menuStrip
        // 
        this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolsStripMenuItem});
        this.menuStrip.Location = new System.Drawing.Point(0, 0);
        this.menuStrip.Name = "menuStrip";
        this.menuStrip.Size = new System.Drawing.Size(385, 24);
        this.menuStrip.TabIndex = 2;
        this.menuStrip.Text = "menuStrip1";
        // 
        // toolsStripMenuItem
        // 
        this.toolsStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.undoToolStripMenuItem,
            this.toolStripSeparator1,
            this.cropToolStripMenuItem,
            this.filtersToolStripMenuItem});
        this.toolsStripMenuItem.ForeColor = System.Drawing.SystemColors.WindowText;
        this.toolsStripMenuItem.Name = "toolsStripMenuItem";
        this.toolsStripMenuItem.Size = new System.Drawing.Size(48, 20);
        this.toolsStripMenuItem.Text = "Tools";
        // 
        // cropToolStripMenuItem
        // 
        this.cropToolStripMenuItem.Name = "cropToolStripMenuItem";
        this.cropToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
        this.cropToolStripMenuItem.Text = "Crop";
        this.cropToolStripMenuItem.Click += new System.EventHandler(this.cropToolStripMenuItem_Click);
        // 
        // filtersToolStripMenuItem
        // 
        this.filtersToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.blurToolStripMenuItem,
            this.gaussianBlurToolStripMenuItem,
            this.sharpenToolStripMenuItem,
            this.histogramEqualizationToolStripMenuItem,
            this.oilPaintingToolStripMenuItem,
            this.sepiaToolStripMenuItem});
        this.filtersToolStripMenuItem.Name = "filtersToolStripMenuItem";
        this.filtersToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
        this.filtersToolStripMenuItem.Text = "Filters";
        // 
        // blurToolStripMenuItem
        // 
        this.blurToolStripMenuItem.Name = "blurToolStripMenuItem";
        this.blurToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
        this.blurToolStripMenuItem.Text = "Blur";
        this.blurToolStripMenuItem.Click += new System.EventHandler(this.blurToolStripMenuItem_Click);
        // 
        // gaussianBlurToolStripMenuItem
        // 
        this.gaussianBlurToolStripMenuItem.Name = "gaussianBlurToolStripMenuItem";
        this.gaussianBlurToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
        this.gaussianBlurToolStripMenuItem.Text = "Gaussian Blur";
        this.gaussianBlurToolStripMenuItem.Click += new System.EventHandler(this.gaussianBlurToolStripMenuItem_Click);
        // 
        // sharpenToolStripMenuItem
        // 
        this.sharpenToolStripMenuItem.Name = "sharpenToolStripMenuItem";
        this.sharpenToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
        this.sharpenToolStripMenuItem.Text = "Sharpen";
        this.sharpenToolStripMenuItem.Click += new System.EventHandler(this.sharpenToolStripMenuItem_Click);
        // 
        // histogramEqualizationToolStripMenuItem
        // 
        this.histogramEqualizationToolStripMenuItem.Name = "histogramEqualizationToolStripMenuItem";
        this.histogramEqualizationToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
        this.histogramEqualizationToolStripMenuItem.Text = "Histogram Equalization";
        this.histogramEqualizationToolStripMenuItem.Click += new System.EventHandler(this.histogramEqualizationToolStripMenuItem_Click);
        // 
        // oilPaintingToolStripMenuItem
        // 
        this.oilPaintingToolStripMenuItem.Name = "oilPaintingToolStripMenuItem";
        this.oilPaintingToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
        this.oilPaintingToolStripMenuItem.Text = "Oil Painting";
        this.oilPaintingToolStripMenuItem.Click += new System.EventHandler(this.oilPaintingToolStripMenuItem_Click);
        // 
        // sepiaToolStripMenuItem
        // 
        this.sepiaToolStripMenuItem.Name = "sepiaToolStripMenuItem";
        this.sepiaToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
        this.sepiaToolStripMenuItem.Text = "Sepia";
        this.sepiaToolStripMenuItem.Click += new System.EventHandler(this.sepiaToolStripMenuItem_Click);
        // 
        // undoToolStripMenuItem
        // 
        this.undoToolStripMenuItem.Enabled = false;
        this.undoToolStripMenuItem.Name = "undoToolStripMenuItem";
        this.undoToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
        this.undoToolStripMenuItem.Text = "Undo";
        this.undoToolStripMenuItem.Click += new System.EventHandler(this.undoToolStripMenuItem_Click);
        // 
        // toolStripSeparator1
        // 
        this.toolStripSeparator1.Name = "toolStripSeparator1";
        this.toolStripSeparator1.Size = new System.Drawing.Size(149, 6);
        // 
        // ImageViewer
        // 
        this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
        this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
        this.AutoSize = true;
        this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
        this.ClientSize = new System.Drawing.Size(385, 462);
        this.Controls.Add(this.menuStrip);
        this.Controls.Add(this.statusStrip);
        this.Controls.Add(this.pictureBox);
        this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
        this.MainMenuStrip = this.menuStrip;
        this.MaximizeBox = false;
        this.Name = "ImageViewer";
        this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
        this.Text = "Image Viewer";
        ((System.ComponentModel.ISupportInitialize)(this.pictureBox)).EndInit();
        this.statusStrip.ResumeLayout(false);
        this.statusStrip.PerformLayout();
        this.menuStrip.ResumeLayout(false);
        this.menuStrip.PerformLayout();
        this.ResumeLayout(false);
        this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.PictureBox pictureBox;
    private System.Windows.Forms.StatusStrip statusStrip;
    private System.Windows.Forms.ToolStripStatusLabel statusLabel;
    private System.Windows.Forms.MenuStrip menuStrip;
    private System.Windows.Forms.ToolStripMenuItem toolsStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem cropToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem filtersToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem blurToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem gaussianBlurToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem histogramEqualizationToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem oilPaintingToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem sepiaToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem sharpenToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem undoToolStripMenuItem;
    private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
  }
}