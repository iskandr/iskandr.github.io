﻿namespace Joiners
{
  partial class FormMain
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
        this.components = new System.ComponentModel.Container();
        this.imageList = new System.Windows.Forms.ImageList(this.components);
        this.listViewImages = new System.Windows.Forms.ListView();
        this.folderBrowserDialog = new System.Windows.Forms.FolderBrowserDialog();
        this.menuStrip1 = new System.Windows.Forms.MenuStrip();
        this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.openDirectoryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.saveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
        this.quitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.optionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.backgroundColorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.progressBarLoad = new System.Windows.Forms.ProgressBar();
        this.bottomImageList = new System.Windows.Forms.ImageList(this.components);
        this.saveFileDialog = new System.Windows.Forms.SaveFileDialog();
        this.colorDialog = new System.Windows.Forms.ColorDialog();
        this.panelMain = new Joiners.PanelMain();
        this.bottomPanel = new System.Windows.Forms.Panel();
        this.btnBottomPanelClose = new System.Windows.Forms.Button();
        this.ddlSimilarity = new System.Windows.Forms.ComboBox();
        this.bottomListView = new System.Windows.Forms.ListView();
        this.bottomLabel = new System.Windows.Forms.Label();
        this.menuStrip1.SuspendLayout();
        this.panelMain.SuspendLayout();
        this.bottomPanel.SuspendLayout();
        this.SuspendLayout();
        // 
        // imageList
        // 
        this.imageList.ColorDepth = System.Windows.Forms.ColorDepth.Depth24Bit;
        this.imageList.ImageSize = new System.Drawing.Size(128, 96);
        this.imageList.TransparentColor = System.Drawing.Color.Transparent;
        // 
        // listViewImages
        // 
        this.listViewImages.AllowDrop = true;
        this.listViewImages.Dock = System.Windows.Forms.DockStyle.Right;
        this.listViewImages.LargeImageList = this.imageList;
        this.listViewImages.Location = new System.Drawing.Point(631, 24);
        this.listViewImages.Margin = new System.Windows.Forms.Padding(1, 1, 1, 3);
        this.listViewImages.MultiSelect = false;
        this.listViewImages.Name = "listViewImages";
        this.listViewImages.Size = new System.Drawing.Size(209, 614);
        this.listViewImages.TabIndex = 0;
        this.listViewImages.UseCompatibleStateImageBehavior = false;
        this.listViewImages.MouseUp += new System.Windows.Forms.MouseEventHandler(this.listViewImages_MouseUp);
        this.listViewImages.MouseDown += new System.Windows.Forms.MouseEventHandler(this.listViewImages_MouseDown);
        // 
        // folderBrowserDialog
        // 
        this.folderBrowserDialog.ShowNewFolderButton = false;
        // 
        // menuStrip1
        // 
        this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.optionsToolStripMenuItem});
        this.menuStrip1.Location = new System.Drawing.Point(0, 0);
        this.menuStrip1.Name = "menuStrip1";
        this.menuStrip1.Size = new System.Drawing.Size(840, 24);
        this.menuStrip1.TabIndex = 1;
        this.menuStrip1.Text = "menuStrip1";
        // 
        // fileToolStripMenuItem
        // 
        this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openDirectoryToolStripMenuItem,
            this.saveToolStripMenuItem,
            this.toolStripSeparator1,
            this.quitToolStripMenuItem});
        this.fileToolStripMenuItem.ForeColor = System.Drawing.SystemColors.WindowText;
        this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
        this.fileToolStripMenuItem.Size = new System.Drawing.Size(35, 20);
        this.fileToolStripMenuItem.Text = "File";
        // 
        // openDirectoryToolStripMenuItem
        // 
        this.openDirectoryToolStripMenuItem.ForeColor = System.Drawing.SystemColors.WindowText;
        this.openDirectoryToolStripMenuItem.Name = "openDirectoryToolStripMenuItem";
        this.openDirectoryToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
        this.openDirectoryToolStripMenuItem.Text = "Open Directory";
        this.openDirectoryToolStripMenuItem.Click += new System.EventHandler(this.openDirectoryToolStripMenuItem_Click);
        // 
        // saveToolStripMenuItem
        // 
        this.saveToolStripMenuItem.Name = "saveToolStripMenuItem";
        this.saveToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
        this.saveToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
        this.saveToolStripMenuItem.Text = "Save";
        this.saveToolStripMenuItem.Click += new System.EventHandler(this.saveToolStripMenuItem_Click);
        // 
        // toolStripSeparator1
        // 
        this.toolStripSeparator1.Name = "toolStripSeparator1";
        this.toolStripSeparator1.Size = new System.Drawing.Size(155, 6);
        // 
        // quitToolStripMenuItem
        // 
        this.quitToolStripMenuItem.ForeColor = System.Drawing.SystemColors.WindowText;
        this.quitToolStripMenuItem.Name = "quitToolStripMenuItem";
        this.quitToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
        this.quitToolStripMenuItem.Text = "Quit";
        this.quitToolStripMenuItem.Click += new System.EventHandler(this.quitToolStripMenuItem_Click);
        // 
        // optionsToolStripMenuItem
        // 
        this.optionsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.backgroundColorToolStripMenuItem});
        this.optionsToolStripMenuItem.Name = "optionsToolStripMenuItem";
        this.optionsToolStripMenuItem.Size = new System.Drawing.Size(56, 20);
        this.optionsToolStripMenuItem.Text = "Options";
        // 
        // backgroundColorToolStripMenuItem
        // 
        this.backgroundColorToolStripMenuItem.Name = "backgroundColorToolStripMenuItem";
        this.backgroundColorToolStripMenuItem.Size = new System.Drawing.Size(169, 22);
        this.backgroundColorToolStripMenuItem.Text = "Background Color";
        this.backgroundColorToolStripMenuItem.Click += new System.EventHandler(this.backgroundColorToolStripMenuItem_Click);
        // 
        // progressBarLoad
        // 
        this.progressBarLoad.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
        this.progressBarLoad.Location = new System.Drawing.Point(631, 615);
        this.progressBarLoad.Name = "progressBarLoad";
        this.progressBarLoad.Size = new System.Drawing.Size(209, 23);
        this.progressBarLoad.TabIndex = 2;
        this.progressBarLoad.Visible = false;
        // 
        // bottomImageList
        // 
        this.bottomImageList.ColorDepth = System.Windows.Forms.ColorDepth.Depth24Bit;
        this.bottomImageList.ImageSize = new System.Drawing.Size(128, 96);
        this.bottomImageList.TransparentColor = System.Drawing.Color.Transparent;
        // 
        // saveFileDialog
        // 
        this.saveFileDialog.DefaultExt = "bmp";
        this.saveFileDialog.Filter = "BMP files (*.bmp)|*.bmp";
        this.saveFileDialog.InitialDirectory = "C:\\Users\\Nado\\Desktop";
        // 
        // panelMain
        // 
        this.panelMain.AllowDrop = true;
        this.panelMain.BackColor = System.Drawing.SystemColors.Window;
        this.panelMain.Controls.Add(this.bottomPanel);
        this.panelMain.Dock = System.Windows.Forms.DockStyle.Fill;
        this.panelMain.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        this.panelMain.Location = new System.Drawing.Point(0, 24);
        this.panelMain.Name = "panelMain";
        this.panelMain.Size = new System.Drawing.Size(631, 614);
        this.panelMain.TabIndex = 3;
        this.panelMain.Text = "Joiners";
        // 
        // bottomPanel
        // 
        this.bottomPanel.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
        this.bottomPanel.BackColor = System.Drawing.SystemColors.Window;
        this.bottomPanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
        this.bottomPanel.Controls.Add(this.btnBottomPanelClose);
        this.bottomPanel.Controls.Add(this.ddlSimilarity);
        this.bottomPanel.Controls.Add(this.bottomListView);
        this.bottomPanel.Controls.Add(this.bottomLabel);
        this.bottomPanel.Location = new System.Drawing.Point(12, 424);
        this.bottomPanel.Name = "bottomPanel";
        this.bottomPanel.Size = new System.Drawing.Size(602, 190);
        this.bottomPanel.TabIndex = 2;
        // 
        // btnBottomPanelClose
        // 
        this.btnBottomPanelClose.BackColor = System.Drawing.SystemColors.Window;
        this.btnBottomPanelClose.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
        this.btnBottomPanelClose.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        this.btnBottomPanelClose.ForeColor = System.Drawing.Color.DarkGray;
        this.btnBottomPanelClose.Location = new System.Drawing.Point(531, 8);
        this.btnBottomPanelClose.Name = "btnBottomPanelClose";
        this.btnBottomPanelClose.Size = new System.Drawing.Size(49, 23);
        this.btnBottomPanelClose.TabIndex = 4;
        this.btnBottomPanelClose.Text = "close";
        this.btnBottomPanelClose.UseVisualStyleBackColor = false;
        this.btnBottomPanelClose.Click += new System.EventHandler(this.btnBottomPanelClose_Click);
        // 
        // ddlSimilarity
        // 
        this.ddlSimilarity.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
        this.ddlSimilarity.FormattingEnabled = true;
        this.ddlSimilarity.Location = new System.Drawing.Point(336, 7);
        this.ddlSimilarity.Name = "ddlSimilarity";
        this.ddlSimilarity.Size = new System.Drawing.Size(121, 21);
        this.ddlSimilarity.TabIndex = 3;
        this.ddlSimilarity.SelectedIndexChanged += new System.EventHandler(this.ddlSimilarity_SelectedIndexChanged);
        // 
        // bottomListView
        // 
        this.bottomListView.Alignment = System.Windows.Forms.ListViewAlignment.Left;
        this.bottomListView.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
        this.bottomListView.BorderStyle = System.Windows.Forms.BorderStyle.None;
        this.bottomListView.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.None;
        this.bottomListView.LargeImageList = this.bottomImageList;
        this.bottomListView.Location = new System.Drawing.Point(12, 41);
        this.bottomListView.MultiSelect = false;
        this.bottomListView.Name = "bottomListView";
        this.bottomListView.ShowItemToolTips = true;
        this.bottomListView.Size = new System.Drawing.Size(578, 144);
        this.bottomListView.TabIndex = 1;
        this.bottomListView.UseCompatibleStateImageBehavior = false;
        this.bottomListView.ItemDrag += new System.Windows.Forms.ItemDragEventHandler(this.bottomListView_ItemDrag);
        // 
        // bottomLabel
        // 
        this.bottomLabel.AutoSize = true;
        this.bottomLabel.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        this.bottomLabel.Location = new System.Drawing.Point(120, 8);
        this.bottomLabel.Name = "bottomLabel";
        this.bottomLabel.Size = new System.Drawing.Size(214, 18);
        this.bottomLabel.TabIndex = 2;
        this.bottomLabel.Text = "Similar Images sorted by";
        // 
        // FormMain
        // 
        this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
        this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
        this.ClientSize = new System.Drawing.Size(840, 638);
        this.Controls.Add(this.panelMain);
        this.Controls.Add(this.progressBarLoad);
        this.Controls.Add(this.listViewImages);
        this.Controls.Add(this.menuStrip1);
        this.MainMenuStrip = this.menuStrip1;
        this.Name = "FormMain";
        this.Text = "Joiners";
        this.Load += new System.EventHandler(this.FormMain_Load);
        this.menuStrip1.ResumeLayout(false);
        this.menuStrip1.PerformLayout();
        this.panelMain.ResumeLayout(false);
        this.bottomPanel.ResumeLayout(false);
        this.bottomPanel.PerformLayout();
        this.ResumeLayout(false);
        this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.ImageList imageList;
    private System.Windows.Forms.ListView listViewImages;
    private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog;
    private System.Windows.Forms.MenuStrip menuStrip1;
    private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem openDirectoryToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem quitToolStripMenuItem;
    private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
    private System.Windows.Forms.ProgressBar progressBarLoad;
    private PanelMain panelMain;
    private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem;
    private System.Windows.Forms.SaveFileDialog saveFileDialog;
    private System.Windows.Forms.ListView bottomListView;
    private System.Windows.Forms.Panel bottomPanel;
    private System.Windows.Forms.Label bottomLabel;
    private System.Windows.Forms.ColorDialog colorDialog;
    private System.Windows.Forms.ToolStripMenuItem optionsToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem backgroundColorToolStripMenuItem;
    private System.Windows.Forms.ComboBox ddlSimilarity;
    private System.Windows.Forms.Button btnBottomPanelClose;
    public System.Windows.Forms.ImageList bottomImageList;

  }
}

