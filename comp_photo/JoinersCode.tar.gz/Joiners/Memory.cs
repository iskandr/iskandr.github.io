//----------------------------------------------------------------------------
//  Project     : EdenArts.Graphic
//  Author      : Valerie Tching
//  Date        : 01/02/2005
//  File        : Memory.cs
//  Description : Memory class
//----------------------------------------------------------------------------
//  EdenArts.Graphic is a 3D graphic engine library.
//  The project is running under QPL licence.
//    (QPL Licence specifications: http://www.trolltech.com/licenses/qpl.html)
//  Zion is part of Eden Arts Team Work
//  Members are:
//      Nadim Awad        (awad_n@epitech.net)
//      Michel Courtine   (courti_m@epitech.net)
//      Matthieu Dehaussy (dehaus_m@epitech.net)
//      Julien Ferrero    (ferrer_j@epitech.net)
//      Nicolas Goubaux   (goubau_n@epitech.net)
//      Valerie Tching    (tching_v@epitech.net)
//  You can have further information on Zion website:
//         http://zion.labtech.epitech.net
//----------------------------------------------------------------------------

using System.Runtime.InteropServices;
using System;

namespace Joiners
{
	/// <summary>
	/// Zion interface with the system for operations such as dynamic memory allocation
	/// </summary>

  //
  // Dynamic Memory Allocation
  // http://msdn.microsoft.com/library/default.asp?url=/library/en-us/csspec/html/vclrfcsharpspec_A_8.asp
  //

  public unsafe class Memory
  {
    static private volatile Memory _instance;
    // Handle for the process heap. This handle is used in all calls to the
    // HeapXXX APIs in the methods below.
    static int ph = GetProcessHeap();
    // Private instance constructor to prevent instantiation.

    static public Memory           Instance
    {
      get
      {
        if (_instance == null)
        {
          lock(typeof(Memory))
          {
            if (_instance == null)
              _instance = new Memory();
          }
        }
        return _instance;
      }
    }

    private Memory() {}
    // Allocates a memory block of the given size. The allocated memory is
    // automatically initialized to zero.
    public static void* Alloc(int size) 
    {
      void* result = HeapAlloc(ph, HEAP_ZERO_MEMORY, size);
      if (result == null) throw new OutOfMemoryException();
      return result;
    }
    // Copies count bytes from src to dst. The source and destination
    // blocks are permitted to overlap.
    public static void Copy(void* src, void* dst, int count) 
    {
      byte* ps = (byte*)src;
      byte* pd = (byte*)dst;
      if (ps > pd) 
      {
        for (; count != 0; count--) *pd++ = *ps++;
      }
      else if (ps < pd) 
      {
        for (ps += count, pd += count; count != 0; count--) *--pd = *--ps;
      }
    }
    // Frees a memory block.
    public static void Free(void* block) 
    {
      if (!HeapFree(ph, 0, block)) throw new InvalidOperationException();
    }
    // Re-allocates a memory block. If the reallocation request is for a
    // larger size, the additional region of memory is automatically
    // initialized to zero.
    public static void* ReAlloc(void* block, int size) 
    {
      void* result = HeapReAlloc(ph, HEAP_ZERO_MEMORY, block, size);
      if (result == null) throw new OutOfMemoryException();
      return result;
    }
    // Returns the size of a memory block.
    public static int SizeOf(void* block) 
    {
      int result = HeapSize(ph, 0, block);
      if (result == -1) throw new InvalidOperationException();
      return result;
    }
    // Heap API flags
    const int HEAP_ZERO_MEMORY = 0x00000008;
    // Heap API functions
    [DllImport("kernel32")]
    static extern int GetProcessHeap();
    [DllImport("kernel32")]
    static extern void* HeapAlloc(int hHeap, int flags, int size);
    [DllImport("kernel32")]
    static extern bool HeapFree(int hHeap, int flags, void* block);
    [DllImport("kernel32")]
    static extern void* HeapReAlloc(int hHeap, int flags,
      void* block, int size);
    [DllImport("kernel32")]
    static extern int HeapSize(int hHeap, int flags, void* block);
  }
}
